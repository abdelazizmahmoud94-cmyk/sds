# ARHPP Digital Twin – Stage 7

```bash
cd ARHPP_App
pip install -r requirements.txt
streamlit run app.py
```

Save/Load state from sidebar.
