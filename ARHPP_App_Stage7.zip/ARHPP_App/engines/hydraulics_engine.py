"""
ARHPP Hydraulics Engine – Stage 7
+ Save / Load state (JSON)
+ All previous features
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any
from datetime import datetime
import math
import json

DEFAULT_LITHOLOGY = [
    {"name": "Dammam",   "md_top": 0,     "md_bot": 800,   "color": "#c4a574", "pp_grad": 0.45, "fg_grad": 0.85},
    {"name": "Rus",      "md_top": 800,   "md_bot": 1400,  "color": "#e8d5b7", "pp_grad": 0.46, "fg_grad": 0.90},
    {"name": "Radhuma",  "md_top": 1400,  "md_bot": 2800,  "color": "#d4b896", "pp_grad": 0.47, "fg_grad": 0.88},
    {"name": "Tayarat",  "md_top": 2800,  "md_bot": 4200,  "color": "#8b7355", "pp_grad": 0.48, "fg_grad": 0.87},
    {"name": "Hartha",   "md_top": 4200,  "md_bot": 5500,  "color": "#a0896c", "pp_grad": 0.49, "fg_grad": 0.89},
    {"name": "Sadi",     "md_top": 5500,  "md_bot": 6200,  "color": "#6b5344", "pp_grad": 0.50, "fg_grad": 0.86},
    {"name": "Mutriba",  "md_top": 6200,  "md_bot": 7000,  "color": "#9c8b7a", "pp_grad": 0.51, "fg_grad": 0.90},
    {"name": "Mishrif",  "md_top": 7000,  "md_bot": 8200,  "color": "#b89b72", "pp_grad": 0.52, "fg_grad": 0.92},
    {"name": "Rumaila",  "md_top": 8200,  "md_bot": 9500,  "color": "#a67c52", "pp_grad": 0.53, "fg_grad": 0.93},
    {"name": "Ahmadi",   "md_top": 9500,  "md_bot": 10500, "color": "#7d6b5a", "pp_grad": 0.54, "fg_grad": 0.91},
    {"name": "Wara",     "md_top": 10500, "md_bot": 11200, "color": "#c2b280", "pp_grad": 0.55, "fg_grad": 0.90},
    {"name": "Burgan",   "md_top": 11200, "md_bot": 13000, "color": "#d2b48c", "pp_grad": 0.56, "fg_grad": 0.88},
]

@dataclass
class WellGeometry:
    md: float = 12000.0
    tvd: float = 11200.0
    hole_id: float = 8.5
    pipe_od: float = 5.0
    pipe_id: float = 4.276
    casing_od: float = 9.625
    bit_depth: float = 12000.0
    shoe_depth: float = 9410.0

@dataclass
class FluidProperties:
    density_ppg: float = 10.5
    pv: float = 28.0
    yp: float = 18.0
    n: float = 0.72
    K: float = 0.45
    tau_y: float = 6.5
    temp_in: float = 120.0
    temp_out: float = 155.0
    ambient_temp: float = 95.0
    temp_gradient: float = 1.5

@dataclass
class OperatingParams:
    flow_in_gpm: float = 850.0
    flow_out_gpm: float = 845.0
    sbp_setpoint: float = 200.0
    choke_position: float = 42.0
    rpm: float = 120.0
    wob: float = 25.0
    rop: float = 45.0
    spp_measured: float = 2850.0
    pump_efficiency: float = 0.97

@dataclass
class BitParams:
    bit_type: str = "PDC"
    tfa: float = 0.85
    bit_size: float = 8.5
    nozzles: str = "16/16/16/16/14/14"

@dataclass
class SurgeSwabParams:
    pipe_velocity_ftmin: float = 60.0
    acceleration: float = 0.5
    open_end: bool = True
    stand_length: float = 93.0
    clinging_factor: float = 0.45

@dataclass
class SimulationState:
    geometry: WellGeometry = field(default_factory=WellGeometry)
    fluid: FluidProperties = field(default_factory=FluidProperties)
    operating: OperatingParams = field(default_factory=OperatingParams)
    bit: BitParams = field(default_factory=BitParams)
    surge: SurgeSwabParams = field(default_factory=SurgeSwabParams)
    mode: str = "Offline"
    choke_mode: str = "AUTO"
    target_bhp: float = 7500.0
    target_ecd: float = 11.20
    litho_gradient: float = 0.56
    lithology: List[Dict] = field(default_factory=lambda: DEFAULT_LITHOLOGY.copy())
    timeline: List[Dict] = field(default_factory=list)
    activity_log: List[Dict] = field(default_factory=list)
    history_bhp: List[float] = field(default_factory=list)
    history_ecd: List[float] = field(default_factory=list)
    history_spp: List[float] = field(default_factory=list)
    history_flow: List[float] = field(default_factory=list)
    bhp: float = 0.0
    ecd: float = 0.0
    model_spp: float = 0.0
    annular_friction: float = 0.0
    pipe_friction: float = 0.0
    bit_pressure_drop: float = 0.0
    hydrostatic: float = 0.0
    live_pp: float = 0.0
    overbalance: float = 0.0
    u_tube_dp: float = 0.0
    effective_flow: float = 0.0
    q_loss: float = 0.0
    q_utube: float = 0.0
    max_surge_psi: float = 0.0
    max_swab_psi: float = 0.0
    esd_surge: float = 0.0
    esd_swab: float = 0.0
    corrected_density: float = 0.0
    current_formation: str = "Burgan"
    delta_flow: float = 0.0
    delta_spp: float = 0.0
    diag_status: str = "OK"
    diag_message: str = ""

def _hydrostatic(density, tvd):
    return 0.052 * density * tvd

def _bit_dp(q, dens, tfa):
    if tfa <= 0: return 0.0
    return (q ** 2 * dens) / (12031.0 * tfa ** 2)

def _annular_velocity(q_gpm, hole_id, pipe_od):
    area = (math.pi / 4.0) * (hole_id**2 - pipe_od**2) / 144.0
    return (q_gpm * 0.133681) / area if area > 0 else 0.0

def _friction_factor(re):
    return 16.0 / max(re, 1.0) if re < 2100 else 0.046 * (re ** -0.2)

def _annular_friction(q, dens, hole_id, pipe_od, length, n, K, rpm=0):
    dh = hole_id - pipe_od
    if dh <= 0 or length <= 0: return 0.0
    v = _annular_velocity(q, hole_id, pipe_od)
    mu_app = K * 100.0 * (v ** (n - 1)) + 1e-6 if v > 0 else K * 100
    re = 928.0 * dens * v * dh / mu_app
    f = _friction_factor(re)
    return max(f * dens * v**2 * length / (25.8 * dh) * (1.0 + rpm/200.0*0.08), 0.0)

def _pipe_friction(q, dens, pipe_id, length, n, K):
    if pipe_id <= 0 or length <= 0: return 0.0
    area = (math.pi / 4.0) * (pipe_id ** 2) / 144.0
    v = (q * 0.133681) / area if area > 0 else 0
    mu_app = K * 100.0 * (v ** (n - 1)) + 1e-6 if v > 0 else K * 100
    re = 928.0 * dens * v * pipe_id / mu_app
    f = _friction_factor(re)
    return max(f * dens * v**2 * length / (25.8 * pipe_id), 0.0)

def _temp_corrected_density(base, temp_in, temp_out, tvd, gradient):
    return base * (1.0 - 0.0003 * ((temp_in + (tvd/100.0)*gradient) - 80))

def get_formation_at_depth(lithology, md):
    for layer in lithology:
        if layer["md_top"] <= md <= layer["md_bot"]:
            return layer
    return lithology[-1] if lithology else {"name": "Unknown", "pp_grad": 0.56, "fg_grad": 0.90, "color": "#888"}

def calculate_surge_swab(state):
    s, g, f = state.surge, state.geometry, state.fluid
    v = s.pipe_velocity_ftmin / 60.0
    dh = g.hole_id - g.pipe_od
    if dh <= 0:
        state.max_surge_psi = state.max_swab_psi = 0.0
        return state
    cling = s.clinging_factor if s.open_end else 1.0
    mu = f.pv * 1.2 + f.yp * 0.5
    base = (mu * v * g.md) / (1000.0 * dh**2) * cling * 3.5
    accel = s.acceleration * f.density_ppg * g.md * 0.0015
    state.max_surge_psi = base + accel
    state.max_swab_psi = -(base * 0.9)
    state.esd_surge = state.ecd + (state.max_surge_psi / (0.052 * g.tvd)) if g.tvd > 0 else state.ecd
    state.esd_swab = state.ecd + (state.max_swab_psi / (0.052 * g.tvd)) if g.tvd > 0 else state.ecd
    return state

def auto_adjust_sbp_for_cbhp(state):
    if state.choke_mode != "CBHP":
        return state
    error = state.target_bhp - state.bhp
    step = max(-30.0, min(30.0, error * 0.18))
    state.operating.sbp_setpoint = max(0.0, min(1000.0, state.operating.sbp_setpoint + step))
    state.operating.choke_position = max(5.0, min(95.0, 28.0 + state.operating.sbp_setpoint / 9.5))
    return state

def run_diagnostics(state):
    state.delta_flow = state.operating.flow_in_gpm - state.operating.flow_out_gpm
    state.delta_spp = state.operating.spp_measured - state.model_spp
    msgs = []
    status = "OK"
    if abs(state.delta_flow) > 15:
        status = "WARNING"
        msgs.append(f"Flow imbalance ΔQ={state.delta_flow:.1f} gpm (possible loss/gain)")
    elif abs(state.delta_flow) > 5:
        msgs.append(f"Minor flow difference ΔQ={state.delta_flow:.1f} gpm")
    if abs(state.delta_spp) > 150:
        status = "WARNING" if status == "OK" else status
        msgs.append(f"SPP residual {state.delta_spp:+.0f} psi (diagnostic only)")
    elif abs(state.delta_spp) > 50:
        msgs.append(f"SPP residual {state.delta_spp:+.0f} psi")
    if state.overbalance < 100:
        status = "ALERT"
        msgs.append(f"Low overbalance {state.overbalance:.0f} psi")
    state.diag_status = status
    state.diag_message = " | ".join(msgs) if msgs else "All primary parameters within normal range"
    return state

def push_history(state, maxlen=40):
    state.history_bhp.append(state.bhp)
    state.history_ecd.append(state.ecd)
    state.history_spp.append(state.model_spp)
    state.history_flow.append(state.effective_flow)
    state.history_bhp = state.history_bhp[-maxlen:]
    state.history_ecd = state.history_ecd[-maxlen:]
    state.history_spp = state.history_spp[-maxlen:]
    state.history_flow = state.history_flow[-maxlen:]
    return state

def run_hydraulics(state):
    g, f, o, b = state.geometry, state.fluid, state.operating, state.bit
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    state.current_formation = form["name"]
    state.litho_gradient = form.get("pp_grad", 0.56)

    state.corrected_density = _temp_corrected_density(f.density_ppg, f.temp_in, f.temp_out, g.tvd, f.temp_gradient)
    state.q_loss = max(0.0, o.flow_in_gpm - o.flow_out_gpm)
    dens_ann = state.corrected_density + 0.15
    state.u_tube_dp = 0.052 * (dens_ann - state.corrected_density) * g.tvd * 0.15
    state.q_utube = max(0.0, state.u_tube_dp / 8.0)
    state.effective_flow = o.flow_in_gpm + state.q_utube - state.q_loss

    state.hydrostatic = _hydrostatic(state.corrected_density, g.tvd)
    state.bit_pressure_drop = _bit_dp(state.effective_flow, state.corrected_density, b.tfa)
    state.annular_friction = _annular_friction(state.effective_flow, state.corrected_density, g.hole_id, g.pipe_od, g.md, f.n, f.K, o.rpm)
    state.pipe_friction = _pipe_friction(state.effective_flow, state.corrected_density, g.pipe_id, g.md, f.n, f.K)

    state.bhp = state.hydrostatic + state.annular_friction + o.sbp_setpoint
    state.ecd = state.bhp / (0.052 * g.tvd) if g.tvd > 0 else 0.0
    state.model_spp = state.pipe_friction + state.bit_pressure_drop + o.sbp_setpoint + state.annular_friction * 0.15

    bit_factor = {"PDC": 1.0, "Diamond Impregnated": 1.05, "Tricone": 0.95}.get(b.bit_type, 1.0)
    rop_factor = 1.0 - (o.rop - 40) * 0.001 if o.rop > 0 else 1.0
    state.live_pp = g.tvd * state.litho_gradient * bit_factor * max(0.9, min(1.1, rop_factor))
    state.overbalance = state.bhp - state.live_pp

    state = calculate_surge_swab(state)

    if state.choke_mode == "CBHP" and state.mode == "Simulation":
        state = auto_adjust_sbp_for_cbhp(state)
        state.bhp = state.hydrostatic + state.annular_friction + state.operating.sbp_setpoint
        state.ecd = state.bhp / (0.052 * g.tvd) if g.tvd > 0 else 0.0
        state.overbalance = state.bhp - state.live_pp

    state = run_diagnostics(state)
    state = push_history(state)
    return state

def get_profile_depth_data(state, num_points=16):
    rows = []
    md_step = state.geometry.md / max(num_points - 1, 1)
    for i in range(num_points):
        md = i * md_step
        tvd = md * (state.geometry.tvd / state.geometry.md) if state.geometry.md > 0 else md
        frac = md / state.geometry.md if state.geometry.md > 0 else 0.0
        dens_ann = state.corrected_density + frac * 0.25
        hydro = _hydrostatic(dens_ann, tvd)
        fric = state.annular_friction * frac
        pressure = hydro + fric + state.operating.sbp_setpoint * frac
        ecd = pressure / (0.052 * tvd) if tvd > 1 else 0.0
        form = get_formation_at_depth(state.lithology, md)
        form_temp = state.fluid.ambient_temp + (tvd / 100.0) * state.fluid.temp_gradient
        ann_temp = state.fluid.temp_in + frac * (state.fluid.temp_out - state.fluid.temp_in)
        rows.append({
            "MD_ft": round(md, 0), "TVD_ft": round(tvd, 0), "Formation": form["name"],
            "Formation_Temp_F": round(form_temp, 1), "Annulus_Temp_F": round(ann_temp, 1),
            "Pipe_Temp_F": round(state.fluid.temp_in + frac * 18, 1),
            "Annulus_Density_ppg": round(dens_ann, 2), "Pipe_Density_ppg": round(state.corrected_density, 2),
            "Annulus_Friction_psi": round(fric, 1),
            "Pipe_App_Visc_cP": round(state.fluid.pv * (1 + frac * 0.3), 1),
            "Annulus_App_Visc_cP": round(state.fluid.pv * (1 + frac * 0.5), 1),
            "Annulus_ECD_ppg": round(ecd, 2), "Annulus_Pressure_psi": round(pressure, 1),
            "Pore_Pressure_psi": round(tvd * form.get("pp_grad", 0.56), 1),
            "Fracture_Pressure_psi": round(tvd * form.get("fg_grad", 0.90), 1),
            "PPG": round(form.get("pp_grad", 0.56) * 19.25, 2), "WBSG_ppg": 0.0, "WBS_psi": 0.0,
        })
    return rows

def add_timeline_event(state, event, details=""):
    state.timeline.insert(0, {"time": datetime.now().strftime("%H:%M:%S"), "event": event, "details": details})
    state.timeline = state.timeline[:50]
    return state

def log_activity(state, activity, duration_min=1.0):
    state.activity_log.append({"time": datetime.now().strftime("%H:%M:%S"), "activity": activity, "duration_min": duration_min})
    state.activity_log = state.activity_log[-200:]
    return state

def get_activity_summary(state):
    summary = {}
    for a in state.activity_log:
        summary[a["activity"]] = summary.get(a["activity"], 0.0) + a.get("duration_min", 1.0)
    if not summary:
        summary = {"Drilling": 42, "Connection": 18, "Circulating": 15, "Trip": 12, "Offline": 8, "Other": 5}
    return summary

def state_to_dict(state: SimulationState) -> Dict[str, Any]:
    """Serialize state for Save"""
    return {
        "geometry": asdict(state.geometry),
        "fluid": asdict(state.fluid),
        "operating": asdict(state.operating),
        "bit": asdict(state.bit),
        "surge": asdict(state.surge),
        "mode": state.mode,
        "choke_mode": state.choke_mode,
        "target_bhp": state.target_bhp,
        "target_ecd": state.target_ecd,
        "litho_gradient": state.litho_gradient,
        "lithology": state.lithology,
        "timeline": state.timeline[:20],
        "activity_log": state.activity_log[-50:],
    }

def dict_to_state(data: Dict[str, Any]) -> SimulationState:
    """Deserialize state for Load"""
    state = SimulationState()
    if "geometry" in data:
        state.geometry = WellGeometry(**data["geometry"])
    if "fluid" in data:
        state.fluid = FluidProperties(**data["fluid"])
    if "operating" in data:
        state.operating = OperatingParams(**data["operating"])
    if "bit" in data:
        state.bit = BitParams(**data["bit"])
    if "surge" in data:
        state.surge = SurgeSwabParams(**data["surge"])
    state.mode = data.get("mode", "Offline")
    state.choke_mode = data.get("choke_mode", "AUTO")
    state.target_bhp = data.get("target_bhp", 7500.0)
    state.target_ecd = data.get("target_ecd", 11.20)
    state.litho_gradient = data.get("litho_gradient", 0.56)
    state.lithology = data.get("lithology", DEFAULT_LITHOLOGY.copy())
    state.timeline = data.get("timeline", [])
    state.activity_log = data.get("activity_log", [])
    return run_hydraulics(state)

def save_state_json(state: SimulationState, path: str = "data/well_state.json") -> str:
    from pathlib import Path
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state_to_dict(state), indent=2), encoding="utf-8")
    return str(p)

def load_state_json(path: str = "data/well_state.json") -> SimulationState:
    from pathlib import Path
    p = Path(path)
    if not p.exists():
        return run_hydraulics(SimulationState())
    data = json.loads(p.read_text(encoding="utf-8"))
    return dict_to_state(data)
