"""
ARHPP Main Application – Stage 7
Save/Load well state + UI polish
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config.settings import APP_NAME, APP_VERSION, APP_SUBTITLE
from engines.hydraulics_engine import (
    SimulationState, run_hydraulics, get_profile_depth_data,
    add_timeline_event, log_activity, get_activity_summary,
    save_state_json, load_state_json, state_to_dict
)

st.set_page_config(page_title=APP_NAME, page_icon="🛢️", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
    .stApp { background-color: #1a1d23; color: #d0d0d0; }
    section[data-testid="stSidebar"] { background-color: #12151a; }
    div[data-testid="stMetricValue"] { color: #00d4aa; font-size: 1.28rem; }
    .block-container { padding-top: 0.4rem; padding-bottom: 0.2rem; }
    h1, h2, h3, h4 { color: #e8e8e8 !important; }
</style>
""", unsafe_allow_html=True)

if "state" not in st.session_state:
    st.session_state.state = run_hydraulics(SimulationState())
if "app_name" not in st.session_state:
    st.session_state.app_name = APP_NAME

state = st.session_state.state

# Top bar
c1, c2, c3, c4 = st.columns([0.5, 3.5, 1.6, 1.2])
with c1:
    st.markdown("### 🛢️")
with c2:
    st.markdown(f"## {st.session_state.app_name} <span style='font-size:12px;color:#888'>{APP_VERSION}</span>", unsafe_allow_html=True)
with c3:
    st.caption(f"Bit: {state.geometry.bit_depth:.0f} ft | {state.current_formation}")
with c4:
    mode_color = {"Offline": "#ffaa00", "Simulation": "#00d4aa", "Live": "#00ff88"}.get(state.mode, "#ffaa00")
    st.markdown(f"<div style='text-align:right;padding-top:10px'><span style='background:{mode_color};color:#111;padding:4px 12px;border-radius:4px;font-weight:700;font-size:12px'>{state.mode.upper()}</span></div>", unsafe_allow_html=True)

status_color = {"OK": "#00d4aa", "WARNING": "#ffaa00", "ALERT": "#ff5555"}.get(state.diag_status, "#888")
st.markdown(f"""
<div style="background:#252a33;padding:6px 12px;border-radius:4px;border-left:4px solid {status_color};margin-bottom:8px;font-size:13px">
<b style="color:{status_color}">{state.diag_status}</b> &nbsp;|&nbsp; {state.diag_message}
</div>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.markdown(f"**{st.session_state.app_name}**")
    nav = st.radio("Modules", [
        "Profile Depth Data", "MPD Gauges", "Main Time Data",
        "Surge & Swab", "Choke Control", "Actual vs Model",
        "Timeline", "Performance", "Engineering", "Settings"
    ], index=0)
    st.markdown("---")
    st.markdown("**Quick Setpoints**")
    state.mode = st.selectbox("Mode", ["Offline", "Simulation", "Live"],
                              index=["Offline", "Simulation", "Live"].index(state.mode))
    state.choke_mode = st.selectbox("Choke Mode", ["MANUAL", "AUTO", "CBHP"],
                                    index=["MANUAL", "AUTO", "CBHP"].index(state.choke_mode))
    state.operating.sbp_setpoint = st.slider("SBP (psi)", 0, 1000, int(state.operating.sbp_setpoint), 5)
    state.operating.flow_in_gpm = st.number_input("Flow In (gpm)", 0.0, 2000.0, float(state.operating.flow_in_gpm), 10.0)
    state.operating.flow_out_gpm = st.number_input("Flow Out (gpm)", 0.0, 2000.0, float(state.operating.flow_out_gpm), 5.0)
    state.operating.spp_measured = st.number_input("SPP Measured (psi)", 0.0, 6000.0, float(state.operating.spp_measured), 10.0)
    state.operating.choke_position = st.slider("Choke %", 0, 100, int(state.operating.choke_position), 1)

    if state.mode == "Simulation":
        if st.button("▶ Step Simulation", use_container_width=True):
            import random
            state.operating.flow_out_gpm = max(0, state.operating.flow_in_gpm - random.uniform(2, 12))
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = log_activity(st.session_state.state, "Drilling", 0.5)
            st.rerun()

    if st.button("⟳ Recalculate", use_container_width=True, type="primary"):
        st.session_state.state = run_hydraulics(state)
        st.session_state.state = add_timeline_event(st.session_state.state, "Recalculate", f"SBP={state.operating.sbp_setpoint:.0f}")
        st.session_state.state = log_activity(st.session_state.state, "Circulating", 2.0)
        st.rerun()

    st.markdown("---")
    st.markdown("**Save / Load**")
    if st.button("💾 Save State", use_container_width=True):
        path = save_state_json(st.session_state.state, "data/well_state.json")
        st.session_state.state = add_timeline_event(st.session_state.state, "State Saved", path)
        st.success(f"Saved → {path}")
    if st.button("📂 Load State", use_container_width=True):
        st.session_state.state = load_state_json("data/well_state.json")
        st.session_state.state = add_timeline_event(st.session_state.state, "State Loaded")
        st.rerun()

# ── Pages (same structure as Stage 6 + Save/Load already in sidebar) ──
if nav == "Profile Depth Data":
    gcols = st.columns(7)
    for col, (label, val, unit, delta) in zip(gcols, [
        ("BHP", f"{state.bhp:.0f}", "psi", f"Tgt {state.target_bhp:.0f}"),
        ("ECD", f"{state.ecd:.2f}", "ppg", f"Tgt {state.target_ecd:.2f}"),
        ("Model SPP", f"{state.model_spp:.0f}", "psi", None),
        ("SBP", f"{state.operating.sbp_setpoint:.0f}", "psi", None),
        ("Flow In", f"{state.operating.flow_in_gpm:.0f}", "gpm", None),
        ("Live PP", f"{state.live_pp:.0f}", "psi", f"OB {state.overbalance:.0f}"),
        ("Eff. Flow", f"{state.effective_flow:.0f}", "gpm", None),
    ]):
        col.metric(label, f"{val} {unit}", delta)

    left, right = st.columns([3.1, 1.2])
    with left:
        df = pd.DataFrame(get_profile_depth_data(state, 18))
        display_df = df.rename(columns={
            "MD_ft": "MD", "TVD_ft": "TVD", "Formation": "Form",
            "Formation_Temp_F": "Form.T", "Annulus_Temp_F": "Ann.T",
            "Pipe_Temp_F": "Pipe.T", "Annulus_Density_ppg": "Ann.Dens",
            "Pipe_Density_ppg": "Pipe.Dens", "Annulus_Friction_psi": "Ann.Fric",
            "Pipe_App_Visc_cP": "Pipe.Visc", "Annulus_App_Visc_cP": "Ann.Visc",
            "Annulus_ECD_ppg": "Ann.ECD", "Annulus_Pressure_psi": "Ann.P",
            "Pore_Pressure_psi": "PP", "Fracture_Pressure_psi": "FG",
            "PPG": "PPG", "WBSG_ppg": "WBSG", "WBS_psi": "WBS"
        })
        st.dataframe(display_df, use_container_width=True, height=380)

    with right:
        st.markdown("**Well Schematic + Lithology**")
        fig = go.Figure()
        total_md = max(state.geometry.md, 1)
        for layer in state.lithology:
            y0 = (layer["md_top"] / total_md) * 100
            y1 = min((layer["md_bot"] / total_md) * 100, 100)
            if y0 > 100: continue
            fig.add_shape(type="rect", x0=0.18, x1=0.82, y0=y0, y1=y1,
                          fillcolor=layer["color"], opacity=0.88, line=dict(color="#1a1d23", width=0.6))
            if y1 - y0 > 3.5:
                fig.add_annotation(x=0.5, y=(y0+y1)/2, text=layer["name"], showarrow=False, font=dict(size=9, color="#111"))
        shoe_y = (state.geometry.shoe_depth / total_md) * 100
        fig.add_shape(type="line", x0=0.05, x1=0.95, y0=shoe_y, y1=shoe_y, line=dict(color="#ffaa00", width=2, dash="dot"))
        bit_y = (state.geometry.bit_depth / total_md) * 100
        fig.add_shape(type="rect", x0=0.08, x1=0.92, y0=bit_y-1.3, y1=bit_y+1.3, fillcolor="#00d4aa", line=dict(width=0))
        fig.update_layout(height=350, margin=dict(l=5,r=5,t=5,b=5), paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23",
                          xaxis=dict(visible=False, range=[0,1]),
                          yaxis=dict(range=[100,0], color="#718096", gridcolor="#2d3748", tickfont=dict(size=9)))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(f"<small>**{state.current_formation}** | Bit {state.geometry.bit_depth:.0f} ft<br>Shoe {state.geometry.shoe_depth:.0f} ft | Choke {state.operating.choke_position:.0f}% ({state.choke_mode})</small>", unsafe_allow_html=True)

elif nav == "Main Time Data":
    st.subheader("Main Time Data – Live Trends")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Effective Flow", f"{state.effective_flow:.1f} gpm")
    m2.metric("Q Loss", f"{state.q_loss:.1f} gpm")
    m3.metric("Q U-Tube", f"{state.q_utube:.1f} gpm")
    m4.metric("Annular Friction", f"{state.annular_friction:.0f} psi")
    if len(state.history_bhp) > 2:
        fig = go.Figure()
        x = list(range(len(state.history_bhp)))
        fig.add_trace(go.Scatter(x=x, y=state.history_bhp, name="BHP", line=dict(color="#00d4aa", width=2)))
        fig.add_trace(go.Scatter(x=x, y=state.history_spp, name="Model SPP", line=dict(color="#4a9eff", width=2)))
        fig.add_trace(go.Scatter(x=x, y=[e*100 for e in state.history_ecd], name="ECD×100", line=dict(color="#ffaa00", width=2)))
        fig.update_layout(paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"),
                          height=300, margin=dict(t=20, b=30), legend=dict(orientation="h"))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Press **Step Simulation** or **Recalculate** a few times to build live trend history.")
    st.metric("Pipe Friction", f"{state.pipe_friction:.0f} psi")
    st.metric("Bit ΔP", f"{state.bit_pressure_drop:.0f} psi")
    st.metric("Corrected Density", f"{state.corrected_density:.2f} ppg")
    st.metric("Current Formation", state.current_formation)

elif nav == "Actual vs Model":
    st.subheader("Actual vs Model Diagnostics")
    st.caption("Primary drivers: Flow In/Out + Density + Temperature. SPP is secondary diagnostic only.")
    d1, d2, d3, d4 = st.columns(4)
    d1.metric("Flow In (Actual)", f"{state.operating.flow_in_gpm:.1f} gpm")
    d2.metric("Flow Out (Actual)", f"{state.operating.flow_out_gpm:.1f} gpm")
    d3.metric("ΔQ (In−Out)", f"{state.delta_flow:.1f} gpm")
    d4.metric("Q Loss (model)", f"{state.q_loss:.1f} gpm")
    st.markdown("---")
    s1, s2, s3 = st.columns(3)
    s1.metric("SPP Measured", f"{state.operating.spp_measured:.0f} psi")
    s2.metric("SPP Model", f"{state.model_spp:.0f} psi")
    s3.metric("Δ SPP (Meas−Model)", f"{state.delta_spp:+.0f} psi")
    st.markdown(f"**Status: {state.diag_status}**")
    st.info(state.diag_message)
    fig = go.Figure()
    fig.add_trace(go.Bar(name="Measured / Actual", x=["Flow In", "SPP"], y=[state.operating.flow_in_gpm, state.operating.spp_measured], marker_color="#4a9eff"))
    fig.add_trace(go.Bar(name="Model", x=["Flow In", "SPP"], y=[state.operating.flow_in_gpm, state.model_spp], marker_color="#00d4aa"))
    fig.update_layout(barmode="group", paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"), height=260, margin=dict(t=20, b=40))
    st.plotly_chart(fig, use_container_width=True)
    st.warning("SPP difference is diagnostic only and does NOT drive pressure calculations.")

elif nav == "Performance":
    st.subheader("Performance – Well Activities")
    summary = get_activity_summary(state)
    fig_pie = px.pie(names=list(summary.keys()), values=list(summary.values()),
                     color_discrete_sequence=px.colors.qualitative.Set2, hole=0.35)
    fig_pie.update_layout(paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"), height=320, margin=dict(t=30,b=20,l=20,r=20))
    col_p1, col_p2 = st.columns([1.4, 1])
    with col_p1:
        st.plotly_chart(fig_pie, use_container_width=True)
    with col_p2:
        for k, v in sorted(summary.items(), key=lambda x: -x[1]):
            st.write(f"• **{k}**: {v:.0f} min")
        act = st.selectbox("Activity type", ["Drilling", "Connection", "Circulating", "Trip", "Offline", "Other"])
        dur = st.number_input("Duration (min)", 0.5, 120.0, 5.0, 0.5)
        if st.button("Add Activity"):
            st.session_state.state = log_activity(state, act, dur)
            st.session_state.state = add_timeline_event(st.session_state.state, f"Activity: {act}", f"{dur} min")
            st.rerun()

elif nav == "Engineering":
    st.subheader("Engineering – Hydraulics Summary")
    e1, e2, e3 = st.columns(3)
    e1.metric("Hydrostatic", f"{state.hydrostatic:.0f} psi")
    e1.metric("Annular Friction", f"{state.annular_friction:.0f} psi")
    e1.metric("Pipe Friction", f"{state.pipe_friction:.0f} psi")
    e2.metric("Bit ΔP", f"{state.bit_pressure_drop:.0f} psi")
    e2.metric("U-Tube ΔP", f"{state.u_tube_dp:.0f} psi")
    e2.metric("Effective Flow", f"{state.effective_flow:.1f} gpm")
    e3.metric("Corrected Density", f"{state.corrected_density:.2f} ppg")
    e3.metric("Live PP Gradient", f"{state.litho_gradient:.3f} psi/ft")
    e3.metric("Overbalance", f"{state.overbalance:.0f} psi")
    budget = {"Hydrostatic": state.hydrostatic, "Annular Friction": state.annular_friction, "SBP": state.operating.sbp_setpoint}
    fig_bar = go.Figure(go.Bar(x=list(budget.keys()), y=list(budget.values()), marker_color=["#4a9eff", "#00d4aa", "#ffaa00"]))
    fig_bar.update_layout(paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"), height=240, yaxis_title="psi", margin=dict(t=20,b=40))
    st.plotly_chart(fig_bar, use_container_width=True)

elif nav == "Timeline":
    st.subheader("Timeline / Feedback")
    ec1, ec2 = st.columns([3, 1])
    with ec1:
        new_event = st.text_input("Add event comment", placeholder="Connection, Pump up, Gas show...")
    with ec2:
        st.write(""); st.write("")
        if st.button("Add to Timeline", use_container_width=True) and new_event.strip():
            st.session_state.state = add_timeline_event(state, new_event.strip())
            st.rerun()
    if state.timeline:
        st.dataframe(pd.DataFrame(state.timeline), use_container_width=True, height=320)
    else:
        st.info("No events yet.")

elif nav == "Surge & Swab":
    st.subheader("Surge & Swab Calculator")
    sc1, sc2 = st.columns(2)
    with sc1:
        state.surge.pipe_velocity_ftmin = st.slider("Pipe Velocity (ft/min)", 5, 150, int(state.surge.pipe_velocity_ftmin))
        state.surge.acceleration = st.number_input("Acceleration (ft/s²)", 0.0, 3.0, float(state.surge.acceleration), 0.1)
        state.surge.open_end = st.checkbox("Open Ended", value=state.surge.open_end)
        state.surge.clinging_factor = st.slider("Clinging Factor", 0.1, 1.0, float(state.surge.clinging_factor), 0.05)
        if st.button("Calculate Surge/Swab", type="primary"):
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Surge/Swab", f"Vel={state.surge.pipe_velocity_ftmin}")
            st.session_state.state = log_activity(st.session_state.state, "Trip", 3.0)
            st.rerun()
    with sc2:
        st.metric("Max Surge", f"{state.max_surge_psi:.0f} psi")
        st.metric("Max Swab", f"{state.max_swab_psi:.0f} psi")
        st.metric("ESD Surge", f"{state.esd_surge:.2f} ppg")
        st.metric("ESD Swab", f"{state.esd_swab:.2f} ppg")
        st.metric("BHP @ Surge", f"{state.bhp + state.max_surge_psi:.0f} psi")
        st.metric("BHP @ Swab", f"{state.bhp + state.max_swab_psi:.0f} psi")

elif nav == "Choke Control":
    st.subheader("Choke Control Panel")
    cc1, cc2, cc3 = st.columns(3)
    with cc1:
        state.choke_mode = st.radio("Choke Mode", ["MANUAL", "AUTO", "CBHP"],
                                    index=["MANUAL", "AUTO", "CBHP"].index(state.choke_mode), horizontal=True)
    with cc2:
        if state.choke_mode == "CBHP":
            state.target_bhp = st.number_input("Target BHP (psi)", 0.0, 15000.0, float(state.target_bhp), 10.0)
        elif state.choke_mode == "AUTO":
            state.target_ecd = st.number_input("Target ECD (ppg)", 8.0, 18.0, float(state.target_ecd), 0.05)
        state.operating.sbp_setpoint = st.slider("SBP Setpoint (psi)", 0, 1000, int(state.operating.sbp_setpoint), 5)
    with cc3:
        st.metric("Choke Position", f"{state.operating.choke_position:.0f} %")
        st.metric("Current SBP", f"{state.operating.sbp_setpoint:.0f} psi")
        st.metric("Current BHP", f"{state.bhp:.0f} psi")
        st.metric("Current ECD", f"{state.ecd:.2f} ppg")
    if st.button("Apply Setpoint & Recalculate", type="primary", use_container_width=True):
        st.session_state.state = run_hydraulics(state)
        st.session_state.state = add_timeline_event(st.session_state.state, "Choke Apply", f"{state.choke_mode} SBP={state.operating.sbp_setpoint:.0f}")
        st.rerun()
    if state.choke_mode == "CBHP":
        st.success("CBHP Auto active in Simulation mode → SBP adjusts to hold Target BHP.")

elif nav == "MPD Gauges":
    st.subheader("MPD Gauges")
    g1, g2, g3, g4 = st.columns(4)
    g1.metric("BHP", f"{state.bhp:.0f} psi", f"{state.bhp - state.target_bhp:+.0f}")
    g2.metric("ECD", f"{state.ecd:.2f} ppg", f"{state.ecd - state.target_ecd:+.2f}")
    g3.metric("SBP", f"{state.operating.sbp_setpoint:.0f} psi")
    g4.metric("Overbalance", f"{state.overbalance:.0f} psi")
    if len(state.history_bhp) > 2:
        st.line_chart({"BHP": state.history_bhp, "ECD×100": [e*100 for e in state.history_ecd]})
    else:
        st.line_chart({"BHP": [state.bhp-40, state.bhp-15, state.bhp, state.bhp+8, state.bhp-5],
                       "ECD x100": [(state.ecd-0.08)*100, (state.ecd-0.03)*100, state.ecd*100, (state.ecd+0.02)*100, state.ecd*100]})

elif nav == "Settings":
    st.subheader("Settings")
    new_name = st.text_input("Application Display Name", value=st.session_state.app_name)
    if st.button("Update Name"):
        st.session_state.app_name = new_name
        st.success(f"Name set to: {new_name}")
        st.rerun()
    st.markdown("---")
    st.markdown("**Well Geometry**")
    state.geometry.md = st.number_input("Total MD (ft)", value=float(state.geometry.md))
    state.geometry.tvd = st.number_input("TVD (ft)", value=float(state.geometry.tvd))
    state.geometry.hole_id = st.number_input("Hole ID (in)", value=float(state.geometry.hole_id))
    state.geometry.pipe_od = st.number_input("Pipe OD (in)", value=float(state.geometry.pipe_od))
    state.geometry.bit_depth = st.number_input("Bit Depth (ft)", value=float(state.geometry.bit_depth))
    state.geometry.shoe_depth = st.number_input("Casing Shoe (ft)", value=float(state.geometry.shoe_depth))
    st.markdown("**Fluid**")
    state.fluid.density_ppg = st.number_input("Mud Density (ppg)", value=float(state.fluid.density_ppg))
    state.fluid.temp_in = st.number_input("Mud Temp In (°F)", value=float(state.fluid.temp_in))
    state.fluid.temp_out = st.number_input("Mud Temp Out (°F)", value=float(state.fluid.temp_out))
    state.fluid.n = st.number_input("n (HB)", value=float(state.fluid.n), format="%.3f")
    state.fluid.K = st.number_input("K (HB)", value=float(state.fluid.K), format="%.3f")
    st.markdown("**Bit**")
    state.bit.bit_type = st.selectbox("Bit Type", ["PDC", "Diamond Impregnated", "Tricone"])
    state.bit.tfa = st.number_input("TFA (in²)", value=float(state.bit.tfa), format="%.3f")
    if st.button("Apply All & Recalculate", type="primary"):
        st.session_state.state = run_hydraulics(state)
        st.session_state.state = add_timeline_event(st.session_state.state, "Settings Applied")
        st.rerun()

else:
    st.subheader(nav)
    st.info(f"Module **{nav}** ready.")

st.markdown("<hr style='border-color:#333'>", unsafe_allow_html=True)
st.caption(f"{st.session_state.app_name} | Stage 7 | Save/Load + Live trends | Excel v4 physics | SPP diagnostic only")
