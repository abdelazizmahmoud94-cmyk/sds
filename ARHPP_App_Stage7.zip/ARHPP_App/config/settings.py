APP_NAME = "ARHPP Digital Twin"
APP_VERSION = "1.0.0-Stage7"
APP_SUBTITLE = "Managed Pressure Drilling & Hydraulics Simulator"
PRIMARY_COLOR = "#00d4aa"
