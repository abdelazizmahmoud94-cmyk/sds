# ARHPP Digital Twin – Stage 25 Final

**PROTOTYPE / EDUCATIONAL SIMULATOR**  
Not validated for operational decisions or Well Control.

## Phases completed

### Phase 1 – Safety / anti-misleading
Correct pump volumetric formula · volume-queue multi-fluid · U-Tube indicator → solver · no Flow-Out mutation · no pit auto-integrate by default · full annular friction in SPP · generic formations

### Phase 2 – Single source of truth
Monitoring / Setup / Operations navigation · one owner per parameter · read-only status strip

### Phase 3 – Sectional physics core (`sectional_physics.py`)
Section builder · true capacities · sectional friction · survey hydrostatic · loss-location flow · U-Tube root solver · pressure ledger

### Phase 4 – Diagnostics (`diagnostics.py`)
Immutable raw sensors · EMA filter · opt-in timestamp pit integrate · operating-state machine · hypothesis ranking with confidence & reason codes

### Phase 5 – Estimated pore pressure (`pore_pressure.py`)
Per-method estimate / uncertainty / applicability / data_quality / calibration_status / reason_codes  
Inverse-variance × quality fusion · d-exp state filtering · MSE torque awareness · gas OBM solubility note · uncertainty bands

## Run
```bash
cd ARHPP_App
pip install -r requirements.txt
streamlit run app.py
```
