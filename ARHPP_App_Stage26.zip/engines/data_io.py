"""
ARHPP Data Export / Import

- Settings: per-section or single combined package
- Well path / String profile / Well profile: independent packages
- Graph data: per-graph series only, with optional time window
- Import replaces live data in the accepted range (no future timestamps)
- Column order must match export schema or import is rejected

PROTOTYPE – JSON packages; not a field data historian.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timezone
import json
import copy

SCHEMA_VERSION = "1.0"

# ─────────────────────────────────────────────────────────────
# Time helpers
# ─────────────────────────────────────────────────────────────

def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _parse_ts(s: str) -> Optional[datetime]:
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _is_future(ts: Optional[datetime], now: Optional[datetime] = None) -> bool:
    if ts is None:
        return False
    now = now or _now_utc()
    return ts > now


def _in_window(ts: Optional[datetime], t0: Optional[datetime], t1: Optional[datetime]) -> bool:
    if ts is None:
        return True  # unlabeled samples kept when no filter labels
    if t0 and ts < t0:
        return False
    if t1 and ts > t1:
        return False
    return True


# ─────────────────────────────────────────────────────────────
# Settings packages
# ─────────────────────────────────────────────────────────────

SETTINGS_KEYS = (
    "fluid",
    "fluid_library",
    "surface_equipment",
    "piping",
    "chokes",
    "choke_control_mode",
    "target_sbp",
    "target_ecd",
    "bit",
    "formations",  # lithology
    "temperatures",  # temp_profile
    "surge",
    "pump_fluid_name",
    "initial_fluid_name",
)


def _extract_settings_section(state, section: str) -> Dict[str, Any]:
    s = section.lower().strip()
    if s == "fluid":
        return {"fluid": copy.deepcopy(state.fluid.__dict__ if hasattr(state.fluid, "__dict__") else dict(state.fluid))}
    if s == "fluid_library":
        return {"fluid_library": copy.deepcopy(state.fluid_library or [])}
    if s == "surface_equipment":
        return {"surface_equipment": copy.deepcopy(state.surface_equipment or [])}
    if s == "piping":
        return {"piping": copy.deepcopy(state.piping or [])}
    if s == "chokes":
        return {
            "chokes": copy.deepcopy(getattr(state, "chokes", []) or []),
            "choke_control_mode": getattr(state, "choke_control_mode", "SBP"),
            "target_sbp": getattr(state, "target_sbp", 200.0),
            "target_ecd": getattr(state, "target_ecd", 11.2),
        }
    if s == "bit":
        return {"bit": copy.deepcopy(state.bit.__dict__ if hasattr(state.bit, "__dict__") else dict(state.bit))}
    if s in ("formations", "lithology"):
        return {"lithology": copy.deepcopy(state.lithology or [])}
    if s in ("temperatures", "temp_profile"):
        return {"temp_profile": copy.deepcopy(state.temp_profile or [])}
    if s == "surge":
        return {"surge": copy.deepcopy(state.surge.__dict__ if hasattr(state.surge, "__dict__") else dict(state.surge))}
    if s == "mud_selection":
        return {
            "pump_fluid_name": state.pump_fluid_name,
            "initial_fluid_name": state.initial_fluid_name,
        }
    if s in ("all", "all_settings"):
        out = {}
        for k in ("fluid", "fluid_library", "surface_equipment", "piping", "chokes",
                  "bit", "formations", "temperatures", "surge", "mud_selection"):
            out.update(_extract_settings_section(state, k))
        return out
    raise ValueError(f"Unknown settings section: {section}")


def export_settings(state, section: str = "all") -> Dict[str, Any]:
    payload = _extract_settings_section(state, section)
    return {
        "schema": SCHEMA_VERSION,
        "kind": "settings",
        "section": section,
        "exported_at": _now_utc().isoformat(),
        "data": payload,
    }


def import_settings(state, package: Dict[str, Any]) -> Tuple[Any, str]:
    if package.get("kind") not in ("settings", None) and package.get("schema"):
        # allow bare data dicts only if kind missing for flexibility
        pass
    if package.get("kind") and package.get("kind") != "settings":
        return state, "Rejected: package kind is not 'settings'"
    data = package.get("data") or package
    # Apply known keys only
    from engines.hydraulics_engine import FluidProperties, BitParams, SurgeSwabParams, WellGeometry

    if "fluid" in data and data["fluid"]:
        f = data["fluid"]
        if isinstance(f, dict):
            state.fluid = FluidProperties(**{k: v for k, v in f.items() if k in FluidProperties.__dataclass_fields__})
    if "fluid_library" in data and data["fluid_library"] is not None:
        state.fluid_library = list(data["fluid_library"])
    if "surface_equipment" in data and data["surface_equipment"] is not None:
        state.surface_equipment = list(data["surface_equipment"])
    if "piping" in data and data["piping"] is not None:
        state.piping = list(data["piping"])
    if "chokes" in data and data["chokes"] is not None:
        state.chokes = list(data["chokes"])
    if "choke_control_mode" in data:
        state.choke_control_mode = str(data["choke_control_mode"])
        state.choke_mode = state.choke_control_mode
    if "target_sbp" in data:
        state.target_sbp = float(data["target_sbp"])
    if "target_ecd" in data:
        state.target_ecd = float(data["target_ecd"])
    if "bit" in data and data["bit"]:
        b = data["bit"]
        if isinstance(b, dict):
            state.bit = BitParams(**{k: v for k, v in b.items() if k in BitParams.__dataclass_fields__})
    if "lithology" in data and data["lithology"] is not None:
        state.lithology = list(data["lithology"])
    if "temp_profile" in data and data["temp_profile"] is not None:
        state.temp_profile = list(data["temp_profile"])
    if "surge" in data and data["surge"]:
        sg = data["surge"]
        if isinstance(sg, dict):
            state.surge = SurgeSwabParams(**{k: v for k, v in sg.items() if k in SurgeSwabParams.__dataclass_fields__})
    if "pump_fluid_name" in data:
        state.pump_fluid_name = data["pump_fluid_name"]
    if "initial_fluid_name" in data:
        state.initial_fluid_name = data["initial_fluid_name"]
    return state, "Settings imported (replaced matching sections)"


# ─────────────────────────────────────────────────────────────
# Well path / string / well profile
# ─────────────────────────────────────────────────────────────

def export_wellpath(state) -> Dict[str, Any]:
    return {
        "schema": SCHEMA_VERSION,
        "kind": "wellpath",
        "exported_at": _now_utc().isoformat(),
        "columns": ["md", "inc", "azi"],
        "data": copy.deepcopy(state.wellpath or []),
    }


def import_wellpath(state, package: Dict[str, Any]) -> Tuple[Any, str]:
    if package.get("kind") not in ("wellpath", None):
        if package.get("kind"):
            return state, "Rejected: kind must be wellpath"
    cols = package.get("columns") or ["md", "inc", "azi"]
    required = ["md", "inc", "azi"]
    if list(cols)[:3] != required and cols != required:
        # still accept if rows have keys
        pass
    rows = package.get("data") or package.get("rows") or []
    if not isinstance(rows, list):
        return state, "Rejected: data must be a list of stations"
    cleaned = []
    for r in rows:
        if not isinstance(r, dict) or "md" not in r:
            return state, "Rejected: each station needs md, inc, azi"
        cleaned.append({
            "md": float(r.get("md", 0)),
            "inc": float(r.get("inc", 0)),
            "azi": float(r.get("azi", 0)),
        })
    state.wellpath = cleaned  # full replace
    return state, f"Wellpath imported: {len(cleaned)} stations (replaced)"


def export_string_profile(state) -> Dict[str, Any]:
    return {
        "schema": SCHEMA_VERSION,
        "kind": "string_profile",
        "exported_at": _now_utc().isoformat(),
        "columns": ["name", "od", "id", "length", "jt_od", "jt_length", "weight"],
        "data": copy.deepcopy(state.work_string or []),
    }


def import_string_profile(state, package: Dict[str, Any]) -> Tuple[Any, str]:
    if package.get("kind") and package.get("kind") != "string_profile":
        return state, "Rejected: kind must be string_profile"
    rows = package.get("data") or []
    if not isinstance(rows, list) or not rows:
        return state, "Rejected: empty string profile"
    state.work_string = copy.deepcopy(rows)
    return state, f"String profile imported: {len(rows)} joints (replaced)"


def export_well_profile(state) -> Dict[str, Any]:
    g = state.geometry
    geo = g.__dict__.copy() if hasattr(g, "__dict__") else dict(g)
    return {
        "schema": SCHEMA_VERSION,
        "kind": "well_profile",
        "exported_at": _now_utc().isoformat(),
        "data": {
            "geometry": geo,
            "casings": copy.deepcopy(state.casings or []),
            "open_hole": copy.deepcopy(state.open_hole or []),
        },
    }


def import_well_profile(state, package: Dict[str, Any]) -> Tuple[Any, str]:
    if package.get("kind") and package.get("kind") != "well_profile":
        return state, "Rejected: kind must be well_profile"
    data = package.get("data") or {}
    from engines.hydraulics_engine import WellGeometry
    if data.get("geometry"):
        geo = data["geometry"]
        state.geometry = WellGeometry(**{k: v for k, v in geo.items() if k in WellGeometry.__dataclass_fields__})
    if "casings" in data and data["casings"] is not None:
        state.casings = list(data["casings"])
    if "open_hole" in data and data["open_hole"] is not None:
        state.open_hole = list(data["open_hole"])
    return state, "Well profile imported (geometry/casings/OH replaced)"


# ─────────────────────────────────────────────────────────────
# Graph series catalogs
# ─────────────────────────────────────────────────────────────

GRAPH_CATALOG = {
    "pore_pressure": {
        "label": "Pore Pressure tracks",
        "time_key": "time_history",
        "series": {
            "pp_history": "Estimated PP",
            "bhp_history_pp": "BHP",
            "fg_history": "FG",
            "pp_low_history": "PP low",
            "pp_high_history": "PP high",
        },
    },
    "ecd_window": {
        "label": "ECD window",
        "time_key": "time_history",
        "series": {
            "ecd_history_pp": "ECD",
        },
    },
    "hydraulics_history": {
        "label": "Hydraulics history",
        "time_key": None,  # index-based
        "series": {
            "history_bhp": "BHP",
            "history_spp": "Model SPP",
            "history_ecd": "ECD",
            "history_flow": "Flow",
        },
    },
    "main_time": {
        "label": "Main time data",
        "time_key": None,
        "series": {
            "history_bhp": "BHP",
            "history_ecd": "ECD",
            "history_spp": "SPP",
            "history_flow": "Flow",
        },
    },
}


def export_graph_data(
    state,
    graph_id: str,
    t0_iso: Optional[str] = None,
    t1_iso: Optional[str] = None,
) -> Dict[str, Any]:
    if graph_id not in GRAPH_CATALOG:
        raise ValueError(f"Unknown graph_id: {graph_id}")
    meta = GRAPH_CATALOG[graph_id]
    now = _now_utc()
    t0 = _parse_ts(t0_iso) if t0_iso else None
    t1 = _parse_ts(t1_iso) if t1_iso else None
    if t0 and _is_future(t0, now):
        raise ValueError("Start time is in the future – not allowed")
    if t1 and _is_future(t1, now):
        t1 = now  # clamp to now
    if t0 and t1 and t0 > t1:
        raise ValueError("Start time must be <= end time")

    time_key = meta["time_key"]
    times = list(getattr(state, time_key, []) or []) if time_key else None

    # Build column-oriented table aligned by index
    series_names = list(meta["series"].keys())
    columns = (["time"] if times is not None else ["index"]) + series_names
    rows = []

    # length reference
    lengths = []
    for sn in series_names:
        lengths.append(len(getattr(state, sn, []) or []))
    if times is not None:
        lengths.append(len(times))
    n = min(lengths) if lengths else 0

    for i in range(n):
        if times is not None:
            ts_raw = times[i] if i < len(times) else ""
            # time_history may be HH:MM:SS only – treat as labels, window filter soft
            ts = _parse_ts(ts_raw) if "T" in str(ts_raw) or "-" in str(ts_raw) else None
            if ts and _is_future(ts, now):
                continue  # skip future
            if ts and not _in_window(ts, t0, t1):
                continue
            row = {"time": ts_raw}
        else:
            # index-based: optional window by index if t0/t1 given as integers in iso fields
            row = {"index": i}
            if t0_iso and t0_iso.isdigit() and i < int(t0_iso):
                continue
            if t1_iso and t1_iso.isdigit() and i > int(t1_iso):
                continue
        for sn in series_names:
            arr = getattr(state, sn, []) or []
            row[sn] = arr[i] if i < len(arr) else None
        rows.append(row)

    return {
        "schema": SCHEMA_VERSION,
        "kind": "graph_data",
        "graph_id": graph_id,
        "label": meta["label"],
        "exported_at": now.isoformat(),
        "time_window": {"from": t0_iso, "to": t1_iso},
        "columns": columns,
        "series_map": meta["series"],
        "data": rows,
    }


def import_graph_data(state, package: Dict[str, Any]) -> Tuple[Any, str]:
    if package.get("kind") and package.get("kind") != "graph_data":
        return state, "Rejected: kind must be graph_data"
    graph_id = package.get("graph_id")
    if not graph_id or graph_id not in GRAPH_CATALOG:
        return state, "Rejected: unknown or missing graph_id"
    meta = GRAPH_CATALOG[graph_id]
    expected_series = list(meta["series"].keys())
    columns = package.get("columns") or []
    # Order check: time/index first, then series in catalog order
    if columns:
        body = [c for c in columns if c not in ("time", "index")]
        if body != expected_series:
            return state, (
                f"Rejected: column order mismatch. Expected {expected_series}, got {body}. "
                "Export/import must use the same parameter order."
            )
    rows = package.get("data") or []
    if not isinstance(rows, list):
        return state, "Rejected: data must be a list"

    now = _now_utc()
    # Build new series arrays (full replace for this graph's series)
    new_series: Dict[str, List] = {sn: [] for sn in expected_series}
    new_times: List[str] = []
    time_key = meta["time_key"]

    for r in rows:
        if not isinstance(r, dict):
            return state, "Rejected: each row must be an object"
        if time_key:
            ts_raw = r.get("time", "")
            ts = _parse_ts(ts_raw) if ts_raw else None
            if ts and _is_future(ts, now):
                continue  # skip future points
            new_times.append(str(ts_raw))
        for sn in expected_series:
            if sn not in r:
                return state, f"Rejected: missing series column '{sn}' in row"
            new_series[sn].append(r[sn])

    # Replace live history for these series only
    for sn, vals in new_series.items():
        setattr(state, sn, vals)
    if time_key and new_times:
        setattr(state, time_key, new_times)

    return state, f"Graph '{graph_id}' imported: {len(rows)} rows (replaced live series)"


# ─────────────────────────────────────────────────────────────
# Combined full settings+geometry package (optional)
# ─────────────────────────────────────────────────────────────

def export_all_setup(state) -> Dict[str, Any]:
    return {
        "schema": SCHEMA_VERSION,
        "kind": "setup_bundle",
        "exported_at": _now_utc().isoformat(),
        "settings": export_settings(state, "all")["data"],
        "wellpath": export_wellpath(state)["data"],
        "string_profile": export_string_profile(state)["data"],
        "well_profile": export_well_profile(state)["data"],
    }


def import_all_setup(state, package: Dict[str, Any]) -> Tuple[Any, str]:
    if package.get("kind") and package.get("kind") != "setup_bundle":
        return state, "Rejected: kind must be setup_bundle"
    msgs = []
    if package.get("settings"):
        state, m = import_settings(state, {"kind": "settings", "data": package["settings"]})
        msgs.append(m)
    if package.get("wellpath") is not None:
        state, m = import_wellpath(state, {"kind": "wellpath", "data": package["wellpath"]})
        msgs.append(m)
    if package.get("string_profile") is not None:
        state, m = import_string_profile(state, {"kind": "string_profile", "data": package["string_profile"]})
        msgs.append(m)
    if package.get("well_profile") is not None:
        state, m = import_well_profile(state, {"kind": "well_profile", "data": package["well_profile"]})
        msgs.append(m)
    return state, " | ".join(msgs)


def dumps_package(pkg: Dict[str, Any]) -> str:
    return json.dumps(pkg, indent=2, default=str)


def loads_package(raw: str) -> Dict[str, Any]:
    return json.loads(raw)


# ─────────────────────────────────────────────────────────────
# CSV / Excel for graph packages
# ─────────────────────────────────────────────────────────────

def graph_package_to_csv(package: Dict[str, Any]) -> str:
    """Serialize graph_data package rows to CSV text (header = columns order)."""
    import csv
    import io
    cols = package.get("columns") or []
    rows = package.get("data") or []
    buf = io.StringIO()
    # metadata comment lines (import ignores lines starting with #)
    buf.write(f"# ARHPP graph_data schema={package.get('schema', SCHEMA_VERSION)}\n")
    buf.write(f"# graph_id={package.get('graph_id', '')}\n")
    buf.write(f"# label={package.get('label', '')}\n")
    buf.write(f"# exported_at={package.get('exported_at', '')}\n")
    writer = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    writer.writeheader()
    for r in rows:
        writer.writerow({c: r.get(c, "") for c in cols})
    return buf.getvalue()


def graph_csv_to_package(csv_text: str, graph_id: str = None) -> Dict[str, Any]:
    """Parse CSV (with optional # metadata) back to graph_data package."""
    import csv
    import io
    lines = csv_text.splitlines()
    meta = {}
    data_lines = []
    for ln in lines:
        if ln.startswith("#"):
            if "graph_id=" in ln:
                meta["graph_id"] = ln.split("graph_id=", 1)[1].strip()
            elif "schema=" in ln:
                meta["schema"] = ln.split("schema=", 1)[1].strip().replace("ARHPP graph_data ", "")
            continue
        data_lines.append(ln)
    reader = csv.DictReader(io.StringIO("\n".join(data_lines)))
    cols = list(reader.fieldnames or [])
    rows = [dict(r) for r in reader]
    # coerce numerics
    for r in rows:
        for k, v in list(r.items()):
            if k in ("time",):
                continue
            try:
                if v is None or v == "":
                    r[k] = None
                elif "." in str(v):
                    r[k] = float(v)
                else:
                    r[k] = int(v) if str(v).lstrip("-").isdigit() else float(v)
            except Exception:
                pass
    gid = graph_id or meta.get("graph_id") or ""
    return {
        "schema": meta.get("schema", SCHEMA_VERSION),
        "kind": "graph_data",
        "graph_id": gid,
        "label": GRAPH_CATALOG.get(gid, {}).get("label", gid),
        "exported_at": _now_utc().isoformat(),
        "columns": cols,
        "series_map": GRAPH_CATALOG.get(gid, {}).get("series", {}),
        "data": rows,
    }


def graph_package_to_xlsx_bytes(package: Dict[str, Any]) -> bytes:
    """Excel workbook: sheet Data + sheet Meta."""
    import io
    try:
        import openpyxl
    except ImportError:
        # fallback: pure csv bytes with xlsx name not ideal – require openpyxl
        raise ImportError("openpyxl is required for Excel export")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Data"
    cols = package.get("columns") or []
    ws.append(cols)
    for r in package.get("data") or []:
        ws.append([r.get(c, "") for c in cols])
    meta = wb.create_sheet("Meta")
    meta.append(["key", "value"])
    for k in ("schema", "kind", "graph_id", "label", "exported_at"):
        meta.append([k, package.get(k, "")])
    meta.append(["columns", ",".join(cols)])
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def graph_xlsx_to_package(file_bytes: bytes, graph_id: str = None) -> Dict[str, Any]:
    import io
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
    ws = wb["Data"] if "Data" in wb.sheetnames else wb.active
    rows_iter = ws.iter_rows(values_only=True)
    cols = [str(c) for c in next(rows_iter)]
    data = []
    for row in rows_iter:
        if row is None or all(v is None for v in row):
            continue
        data.append({cols[i]: row[i] for i in range(len(cols))})
    gid = graph_id
    if "Meta" in wb.sheetnames:
        for r in wb["Meta"].iter_rows(values_only=True):
            if r and r[0] == "graph_id" and r[1]:
                gid = str(r[1])
    return {
        "schema": SCHEMA_VERSION,
        "kind": "graph_data",
        "graph_id": gid or "",
        "label": GRAPH_CATALOG.get(gid or "", {}).get("label", gid or ""),
        "exported_at": _now_utc().isoformat(),
        "columns": cols,
        "series_map": GRAPH_CATALOG.get(gid or "", {}).get("series", {}),
        "data": data,
    }
