"""
ARHPP Circulation volumes & stroke counts (bit-depth based)

Scientific basis (oilfield standard):
  Pipe capacity (bbl/ft)    ≈ ID² / 1029.4
  Annular capacity (bbl/ft) ≈ (Dh² − Dp²) / 1029.4
  Pump output (gal/stroke)  = n_cyl × (π/4) × L² × S / 231 × η
  bbl/stroke                = gal/stroke / 42

Volumes referenced to **bit depth** (circulation path to bit and back):
  V_string  = capacity inside drillstring from surface to bit
  V_annulus = capacity in annulus from bit to surface
  V_cycle   = V_string + V_annulus   (surface → bit → surface)

Stroke counts use the **Main** pump only (Setup › pump_state == "Main"):
  Down strokes      = V_string  / bbl_per_stroke_main
  Bottoms-up strokes = V_annulus / bbl_per_stroke_main
  Cycle strokes      = Down + Bottoms-up

Live stroke counters integrate SPM × Δt for each pump; Main total is summed.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timezone
import math


def _pipe_cap_bbl_ft(id_in: float) -> float:
    d = max(float(id_in), 0.1)
    return (d * d) / 1029.4


def _ann_cap_bbl_ft(hole_id: float, pipe_od: float) -> float:
    dh = max(float(hole_id), 0.1)
    dp = max(float(pipe_od), 0.0)
    return max(dh * dh - dp * dp, 0.0) / 1029.4


def gal_per_stroke_from_pump(p: Dict) -> float:
    """Theoretical pump displacement per stroke (gal/stk) with efficiency."""
    liner = float(p.get("liner_in", 4.75) or 4.75)
    stroke = float(p.get("stroke_in", 12.0) or 12.0)
    eff = float(p.get("efficiency", 96) or 96) / 100.0
    ptype = str(p.get("pump_type", "Triplex") or "Triplex")
    if ptype == "Duplex":
        n_cyl = 2
    elif ptype in ("Quintuplex", "Penta"):
        n_cyl = 5
    else:
        n_cyl = 3
    # precomputed field preferred
    g = float(p.get("output_gal_stk") or 0)
    if g > 0:
        return g
    # gal = n × (π/4) × L²(in) × S(in) / 231 × η
    gal = n_cyl * (math.pi / 4.0) * (liner ** 2) * stroke / 231.0 * eff
    return gal


def bbl_per_stroke_from_pump(p: Dict) -> float:
    return gal_per_stroke_from_pump(p) / 42.0


def get_main_pumps(state) -> List[Dict]:
    """Pumps marked Main in Setup surface equipment (active)."""
    out = []
    for e in (state.surface_equipment or []):
        if e.get("type") != "Pump":
            continue
        if not e.get("active", True):
            continue
        if str(e.get("pump_state", "")).lower() == "main":
            out.append(e)
    return out


def get_main_pump(state) -> Optional[Dict]:
    mains = get_main_pumps(state)
    if mains:
        return mains[0]
    # fallback: first active pump with SPM > 0
    for e in (state.surface_equipment or []):
        if e.get("type") == "Pump" and e.get("active", True) and float(e.get("spm", 0) or 0) > 0:
            return e
    pumps = [e for e in (state.surface_equipment or []) if e.get("type") == "Pump"]
    return pumps[0] if pumps else None


def compute_well_volumes(state) -> Dict[str, float]:
    """String & annulus volumes (bbl) from surface to bit depth."""
    g = state.geometry
    bit = max(float(g.bit_depth), 1.0)

    # Prefer sectional totals if available (already to bit)
    v_pipe = float(getattr(state, "pipe_capacity_bbl", 0) or 0)
    v_ann = float(getattr(state, "ann_capacity_bbl", 0) or 0)

    if v_pipe <= 0:
        # work_string cumulative to bit
        try:
            from engines.sectional_physics import build_string_sections, total_pipe_capacity_bbl
            secs = build_string_sections(state.work_string, bit)
            v_pipe = total_pipe_capacity_bbl(secs)
        except Exception:
            v_pipe = _pipe_cap_bbl_ft(float(g.pipe_id)) * bit

    if v_ann <= 0:
        try:
            from engines.sectional_physics import build_string_sections, build_annulus_sections, total_ann_capacity_bbl
            ssecs = build_string_sections(state.work_string, bit)
            asecs = build_annulus_sections(state.casings or [], state.open_hole or [], ssecs, bit, float(g.hole_id))
            v_ann = total_ann_capacity_bbl(asecs)
        except Exception:
            v_ann = _ann_cap_bbl_ft(float(g.hole_id), float(g.pipe_od)) * bit

    return {
        "bit_depth_ft": bit,
        "string_volume_bbl": v_pipe,
        "annular_volume_bbl": v_ann,
        "cycle_volume_bbl": v_pipe + v_ann,
    }


def compute_stroke_targets(state) -> Dict[str, Any]:
    """Down / Bottoms-up / Cycle stroke counts for Main pump."""
    vols = compute_well_volumes(state)
    main = get_main_pump(state)
    if not main:
        return {
            **vols,
            "main_pump": None,
            "gal_per_stroke": 0.0,
            "bbl_per_stroke": 0.0,
            "strokes_to_bottom": 0.0,
            "strokes_bottoms_up": 0.0,
            "cycle_strokes": 0.0,
        }
    gps = gal_per_stroke_from_pump(main)
    bps = gps / 42.0
    if bps <= 1e-9:
        down = up = cycle = 0.0
    else:
        down = vols["string_volume_bbl"] / bps
        up = vols["annular_volume_bbl"] / bps
        cycle = down + up
    return {
        **vols,
        "main_pump": main.get("name", "Main"),
        "gal_per_stroke": gps,
        "bbl_per_stroke": bps,
        "strokes_to_bottom": down,
        "strokes_bottoms_up": up,
        "cycle_strokes": cycle,
    }


def _ensure_counters(state) -> Dict[str, float]:
    c = getattr(state, "stroke_counters", None)
    if not isinstance(c, dict):
        c = {}
        state.stroke_counters = c
    c.setdefault("per_pump", {})
    c.setdefault("main_total", 0.0)
    c.setdefault("last_ts", "")
    return c


def reset_stroke_counters(state) -> Any:
    c = _ensure_counters(state)
    c["per_pump"] = {}
    c["main_total"] = 0.0
    c["last_ts"] = datetime.now(timezone.utc).isoformat()
    state.stroke_counters = c
    state.operating.total_strokes = 0.0
    return state


def update_stroke_counters(state, dt_min: Optional[float] = None) -> Any:
    """Integrate SPM × minutes for each pump; accumulate Main total.

    If dt_min is None, uses wall-clock Δt since last update (capped).
    """
    c = _ensure_counters(state)
    now = datetime.now(timezone.utc)
    if dt_min is None:
        last = c.get("last_ts") or ""
        dt_min = 0.05
        if last:
            try:
                t0 = datetime.fromisoformat(last)
                if t0.tzinfo is None:
                    t0 = t0.replace(tzinfo=timezone.utc)
                dt_min = max((now - t0).total_seconds() / 60.0, 0.0)
                if dt_min > 2.0:
                    dt_min = 0.05
            except Exception:
                dt_min = 0.05
    c["last_ts"] = now.isoformat()

    main_names = {p.get("name") for p in get_main_pumps(state)}
    main_add = 0.0
    for e in (state.surface_equipment or []):
        if e.get("type") != "Pump" or not e.get("active", True):
            continue
        name = e.get("name", "?")
        spm = float(e.get("spm", 0) or 0)
        if spm <= 0:
            continue
        add = spm * float(dt_min)
        per = c["per_pump"]
        per[name] = float(per.get(name, 0.0)) + add
        if name in main_names:
            main_add += add
    c["main_total"] = float(c.get("main_total", 0.0)) + main_add
    state.stroke_counters = c
    # legacy field = main total
    state.operating.total_strokes = float(c["main_total"])
    return state


def apply_stroke_volume_results(state) -> Any:
    """Write targets + update counters onto state for UI / diagnostics."""
    targets = compute_stroke_targets(state)
    state.string_volume_bbl = targets["string_volume_bbl"]
    state.annular_volume_bbl = targets["annular_volume_bbl"]
    state.cycle_volume_bbl = targets["cycle_volume_bbl"]
    state.strokes_to_bottom = targets["strokes_to_bottom"]
    state.strokes_bottoms_up = targets["strokes_bottoms_up"]
    state.cycle_strokes = targets["cycle_strokes"]
    state.main_pump_name = targets.get("main_pump") or ""
    state.main_gal_per_stroke = targets.get("gal_per_stroke") or 0.0
    state.main_bbl_per_stroke = targets.get("bbl_per_stroke") or 0.0
    state = update_stroke_counters(state)
    return state
