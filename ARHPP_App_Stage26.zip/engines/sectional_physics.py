"""
ARHPP Sectional Physics Core – Stage 23 (Phase 3)

Section builder · true capacities · sectional friction · survey hydrostatic
Pressure ledger · U-Tube root solver · loss-location flow distribution

PROTOTYPE – improved physics vs Stage 21/22 but still not field-validated.
"""

from __future__ import annotations
from typing import List, Dict, Any, Optional, Tuple
import math


# ─────────────────────────────────────────────────────────────
# Capacity helpers (bbl/ft)
# ─────────────────────────────────────────────────────────────

def pipe_cap_bbl_ft(id_in: float) -> float:
    return max((float(id_in) ** 2) / 1029.4, 1e-9)


def ann_cap_bbl_ft(hole_id: float, pipe_od: float) -> float:
    return max((float(hole_id) ** 2 - float(pipe_od) ** 2) / 1029.4, 1e-9)


# ─────────────────────────────────────────────────────────────
# Section builders
# ─────────────────────────────────────────────────────────────

def build_string_sections(work_string: List[Dict], bit_depth: float) -> List[Dict]:
    """Build pipe sections from work string (bit at index 0 = bottom).

    Returns list ordered surface→bit:
      md_top, md_bot, id_in, od_in, body, desc, len_ft, bbl_per_ft
    """
    if not work_string:
        # fallback single section
        return [{
            "md_top": 0.0, "md_bot": float(bit_depth),
            "id_in": 4.276, "od_in": 5.0,
            "body": "DP", "desc": "Drillpipe",
            "len_ft": float(bit_depth), "bbl_per_ft": pipe_cap_bbl_ft(4.276),
        }]

    # work_string index 0 = bit (bottom). Expand by qty, accumulate from bit up.
    expanded = []
    for row in work_string:
        qty = max(int(row.get("qty", 1) or 1), 1)
        for _ in range(qty):
            expanded.append(dict(row))

    sections_bottom_up = []
    cursor = float(bit_depth)
    for row in expanded:
        length = max(float(row.get("len_ft", 0) or 0), 0.01)
        od = float(row.get("od_in", 5.0) or 5.0)
        id_in = float(row.get("id_in", 4.0) or 4.0)
        bot = cursor
        top = max(cursor - length, 0.0)
        sections_bottom_up.append({
            "md_top": top, "md_bot": bot,
            "id_in": id_in, "od_in": od,
            "body": str(row.get("body", "DP")),
            "desc": str(row.get("desc", "")),
            "len_ft": bot - top,
            "bbl_per_ft": pipe_cap_bbl_ft(id_in),
        })
        cursor = top
        if cursor <= 0:
            break

    # If string shorter than bit depth, fill remaining with last DP-like section
    if cursor > 0.5:
        last_id = sections_bottom_up[-1]["id_in"] if sections_bottom_up else 4.276
        last_od = sections_bottom_up[-1]["od_in"] if sections_bottom_up else 5.0
        sections_bottom_up.append({
            "md_top": 0.0, "md_bot": cursor,
            "id_in": last_id, "od_in": last_od,
            "body": "DP", "desc": "Drillpipe (fill)",
            "len_ft": cursor, "bbl_per_ft": pipe_cap_bbl_ft(last_id),
        })

    # return surface → bit
    sections = list(reversed(sections_bottom_up))
    return sections


def _hole_id_at_md(open_hole: List[Dict], casings: List[Dict], md: float, fallback: float = 8.5) -> float:
    for h in (open_hole or []):
        top = float(h.get("md_top", 0) or 0)
        bot = float(h.get("md_bot", 0) or 0)
        if top <= md <= bot + 0.1:
            return float(h.get("hole_id_in", fallback) or fallback)
    # inside casing: use casing ID as "hole"
    for c in reversed(casings or []):
        top = float(c.get("md_top", 0) or 0)
        bot = float(c.get("md_bot", 0) or 0)
        if top <= md <= bot + 0.1:
            return float(c.get("id_in", fallback) or fallback)
    return fallback


def _pipe_od_at_md(string_sections: List[Dict], md: float, fallback: float = 5.0) -> float:
    for s in string_sections:
        if s["md_top"] - 0.1 <= md <= s["md_bot"] + 0.1:
            return float(s["od_in"])
    return fallback


def build_annulus_sections(
    casings: List[Dict],
    open_hole: List[Dict],
    string_sections: List[Dict],
    bit_depth: float,
    step_ft: float = 100.0,
) -> List[Dict]:
    """Annular sections with local hole_id and local pipe_od.

    Breaks at casing shoes, OH changes, and string OD changes.
    """
    bit = float(bit_depth)
    if bit <= 1:
        return []

    # Collect breakpoints
    breaks = {0.0, bit}
    for c in (casings or []):
        breaks.add(float(c.get("md_top", 0) or 0))
        breaks.add(float(c.get("md_bot", 0) or 0))
    for h in (open_hole or []):
        breaks.add(float(h.get("md_top", 0) or 0))
        breaks.add(float(h.get("md_bot", 0) or 0))
    for s in (string_sections or []):
        breaks.add(float(s["md_top"]))
        breaks.add(float(s["md_bot"]))

    # Also sample every step_ft for smoother geometry
    md = 0.0
    while md < bit:
        breaks.add(md)
        md += step_ft
    breaks = sorted(b for b in breaks if 0 <= b <= bit + 0.01)

    sections = []
    for i in range(len(breaks) - 1):
        top = breaks[i]
        bot = breaks[i + 1]
        if bot - top < 0.05:
            continue
        mid = 0.5 * (top + bot)
        hole = _hole_id_at_md(open_hole, casings, mid)
        pod = _pipe_od_at_md(string_sections, mid)
        # ensure hole > pipe
        if hole <= pod:
            hole = pod + 0.25
        sections.append({
            "md_top": top, "md_bot": bot,
            "hole_id": hole, "pipe_od": pod,
            "len_ft": bot - top,
            "bbl_per_ft": ann_cap_bbl_ft(hole, pod),
        })
    return sections


def total_pipe_capacity_bbl(string_sections: List[Dict]) -> float:
    return sum(s["len_ft"] * s["bbl_per_ft"] for s in string_sections)


def total_ann_capacity_bbl(ann_sections: List[Dict]) -> float:
    return sum(s["len_ft"] * s["bbl_per_ft"] for s in ann_sections)


# ─────────────────────────────────────────────────────────────
# Sectional friction (HB practical model, no artificial caps)
# ─────────────────────────────────────────────────────────────

def _ann_velocity(q_gpm: float, hole_id: float, pipe_od: float) -> float:
    denom = hole_id ** 2 - pipe_od ** 2
    if denom <= 0:
        return 0.0
    return 0.4085 * q_gpm / denom


def _pipe_velocity(q_gpm: float, pipe_id: float) -> float:
    if pipe_id <= 0:
        return 0.0
    return 0.4085 * q_gpm / (pipe_id ** 2)


def section_pipe_friction(q: float, dens: float, pipe_id: float, length: float, n: float, K: float) -> float:
    if pipe_id <= 0 or length <= 0 or q <= 0:
        return 0.0
    v = _pipe_velocity(q, pipe_id)
    if v <= 0:
        return 0.0
    gamma = max((8.0 * v) / max(pipe_id, 0.15), 1.0)
    mu_app = max(min(K * 478.8 * (gamma ** (n - 1.0)) + 1.0, 250.0), 3.0)
    re = 928.0 * dens * v * pipe_id / mu_app
    f = 16.0 / max(re, 10.0) if re < 2100 else 0.079 / (re ** 0.25)
    dp_per_ft = f * dens * (v ** 2) / (21.1 * pipe_id)
    mud_factor = 0.7 + 0.3 * (K / 0.5) * (0.75 / max(n, 0.3))
    return max(dp_per_ft * length * mud_factor * 0.55, 0.0)


def section_ann_friction(
    q: float, dens: float, hole_id: float, pipe_od: float,
    length: float, n: float, K: float, rpm: float = 0.0,
) -> float:
    dh = hole_id - pipe_od
    if dh <= 0 or length <= 0 or q <= 0:
        return 0.0
    v = _ann_velocity(q, hole_id, pipe_od)
    if v <= 0:
        return 0.0
    gamma = max((12.0 * v) / max(dh, 0.15), 1.0)
    mu_app = max(min(K * 478.8 * (gamma ** (n - 1.0)) + 1.0, 250.0), 3.0)
    re = 928.0 * dens * v * dh / mu_app
    f = 16.0 / max(re, 10.0) if re < 2100 else 0.079 / (re ** 0.25)
    dp_per_ft = f * dens * (v ** 2) / (21.1 * dh)
    mud_factor = 0.7 + 0.3 * (K / 0.5) * (0.75 / max(n, 0.3))
    # Mild rotation correction (prototype – eccentricity not modelled)
    rpm_factor = 1.0 + 0.02 * (rpm / 120.0)
    return max(dp_per_ft * length * mud_factor * rpm_factor, 0.0)


def sectional_pipe_friction(
    string_sections: List[Dict], q: float, dens: float, n: float, K: float,
) -> Tuple[float, List[Dict]]:
    """Returns (total_psi, per-section detail)."""
    total = 0.0
    details = []
    for s in string_sections:
        dp = section_pipe_friction(q, dens, s["id_in"], s["len_ft"], n, K)
        total += dp
        details.append({**s, "q_gpm": q, "dp_psi": dp, "path": "pipe"})
    return total, details


def sectional_annular_friction(
    ann_sections: List[Dict],
    q_by_md: Optional[callable],
    dens: float, n: float, K: float, rpm: float = 0.0,
    default_q: float = 0.0,
) -> Tuple[float, List[Dict]]:
    """q_by_md(mid_md) → local annular flow. If None, use default_q everywhere."""
    total = 0.0
    details = []
    for s in ann_sections:
        mid = 0.5 * (s["md_top"] + s["md_bot"])
        q = float(q_by_md(mid)) if q_by_md else default_q
        dp = section_ann_friction(q, dens, s["hole_id"], s["pipe_od"], s["len_ft"], n, K, rpm)
        total += dp
        details.append({**s, "q_gpm": q, "dp_psi": dp, "path": "annulus"})
    return total, details


# ─────────────────────────────────────────────────────────────
# Loss-location flow distribution
# ─────────────────────────────────────────────────────────────

def make_annulus_flow_profile(
    q_in: float, q_out: float, loss_md: float, bit_depth: float,
) -> callable:
    """Assume single loss zone at loss_md.

    Below loss (deeper): flow ≈ q_in
    Above loss (shallower): flow ≈ q_out = q_in - q_loss
    """
    q_in = max(float(q_in), 0.0)
    q_out = max(float(q_out), 0.0)
    loss_md = float(loss_md)
    bit = float(bit_depth)

    def q_at(md: float) -> float:
        # md increases with depth
        if md >= loss_md - 0.5:
            return q_in  # below / at loss toward bit
        return q_out  # above loss toward surface

    return q_at


# ─────────────────────────────────────────────────────────────
# Survey-based hydrostatic from fluid column
# ─────────────────────────────────────────────────────────────

def hydrostatic_column_survey(
    col: List[Dict],
    wellpath_computed: Optional[List[Dict]],
    tvd_at_md_fn,
    tvd_ratio_fallback: float = 1.0,
) -> float:
    """Σ 0.052 × MW × ΔTVD using survey when available."""
    h = 0.0
    for seg in col or []:
        md_top = float(seg["md_top"])
        md_bot = float(seg["md_bot"])
        if md_bot <= md_top:
            continue
        dens = float(seg.get("density_ppg", 10.0))
        if wellpath_computed and tvd_at_md_fn:
            tvd_top = tvd_at_md_fn(wellpath_computed, md_top)
            tvd_bot = tvd_at_md_fn(wellpath_computed, md_bot)
            dtvd = abs(tvd_bot - tvd_top)
        else:
            dtvd = (md_bot - md_top) * tvd_ratio_fallback
        h += 0.052 * dens * dtvd
    return h


# ─────────────────────────────────────────────────────────────
# System ΔP(Q) for U-Tube root solve
# ─────────────────────────────────────────────────────────────

def system_delta_p(
    q: float,
    dens: float,
    n: float,
    K: float,
    string_sections: List[Dict],
    ann_sections: List[Dict],
    tfa: float,
    surface_dp_fn,
    rpm: float = 0.0,
) -> float:
    """Total frictional + bit resistance for flow Q (gpm) through closed U-tube path."""
    q = abs(float(q))
    if q < 1e-6:
        return 0.0
    pipe_dp, _ = sectional_pipe_friction(string_sections, q, dens, n, K)
    ann_dp, _ = sectional_annular_friction(ann_sections, None, dens, n, K, rpm, default_q=q)
    # bit
    bit_dp = (q ** 2 * dens) / (12031.0 * max(tfa, 0.05) ** 2) if tfa > 0 else 0.0
    surf = 0.0
    try:
        surf = float(surface_dp_fn(q)) if surface_dp_fn else 0.0
    except Exception:
        surf = 0.0
    return pipe_dp + ann_dp + bit_dp + surf


def solve_utube_flow(
    hyd_pipe: float,
    hyd_ann: float,
    sbp: float,
    dens: float,
    n: float,
    K: float,
    string_sections: List[Dict],
    ann_sections: List[Dict],
    tfa: float,
    surface_dp_fn=None,
    rpm: float = 0.0,
    q_max: float = 800.0,
    tol: float = 0.5,
) -> Tuple[float, float, str]:
    """Solve pumps-off U-tube flow by bisection.

    Residual: (hyd_pipe - hyd_ann - sbp) - sign-consistent system ΔP(Q) = 0

    Convention:
      driving_dp = hyd_pipe - hyd_ann - sbp
      If driving_dp > 0: fluid driven pipe→annulus (string heavier / higher head)
      If driving_dp < 0: fluid driven annulus→pipe

    Returns (q_utube_gpm, residual_psi, status_msg)
    q_utube > 0 means flow from pipe into annulus (free-fall direction when string heavier).
    """
    driving = float(hyd_pipe) - float(hyd_ann) - float(sbp)

    if abs(driving) < 1.0:
        return 0.0, driving, "balanced"

    # System resistance always opposes flow; we solve |driving| = ΔP_system(|Q|)
    target = abs(driving)

    def residual(q):
        return system_delta_p(q, dens, n, K, string_sections, ann_sections, tfa, surface_dp_fn, rpm) - target

    # Bracket
    lo, hi = 0.0, max(q_max, 50.0)
    r_lo = residual(lo)  # -target < 0
    r_hi = residual(hi)
    # Expand hi if needed
    expands = 0
    while r_hi < 0 and expands < 8:
        hi *= 1.8
        r_hi = residual(hi)
        expands += 1

    if r_hi < 0:
        # System too weak even at high Q – return hi as estimate
        q_sol = hi if driving > 0 else -hi
        return q_sol, residual(hi), "q_at_limit"

    # Bisection
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        r_mid = residual(mid)
        if abs(r_mid) < tol or (hi - lo) < 0.05:
            q_mag = mid
            break
        if r_mid < 0:
            lo = mid
        else:
            hi = mid
    else:
        q_mag = 0.5 * (lo + hi)

    q_signed = q_mag if driving > 0 else -q_mag
    return q_signed, residual(q_mag), "solved"


# ─────────────────────────────────────────────────────────────
# Pressure ledger
# ─────────────────────────────────────────────────────────────

def build_pressure_ledger(
    ann_hydro: float,
    ann_friction: float,
    sbp: float,
    pipe_hydro: float,
    pipe_friction: float,
    bit_dp: float,
    surface_dp: float,
    surge_psi: float = 0.0,
    swab_psi: float = 0.0,
    gas_void_psi: float = 0.0,
    u_tube_dp: float = 0.0,
    tvd: float = 1.0,
) -> Dict[str, Any]:
    """Annular path BHP ledger + SPP path components."""
    bhp = ann_hydro + ann_friction + sbp + surge_psi + swab_psi + gas_void_psi
    ecd = bhp / (0.052 * tvd) if tvd > 1 else 0.0
    # SPP model: surface + pipe + bit + ann + sbp + hydro imbalance (pipe heavier adds demand)
    hydro_imbalance = max(pipe_hydro - ann_hydro, 0.0)
    model_spp = surface_dp + pipe_friction + bit_dp + ann_friction + sbp + hydro_imbalance

    ledger = {
        "annular_hydrostatic_psi": round(ann_hydro, 1),
        "annular_friction_psi": round(ann_friction, 1),
        "sbp_psi": round(sbp, 1),
        "surge_psi": round(surge_psi, 1),
        "swab_psi": round(swab_psi, 1),
        "gas_void_effect_psi": round(gas_void_psi, 1),
        "bhp_psi": round(bhp, 1),
        "ecd_ppg": round(ecd, 3),
        "pipe_hydrostatic_psi": round(pipe_hydro, 1),
        "pipe_friction_psi": round(pipe_friction, 1),
        "bit_dp_psi": round(bit_dp, 1),
        "surface_friction_psi": round(surface_dp, 1),
        "hydro_imbalance_psi": round(hydro_imbalance, 1),
        "u_tube_dp_psi": round(u_tube_dp, 1),
        "model_spp_psi": round(model_spp, 1),
    }
    return ledger


def run_sectional_hydraulics(
    state,
    compute_wellpath_fn,
    wellpath_tvd_fn,
    surface_piping_fn,
) -> Any:
    """Phase 3 core: replace single-geometry friction/hydro with sectional models.

    Mutates and returns state.
    """
    g = state.geometry
    f = state.fluid
    o = state.operating
    b = state.bit

    # 1) Section builder
    string_secs = build_string_sections(state.work_string, g.bit_depth)
    ann_secs = build_annulus_sections(state.casings, state.open_hole, string_secs, g.bit_depth)
    state.string_sections = string_secs
    state.annulus_sections = ann_secs
    state.pipe_capacity_bbl = total_pipe_capacity_bbl(string_secs)
    state.ann_capacity_bbl = total_ann_capacity_bbl(ann_secs)

    # 2) Survey
    wp = None
    if state.wellpath and len(state.wellpath) >= 2:
        try:
            wp = compute_wellpath_fn(state.wellpath)
        except Exception:
            wp = None
    tvd_ratio = (g.tvd / g.md) if g.md > 1 else 1.0

    # 3) Hydrostatics from columns
    ann_hydro = hydrostatic_column_survey(
        state.ann_column, wp, wellpath_tvd_fn, tvd_ratio,
    ) if state.ann_column else 0.052 * state.corrected_density * g.tvd
    pipe_hydro = hydrostatic_column_survey(
        state.pipe_column, wp, wellpath_tvd_fn, tvd_ratio,
    ) if state.pipe_column else 0.052 * state.corrected_density * g.tvd

    state.hydrostatic = ann_hydro
    state.pipe_hydrostatic = pipe_hydro
    state.u_tube_dp = ann_hydro - pipe_hydro  # >0 annulus heavier

    # 4) Loss-aware flow distribution
    q_in = max(float(o.flow_in_gpm), 0.0)
    q_out = max(float(o.flow_out_gpm), 0.0)
    q_loss = max(q_in - q_out, 0.0)
    state.q_loss = q_loss
    # Default loss location near bit (open hole); user can later set loss_md
    loss_md = float(getattr(state, "loss_md", g.bit_depth) or g.bit_depth)
    q_ann_fn = make_annulus_flow_profile(q_in, q_out, loss_md, g.bit_depth)

    # Pipe/bit still see q_in (losses assumed downstream of bit / in open hole)
    q_pipe = q_in
    state.effective_flow = q_pipe  # representative

    # 5) Sectional friction
    dens = float(state.corrected_density or f.density_ppg)
    n = float(f.n)
    K = float(f.K)
    # viscosity temp factor already applied upstream into K if needed – use as-is
    pipe_dp, pipe_details = sectional_pipe_friction(string_secs, q_pipe, dens, n, K)
    ann_dp, ann_details = sectional_annular_friction(
        ann_secs, q_ann_fn, dens, n, K, rpm=float(o.rpm), default_q=q_out,
    )
    state.pipe_friction = pipe_dp
    state.annular_friction = ann_dp
    state.section_friction_detail = pipe_details + ann_details

    # 6) Bit
    tfa = float(b.tfa or 0.85)
    bit_dp = (q_pipe ** 2 * dens) / (12031.0 * max(tfa, 0.05) ** 2) if q_pipe > 0 else 0.0
    state.bit_pressure_drop = bit_dp

    # 7) Surface (active path only)
    def _surf(q):
        return surface_piping_fn(state.piping, q, dens, n, K)

    state.surface_friction = _surf(q_pipe)

    # 8) U-Tube root solver (pumps-off or low flow)
    pumps_off = q_in < 5.0
    if pumps_off or abs(state.u_tube_dp) > 30:
        q_ut, resid, status = solve_utube_flow(
            hyd_pipe=pipe_hydro,
            hyd_ann=ann_hydro,
            sbp=float(o.sbp_setpoint),
            dens=dens, n=n, K=K,
            string_sections=string_secs,
            ann_sections=ann_secs,
            tfa=tfa,
            surface_dp_fn=_surf,
            rpm=float(o.rpm),
        )
        state.q_utube = q_ut
        state.u_tube_status = status
        state.u_tube_residual = resid
    else:
        state.q_utube = 0.0
        state.u_tube_status = "pumps_on_skip"
        state.u_tube_residual = 0.0

    # 9) Pressure ledger → BHP / ECD / Model SPP
    ledger = build_pressure_ledger(
        ann_hydro=ann_hydro,
        ann_friction=ann_dp,
        sbp=float(o.sbp_setpoint),
        pipe_hydro=pipe_hydro,
        pipe_friction=pipe_dp,
        bit_dp=bit_dp,
        surface_dp=state.surface_friction,
        surge_psi=0.0,
        swab_psi=0.0,
        gas_void_psi=0.0,
        u_tube_dp=state.u_tube_dp,
        tvd=float(g.tvd) or 1.0,
    )
    state.pressure_ledger = ledger
    state.bhp = ledger["bhp_psi"]
    state.ecd = ledger["ecd_ppg"]
    state.model_spp = ledger["model_spp_psi"]

    return state
