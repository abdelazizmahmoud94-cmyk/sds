"""
ICU Virtual Trip Tank – Victus-style flow imbalance integrator.

While RUNNING:
  gain_rate_gpm = (Flow_Out − Flow_In) − zero_adjust_gpm
  dV_bbl = gain_rate_gpm × Δt_min / 42

Controls:
  Start / Stop  – integrate only while running
  Reset         – zero volume & timer (keeps zero_adjust)

PROTOTYPE – educational; not a certified trip-tank system.
"""

from __future__ import annotations
from typing import Any, Dict, Optional
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse(iso: str) -> Optional[datetime]:
    if not iso:
        return None
    try:
        dt = datetime.fromisoformat(iso)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def ensure_trip_tank(state) -> Dict[str, Any]:
    tt = getattr(state, "trip_tank", None)
    if not isinstance(tt, dict):
        tt = {}
    tt.setdefault("running", False)
    tt.setdefault("zero_adjust_gpm", 0.0)
    tt.setdefault("total_volume_bbl", 0.0)
    tt.setdefault("elapsed_sec", 0.0)
    tt.setdefault("started_at", "")
    tt.setdefault("last_ts", "")
    tt.setdefault("gain_rate_gpm", 0.0)
    state.trip_tank = tt
    return tt


def start_trip_tank(state) -> Any:
    tt = ensure_trip_tank(state)
    now = _now()
    tt["running"] = True
    if not tt.get("started_at"):
        tt["started_at"] = now.isoformat()
    tt["last_ts"] = now.isoformat()
    state.trip_tank = tt
    return state


def stop_trip_tank(state) -> Any:
    tt = ensure_trip_tank(state)
    # final tick
    state = update_trip_tank(state)
    tt = ensure_trip_tank(state)
    tt["running"] = False
    tt["last_ts"] = ""
    state.trip_tank = tt
    return state


def reset_trip_tank(state) -> Any:
    tt = ensure_trip_tank(state)
    za = float(tt.get("zero_adjust_gpm", 0) or 0)
    state.trip_tank = {
        "running": False,
        "zero_adjust_gpm": za,
        "total_volume_bbl": 0.0,
        "elapsed_sec": 0.0,
        "started_at": "",
        "last_ts": "",
        "gain_rate_gpm": 0.0,
    }
    return state


def update_trip_tank(state) -> Any:
    """Integrate while running using wall-clock Δt."""
    tt = ensure_trip_tank(state)
    o = state.operating
    q_in = float(o.flow_in_gpm)
    q_out = float(o.flow_out_gpm)
    za = float(tt.get("zero_adjust_gpm", 0) or 0)
    # Positive volume = net gain at surface (returns exceed pumped) after zero adjust
    gain_rate = (q_out - q_in) - za
    tt["gain_rate_gpm"] = gain_rate

    if not tt.get("running"):
        state.trip_tank = tt
        return state

    now = _now()
    last = _parse(tt.get("last_ts") or "")
    dt_sec = 0.0
    if last is not None:
        dt_sec = max((now - last).total_seconds(), 0.0)
        if dt_sec > 120:  # gap after pause/load
            dt_sec = 0.0
    else:
        dt_sec = 0.0

    tt["last_ts"] = now.isoformat()
    if not tt.get("started_at"):
        tt["started_at"] = now.isoformat()

    if dt_sec > 0:
        dt_min = dt_sec / 60.0
        d_bbl = gain_rate * dt_min / 42.0
        tt["total_volume_bbl"] = float(tt.get("total_volume_bbl", 0) or 0) + d_bbl
        tt["elapsed_sec"] = float(tt.get("elapsed_sec", 0) or 0) + dt_sec

    state.trip_tank = tt
    # mirror convenience fields
    state.trip_tank_volume_bbl = float(tt["total_volume_bbl"])
    state.trip_tank_gain_rate_gpm = float(tt["gain_rate_gpm"])
    state.trip_tank_elapsed_sec = float(tt["elapsed_sec"])
    return state


def format_elapsed(sec: float) -> str:
    sec = int(max(sec, 0))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"
