"""
ARHPP Estimated Pore Pressure – Stage 25 (Phase 5)

Each method returns:
  estimate_psi, uncertainty_psi, applicability (0–1), data_quality (0–1),
  calibration_status, reason_codes

Fusion: inverse-variance × applicability × data_quality (not fixed weights).

PROTOTYPE – Estimated PP only, not measured pore pressure.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Tuple
import math


@dataclass
class PPMethodResult:
    name: str
    estimate_psi: float
    uncertainty_psi: float
    applicability: float      # 0–1
    data_quality: float       # 0–1
    calibration_status: str   # uncalibrated | provisional | calibrated
    reason_codes: List[str] = field(default_factory=list)
    notes: str = ""

    @property
    def weight(self) -> float:
        """Inverse-variance weight scaled by applicability and data quality."""
        sig2 = max(self.uncertainty_psi, 50.0) ** 2
        return (1.0 / sig2) * max(self.applicability, 0.01) * max(self.data_quality, 0.01)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["weight"] = round(self.weight, 8)
        return d


def _ppg_to_psi(ppg: float, tvd: float) -> float:
    return 0.052 * float(ppg) * max(float(tvd), 1.0)


def _psi_to_ppg(psi: float, tvd: float) -> float:
    tvd = max(float(tvd), 1.0)
    return float(psi) / (0.052 * tvd)


# ─────────────────────────────────────────────────────────────
# Individual methods
# ─────────────────────────────────────────────────────────────

def method_formation_table(state) -> PPMethodResult:
    """Uses user-entered formation PPG at current depth.

    This is a look-up, not a prediction – high weight only if user marks
    calibrated; otherwise treated as prior with larger uncertainty.
    """
    from engines.hydraulics_engine import get_formation_at_depth

    g = state.geometry
    tvd = max(g.tvd, 1.0)
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    ppg = float(form.get("ppg", 9.0) or 9.0)
    est = _ppg_to_psi(ppg, tvd)
    # User table: useful prior but not a live measurement
    cal = str(form.get("calibration_status", "provisional") or "provisional")
    if cal not in ("uncalibrated", "provisional", "calibrated"):
        cal = "provisional"
    # Uncertainty: ±0.5 ppg provisional, ±0.25 calibrated, ±1.0 uncalibrated
    u_ppg = {"calibrated": 0.25, "provisional": 0.50, "uncalibrated": 1.0}.get(cal, 0.5)
    unc = _ppg_to_psi(u_ppg, tvd)
    dq = {"calibrated": 0.9, "provisional": 0.6, "uncalibrated": 0.35}.get(cal, 0.5)
    return PPMethodResult(
        name="Formation table",
        estimate_psi=est,
        uncertainty_psi=unc,
        applicability=0.9,
        data_quality=dq,
        calibration_status=cal,
        reason_codes=["FORMATION_LOOKUP", f"FORM={form.get('name', '?')}"],
        notes=f"PPG={ppg:.2f} at TVD={tvd:.0f} ft",
    )


def method_dexponent(state) -> PPMethodResult:
    """Corrected d-exponent (Eaton-style) – only applicable while drilling on-bottom."""
    from engines.hydraulics_engine import (
        compute_d_exponent, compute_dc_exponent, pp_from_dexponent,
    )

    g, o, b, f = state.geometry, state.operating, state.bit, state.fluid
    tvd = max(g.tvd, 1.0)
    rop, rpm, wob = float(o.rop), float(o.rpm), float(o.wob)
    bit = float(b.bit_size or g.hole_id)
    op_state = getattr(state, "operating_state", "Unknown")

    reasons = []
    applicability = 1.0
    data_quality = 0.7

    # State filtering: d-exp invalid off-bottom / pumps off / connection
    if op_state in ("PumpsOff", "Connection", "Tripping", "FlowCheck"):
        applicability = 0.05
        reasons.append(f"STATE_{op_state.upper()}_INVALID")
    elif op_state == "Circulating" and rop < 2:
        applicability = 0.15
        reasons.append("OFF_BOTTOM_OR_LOW_ROP")
    elif rop < 1 or rpm < 5 or wob < 1:
        applicability = 0.1
        reasons.append("PARAMS_TOO_LOW")
        data_quality = 0.3
    else:
        reasons.append("ON_BOTTOM_DRILLING")

    d_exp = compute_d_exponent(rop, rpm, wob, bit)
    dc = compute_dc_exponent(d_exp, f.density_ppg, normal_ppg=8.75)
    state.d_exponent = d_exp
    state.dc_exponent = dc

    normal_dc = {"PDC": 1.35, "Diamond Impregnated": 1.45, "Tricone": 1.25}.get(b.bit_type, 1.4)
    pp_psi, _ = pp_from_dexponent(tvd, dc, normal_dc=normal_dc, normal_ppg=8.75)
    bit_factor = {"PDC": 1.0, "Diamond Impregnated": 1.03, "Tricone": 0.97}.get(b.bit_type, 1.0)
    pp_psi *= bit_factor

    # Uncertainty grows when applicability drops
    base_unc_ppg = 0.6
    unc = _ppg_to_psi(base_unc_ppg, tvd) / max(applicability, 0.15)

    return PPMethodResult(
        name="d-exponent (Eaton)",
        estimate_psi=pp_psi,
        uncertainty_psi=unc,
        applicability=applicability,
        data_quality=data_quality,
        calibration_status="uncalibrated",
        reason_codes=reasons + [f"d={d_exp:.3f}", f"dc={dc:.3f}"],
        notes=f"Requires formation NCT calibration for field use",
    )


def method_mse(state) -> PPMethodResult:
    """MSE-based PP – down-weight heavily if torque is estimated, not measured."""
    from engines.hydraulics_engine import compute_mse_ksi, pp_from_mse

    g, o, b = state.geometry, state.operating, state.bit
    tvd = max(g.tvd, 1.0)
    rop, rpm, wob = float(o.rop), float(o.rpm), float(o.wob)
    bit = float(b.bit_size or g.hole_id)
    op_state = getattr(state, "operating_state", "Unknown")

    # Torque: only trust if user provided measured torque
    torque_kftlb = float(getattr(o, "torque_kftlb", 0) or 0)
    torque_measured = torque_kftlb > 0
    reasons = []
    data_quality = 0.75
    applicability = 0.85

    if not torque_measured:
        # compute_mse_ksi will approximate torque – penalize
        data_quality = 0.25
        reasons.append("TORQUE_ESTIMATED")
        applicability = 0.4
    else:
        reasons.append("TORQUE_MEASURED")

    if op_state not in ("Drilling",) and rop < 2:
        applicability *= 0.2
        reasons.append("NOT_DRILLING")

    if rop < 1 or rpm < 5:
        applicability = min(applicability, 0.1)
        reasons.append("PARAMS_LOW")

    mse = compute_mse_ksi(wob, rpm, rop, bit, torque_kftlb=torque_kftlb if torque_measured else 0.0)
    state.mse_ksi = mse
    base_mse = {"PDC": 35.0, "Diamond Impregnated": 55.0, "Tricone": 40.0}.get(b.bit_type, 40.0)
    pp_psi, _ = pp_from_mse(tvd, mse, baseline_mse=base_mse)

    unc_ppg = 0.8 if torque_measured else 1.5
    unc = _ppg_to_psi(unc_ppg, tvd)

    return PPMethodResult(
        name="MSE",
        estimate_psi=pp_psi,
        uncertainty_psi=unc,
        applicability=applicability,
        data_quality=data_quality,
        calibration_status="uncalibrated",
        reason_codes=reasons + [f"MSE={mse:.1f} ksi"],
        notes="Reliable mainly with measured surface/downhole torque",
    )


def method_gas(state) -> PPMethodResult:
    """Gas-show adjustment on formation baseline – normalized, lag-aware (simple)."""
    from engines.hydraulics_engine import pp_gas_adjustment, get_formation_at_depth

    g, o = state.geometry, state.operating
    tvd = max(g.tvd, 1.0)
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    form_ppg = float(form.get("ppg", 9.0) or 9.0)
    base = _ppg_to_psi(form_ppg, tvd)

    gas_u = float(getattr(o, "gas_units", 0) or 0)
    bg = float(getattr(o, "background_gas", 5) or 5)
    cg = float(getattr(o, "connection_gas", 0) or 0)
    tg = float(getattr(o, "trip_gas", 0) or 0)
    mud_type = str(getattr(state.fluid, "mud_type", "Water Base") or "Water Base")

    reasons = []
    applicability = 0.6
    data_quality = 0.5

    # Background-normalized residual gas
    residual = max(gas_u - bg, 0.0)
    # OBM dissolves gas – shows are muted; reduce applicability of raw units
    if "Oil" in mud_type or "Synthetic" in mud_type:
        residual *= 0.5
        applicability = 0.35
        reasons.append("OBM_SOLUBILITY_REDUCED")
        data_quality = 0.35
    else:
        reasons.append("WBM_GAS")

    # Lag proxy: if circulating, gas at surface lags bottoms-up
    op_state = getattr(state, "operating_state", "")
    if op_state == "Drilling":
        reasons.append("LAG_NOT_CORRECTED")
        data_quality *= 0.85

    # Connection/trip gas spikes are not continuous PP
    if cg > bg * 2 or tg > bg * 2:
        reasons.append("CONN_OR_TRIP_GAS")
        applicability *= 0.7

    if residual < 1:
        applicability = 0.15
        reasons.append("NO_SIGNIFICANT_SHOW")

    pp_psi, dppg = pp_gas_adjustment(base, gas_u, bg, cg, tg, tvd)
    # Cap gas uplift
    max_uplift = _ppg_to_psi(1.5, tvd)
    pp_psi = min(pp_psi, base + max_uplift)

    unc = _ppg_to_psi(0.9, tvd)
    return PPMethodResult(
        name="Gas show",
        estimate_psi=pp_psi,
        uncertainty_psi=unc,
        applicability=applicability,
        data_quality=data_quality,
        calibration_status="uncalibrated",
        reason_codes=reasons + [f"gas={gas_u:.0f}", f"bg={bg:.0f}"],
        notes="Gas units are not absolute PP; background & mud type matter",
    )


def method_temperature(state) -> PPMethodResult:
    """Weak temperature influence on formation baseline – low weight by design."""
    from engines.hydraulics_engine import pp_temperature_factor, temp_at_tvd, get_formation_at_depth

    g, f = state.geometry, state.fluid
    tvd = max(g.tvd, 1.0)
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    form_ppg = float(form.get("ppg", 9.0) or 9.0)
    base = _ppg_to_psi(form_ppg, tvd)

    t_bit = temp_at_tvd(state.temp_profile, tvd, f.ambient_temp, f.temp_gradient) if state.temp_profile else f.temp_out
    t_exp = f.ambient_temp + (tvd / 100.0) * f.temp_gradient
    pp_psi = pp_temperature_factor(base, t_bit, ref_temp=t_exp)

    return PPMethodResult(
        name="Temperature",
        estimate_psi=pp_psi,
        uncertainty_psi=_ppg_to_psi(1.0, tvd),
        applicability=0.3,
        data_quality=0.4,
        calibration_status="uncalibrated",
        reason_codes=["WEAK_EMPIRICAL", f"Tbit={t_bit:.0f}F"],
        notes="Empirical ± band only; not a primary PP method",
    )


def method_path(state, pp_dex_psi: float) -> PPMethodResult:
    """Trajectory-aware correction – depends on valid d-exp parent."""
    from engines.hydraulics_engine import (
        inclination_azimuth_at_md, compute_wellpath, pp_path_corrected,
    )

    g = state.geometry
    tvd = max(g.tvd, 1.0)
    inc, azi = inclination_azimuth_at_md(state.wellpath, g.bit_depth)
    state.inclination_at_bit = inc
    state.azimuth_at_bit = azi

    dls = 0.0
    if state.wellpath and len(state.wellpath) >= 2:
        try:
            wp = compute_wellpath(state.wellpath)
            dls = float(wp[-1].get("dls", 0) or 0)
            for row in wp:
                if abs(row["md"] - g.bit_depth) < 50:
                    dls = float(row.get("dls", dls) or dls)
        except Exception:
            pass

    pp_psi = pp_path_corrected(tvd, pp_dex_psi, inc, azi, dls)
    # Applicability rises with inclination (where vertical models fail)
    path_f = (math.sin(math.radians(max(0.0, min(90.0, inc))))) ** 1.2
    applicability = 0.25 + 0.55 * path_f

    return PPMethodResult(
        name="Path corrected",
        estimate_psi=pp_psi,
        uncertainty_psi=_ppg_to_psi(0.85, tvd),
        applicability=applicability,
        data_quality=0.5,
        calibration_status="uncalibrated",
        reason_codes=[f"INC={inc:.1f}", f"DLS={dls:.1f}"],
        notes="Heuristic blend toward path stress – not a full geomechanics model",
    )


# ─────────────────────────────────────────────────────────────
# Fusion
# ─────────────────────────────────────────────────────────────

def fuse_methods(methods: List[PPMethodResult]) -> Tuple[float, float, Dict[str, Any]]:
    """Inverse-variance × quality fusion.

    Returns (hybrid_psi, hybrid_uncertainty_psi, meta)
    """
    active = [m for m in methods if m.applicability > 0.05 and m.weight > 0]
    if not active:
        # fallback
        if methods:
            est = methods[0].estimate_psi
            unc = methods[0].uncertainty_psi
        else:
            est, unc = 0.0, 1000.0
        return est, unc, {"n_active": 0, "weights": {}}

    wsum = sum(m.weight for m in active)
    hybrid = sum(m.weight * m.estimate_psi for m in active) / wsum
    # Combined uncertainty (approx)
    # σ_h² ≈ 1 / Σ(1/σ_i² * a * q)  but we already folded a,q into weight
    inv = sum(m.weight for m in active)
    unc = math.sqrt(1.0 / inv) if inv > 0 else 500.0
    # Floor uncertainty at 0.3 ppg equivalent roughly via meta
    meta = {
        "n_active": len(active),
        "weights": {m.name: round(m.weight / wsum, 4) for m in active},
        "methods": [m.to_dict() for m in methods],
    }
    return hybrid, unc, meta


def estimate_pore_pressure_v2(state) -> Any:
    """Phase 5 orchestrator – replaces fixed-weight hybrid."""
    g = state.geometry
    tvd = max(g.tvd, 1.0)
    o = state.operating

    # Sync gas fields onto state for legacy charts
    state.gas_units = float(getattr(o, "gas_units", 0) or 0)
    state.background_gas = float(getattr(o, "background_gas", 5) or 5)
    state.connection_gas = float(getattr(o, "connection_gas", 0) or 0)
    state.trip_gas = float(getattr(o, "trip_gas", 0) or 0)

    m_form = method_formation_table(state)
    m_dex = method_dexponent(state)
    m_mse = method_mse(state)
    m_gas = method_gas(state)
    m_temp = method_temperature(state)
    m_path = method_path(state, m_dex.estimate_psi)

    methods = [m_form, m_dex, m_mse, m_gas, m_temp, m_path]
    hybrid, unc, meta = fuse_methods(methods)

    # FG from formation table
    from engines.hydraulics_engine import get_formation_at_depth
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    form_fpg = float(form.get("fpg", 16.0) or 16.0)
    state.fg_psi = _ppg_to_psi(form_fpg, tvd)

    # Write legacy scalar fields
    state.pp_formation = m_form.estimate_psi
    state.pp_dexponent = m_dex.estimate_psi
    state.pp_mse = m_mse.estimate_psi
    state.pp_gas = m_gas.estimate_psi
    state.pp_temp = m_temp.estimate_psi
    state.pp_path = m_path.estimate_psi
    state.pp_hybrid = hybrid
    state.live_pp = hybrid  # Estimated PP
    state.pp_gradient_ppg = _psi_to_ppg(hybrid, tvd)
    state.pp_uncertainty_psi = unc
    state.pp_uncertainty_ppg = _psi_to_ppg(unc, tvd)
    state.pp_methods = meta.get("methods", [])
    state.pp_fusion_weights = meta.get("weights", {})
    state.overbalance = float(getattr(state, "bhp", 0) or 0) - hybrid
    state.litho_gradient = state.pp_gradient_ppg * 0.052

    # History
    from datetime import datetime
    state.pp_history.append(state.live_pp)
    state.bhp_history_pp.append(state.bhp)
    state.ecd_history_pp.append(state.ecd)
    state.fg_history.append(state.fg_psi)
    state.time_history.append(datetime.now().strftime("%H:%M:%S"))
    # uncertainty band history
    lo = list(getattr(state, "pp_low_history", []) or [])
    hi = list(getattr(state, "pp_high_history", []) or [])
    lo.append(hybrid - unc)
    hi.append(hybrid + unc)
    maxlen = 60
    state.pp_low_history = lo[-maxlen:]
    state.pp_high_history = hi[-maxlen:]
    state.pp_history = state.pp_history[-maxlen:]
    state.bhp_history_pp = state.bhp_history_pp[-maxlen:]
    state.ecd_history_pp = state.ecd_history_pp[-maxlen:]
    state.fg_history = state.fg_history[-maxlen:]
    state.time_history = state.time_history[-maxlen:]

    return state
