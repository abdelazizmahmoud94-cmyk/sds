"""
ARHPP Diagnostics – Stage 24 (Phase 4)

- Raw sensor values stored immutably (never overwritten by model)
- Timestamp-based pit volume integration
- Light sensor filtering / lag model
- Operating-state machine
- Hypothesis ranking with confidence + reason codes

PROTOTYPE – screening aid only, not well-control qualified.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import math
import copy


# ─────────────────────────────────────────────────────────────
# Raw sensor snapshot (immutable once captured for a cycle)
# ─────────────────────────────────────────────────────────────

@dataclass
class SensorSnapshot:
    """Raw inputs – model must not mutate these fields in-place for history."""
    timestamp: str = ""
    flow_in_gpm: float = 0.0
    flow_out_gpm: float = 0.0
    spp_measured: float = 0.0
    sbp_setpoint: float = 0.0
    choke_position: float = 0.0
    pit_gain_bbl: float = 0.0
    gas_units: float = 0.0
    background_gas: float = 0.0
    rop: float = 0.0
    wob: float = 0.0
    rpm: float = 0.0
    pump1_spm: float = 0.0
    pump2_spm: float = 0.0
    pump3_spm: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def capture_raw_sensors(state) -> SensorSnapshot:
    """Copy current operating values into an immutable snapshot."""
    o = state.operating
    snap = SensorSnapshot(
        timestamp=datetime.now(timezone.utc).isoformat(),
        flow_in_gpm=float(o.flow_in_gpm),
        flow_out_gpm=float(o.flow_out_gpm),
        spp_measured=float(o.spp_measured),
        sbp_setpoint=float(o.sbp_setpoint),
        choke_position=float(o.choke_position),
        pit_gain_bbl=float(o.pit_gain_bbl),
        gas_units=float(getattr(o, "gas_units", 0) or 0),
        background_gas=float(getattr(o, "background_gas", 5) or 5),
        rop=float(o.rop),
        wob=float(o.wob),
        rpm=float(o.rpm),
        pump1_spm=float(o.pump1_spm),
        pump2_spm=float(o.pump2_spm),
        pump3_spm=float(o.pump3_spm),
    )
    # Append to immutable history (cap length)
    hist = list(getattr(state, "raw_sensor_history", []) or [])
    hist.append(snap.to_dict())
    state.raw_sensor_history = hist[-120:]
    state.raw_sensors = snap.to_dict()
    return snap


# ─────────────────────────────────────────────────────────────
# Filtered / lagged values (model-side, separate from raw)
# ─────────────────────────────────────────────────────────────

def _ema(prev: float, new: float, alpha: float) -> float:
    return alpha * new + (1.0 - alpha) * prev


def update_filtered_sensors(state, snap: SensorSnapshot, alpha: float = 0.35) -> Dict[str, float]:
    """Exponential moving average filter – does not touch raw operating fields."""
    prev = getattr(state, "filtered_sensors", None) or {}
    keys = [
        "flow_in_gpm", "flow_out_gpm", "spp_measured", "sbp_setpoint",
        "pit_gain_bbl", "gas_units", "rop", "wob", "rpm",
    ]
    out = {}
    for k in keys:
        new_v = float(getattr(snap, k, 0.0) or 0.0)
        old_v = float(prev.get(k, new_v))
        out[k] = _ema(old_v, new_v, alpha)
    # Simple lag estimate on flow_out vs flow_in (transport delay proxy, minutes)
    dq = out["flow_out_gpm"] - out["flow_in_gpm"]
    out["delta_flow_filtered"] = out["flow_in_gpm"] - out["flow_out_gpm"]
    out["flow_lag_proxy_min"] = min(5.0, max(0.0, abs(dq) / max(out["flow_in_gpm"], 1.0) * 2.0))
    state.filtered_sensors = out
    return out


# ─────────────────────────────────────────────────────────────
# Timestamp-based pit integration
# ─────────────────────────────────────────────────────────────

def integrate_pit_from_flow(state, snap: SensorSnapshot) -> float:
    """Accumulate pit volume using real wall-clock Δt between cycles.

    Only integrates when state.pit_auto_integrate is True (default False
    so user/sensor ownership is preserved unless explicitly enabled).
    """
    if not getattr(state, "pit_auto_integrate", False):
        return float(state.operating.pit_gain_bbl)

    now = datetime.now(timezone.utc)
    last_iso = getattr(state, "last_diag_timestamp", None)
    dt_min = 0.0
    if last_iso:
        try:
            last = datetime.fromisoformat(last_iso)
            if last.tzinfo is None:
                last = last.replace(tzinfo=timezone.utc)
            dt_min = max((now - last).total_seconds() / 60.0, 0.0)
            # Ignore absurd gaps (e.g. after load)
            if dt_min > 5.0:
                dt_min = 0.0
        except Exception:
            dt_min = 0.0

    state.last_diag_timestamp = now.isoformat()
    if dt_min <= 0:
        return float(state.operating.pit_gain_bbl)

    # Δpit (bbl) = (Qout - Qin) [gpm] * dt_min / 42
    dq = float(snap.flow_out_gpm) - float(snap.flow_in_gpm)
    delta_bbl = (dq / 42.0) * dt_min
    new_pit = float(state.operating.pit_gain_bbl) + delta_bbl
    # Write back only the integrated value – raw snapshot already stored
    state.operating.pit_gain_bbl = new_pit
    state.pit_integrated_delta_bbl = delta_bbl
    state.pit_dt_min = dt_min
    return new_pit


# ─────────────────────────────────────────────────────────────
# Operating-state machine
# ─────────────────────────────────────────────────────────────

OPERATING_STATES = (
    "PumpsOff",
    "Circulating",
    "Drilling",
    "Connection",
    "Tripping",
    "FlowCheck",
    "Unknown",
)


def classify_operating_state(state, snap: SensorSnapshot) -> str:
    """Simple state machine from sensors + mode."""
    q_in = snap.flow_in_gpm
    spm = snap.pump1_spm + snap.pump2_spm + snap.pump3_spm
    rop = snap.rop
    rpm = snap.rpm
    mode = getattr(state, "mode", "Offline")

    if q_in < 5 and spm < 2:
        st = "PumpsOff"
    elif rop > 5 and rpm > 20 and q_in > 50:
        st = "Drilling"
    elif q_in > 50 and rop <= 5:
        st = "Circulating"
    elif q_in < 30 and rop < 1 and rpm < 5:
        # could be connection or flow check
        if abs(snap.flow_out_gpm - snap.flow_in_gpm) > 10:
            st = "FlowCheck"
        else:
            st = "Connection"
    elif q_in < 20 and getattr(state, "surge", None) and abs(getattr(state.surge, "pipe_velocity_ftmin", 0)) > 10:
        st = "Tripping"
    else:
        st = "Unknown"

    prev = getattr(state, "operating_state", None)
    state.operating_state = st
    state.operating_state_prev = prev
    return st


# ─────────────────────────────────────────────────────────────
# Hypothesis ranking
# ─────────────────────────────────────────────────────────────

@dataclass
class Hypothesis:
    name: str
    probability: float  # 0–100
    confidence: str     # Low / Medium / High
    reason_codes: List[str] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


def rank_hypotheses(state, snap: SensorSnapshot, filtered: Dict[str, float]) -> List[Dict[str, Any]]:
    """Rank alternative explanations for flow/pressure anomalies.

    Returns list of hypothesis dicts sorted by probability descending.
    """
    o = state.operating
    dq = snap.flow_out_gpm - snap.flow_in_gpm  # + returns excess
    delta_in_out = snap.flow_in_gpm - snap.flow_out_gpm
    pit = float(o.pit_gain_bbl)
    gas = snap.gas_units
    bg = max(snap.background_gas, 1.0)
    overbal = float(getattr(state, "overbalance", 0) or 0)
    u_dp = float(getattr(state, "u_tube_dp", 0) or 0)
    q_ut = float(getattr(state, "q_utube", 0) or 0)
    delta_spp = float(getattr(state, "delta_spp", 0) or 0)
    op_state = getattr(state, "operating_state", "Unknown")
    pumps_off = op_state == "PumpsOff" or snap.flow_in_gpm < 5

    hyps: List[Hypothesis] = []

    # --- Kick (influx) ---
    kick_p = 5.0
    kick_reasons, kick_ev = [], []
    if dq > 15:
        kick_p += min(40.0, (dq - 15) * 1.2)
        kick_reasons.append("FLOW_OUT_HIGH")
        kick_ev.append(f"Qout-Qin={dq:.1f} gpm")
    if pit > 5:
        kick_p += min(25.0, pit * 1.5)
        kick_reasons.append("PIT_GAIN")
        kick_ev.append(f"pit={pit:.1f} bbl")
    if gas > bg * 3:
        kick_p += 15.0
        kick_reasons.append("GAS_SHOW")
        kick_ev.append(f"gas={gas:.0f} > 3×bg")
    if overbal < 50:
        kick_p += 20.0
        kick_reasons.append("LOW_OVERBALANCE")
        kick_ev.append(f"OB={overbal:.0f} psi")
    elif overbal < 150:
        kick_p += 8.0
        kick_reasons.append("MARGINAL_OVERBALANCE")
    if pumps_off and abs(u_dp) > 50:
        # U-tube more likely than kick when pumps off with hydro imbalance
        kick_p *= 0.45
        kick_reasons.append("UTUBE_COMPETING")
    kick_p = _clamp(kick_p)
    kick_conf = "High" if kick_p >= 60 else ("Medium" if kick_p >= 30 else "Low")
    hyps.append(Hypothesis("Kick (influx)", kick_p, kick_conf, kick_reasons, kick_ev))

    # --- Losses ---
    loss_p = 5.0
    loss_reasons, loss_ev = [], []
    if dq < -15:
        loss_p += min(40.0, abs(dq + 15) * 1.2)
        loss_reasons.append("FLOW_OUT_LOW")
        loss_ev.append(f"Qout-Qin={dq:.1f} gpm")
    if pit < -8:
        loss_p += min(25.0, abs(pit) * 1.2)
        loss_reasons.append("PIT_LOSS")
        loss_ev.append(f"pit={pit:.1f} bbl")
    if delta_spp < -150 and dq < -5:
        loss_p += 10.0
        loss_reasons.append("SPP_DROP")
        loss_ev.append(f"ΔSPP={delta_spp:.0f} psi")
    loss_p = _clamp(loss_p)
    loss_conf = "High" if loss_p >= 60 else ("Medium" if loss_p >= 30 else "Low")
    hyps.append(Hypothesis("Losses", loss_p, loss_conf, loss_reasons, loss_ev))

    # --- U-Tube ---
    ut_p = 5.0
    ut_reasons, ut_ev = [], []
    if abs(u_dp) > 30:
        ut_p += min(50.0, abs(u_dp) / 40.0)
        ut_reasons.append("HYDRO_IMBALANCE")
        ut_ev.append(f"U-Tube ΔP={u_dp:.0f} psi")
    if pumps_off and abs(u_dp) > 20:
        ut_p += 25.0
        ut_reasons.append("PUMPS_OFF")
    if abs(q_ut) > 10:
        ut_p += min(20.0, abs(q_ut) / 20.0)
        ut_reasons.append("UTUBE_FLOW_SOLVED")
        ut_ev.append(f"Q_utube={q_ut:.1f} gpm")
    if not pumps_off:
        ut_p *= 0.4
        ut_reasons.append("PUMPS_ON_REDUCED")
    ut_p = _clamp(ut_p)
    ut_conf = "High" if ut_p >= 55 else ("Medium" if ut_p >= 25 else "Low")
    hyps.append(Hypothesis("U-Tube imbalance", ut_p, ut_conf, ut_reasons, ut_ev))

    # --- Ballooning / wellbore breathing ---
    bal_p = 3.0
    bal_reasons, bal_ev = [], []
    if abs(dq) > 10 and abs(pit) < 3 and overbal > 200:
        bal_p += 25.0
        bal_reasons.append("FLOW_SWING_SMALL_PIT")
        bal_ev.append("Flow imbalance without sustained pit change")
    if abs(delta_spp) > 100 and abs(dq) < 20:
        bal_p += 15.0
        bal_reasons.append("SPP_OSCILLATION")
    bal_p = _clamp(bal_p)
    hyps.append(Hypothesis("Ballooning / breathing", bal_p,
                           "Medium" if bal_p >= 30 else "Low", bal_reasons, bal_ev))

    # --- Sensor / meter issue ---
    sens_p = 5.0
    sens_reasons, sens_ev = [], []
    lag = float(filtered.get("flow_lag_proxy_min", 0) or 0)
    if lag > 1.5 and abs(dq) > 10:
        sens_p += 20.0
        sens_reasons.append("FLOW_LAG_PROXY")
        sens_ev.append(f"lag_proxy≈{lag:.1f} min")
    if abs(delta_spp) > 300 and abs(dq) < 8 and abs(pit) < 2:
        sens_p += 25.0
        sens_reasons.append("SPP_MISMATCH_NO_FLOW")
        sens_ev.append(f"ΔSPP={delta_spp:.0f} with stable flow/pit")
    if snap.flow_out_gpm < 1 and snap.flow_in_gpm > 100:
        sens_p += 30.0
        sens_reasons.append("FLOW_OUT_NEAR_ZERO")
        sens_ev.append("Flow Out ≈ 0 while pumping")
    sens_p = _clamp(sens_p)
    hyps.append(Hypothesis("Sensor / meter issue", sens_p,
                           "Medium" if sens_p >= 35 else "Low", sens_reasons, sens_ev))

    # --- Thermal expansion (weak prior) ---
    th_p = 2.0
    if abs(dq) < 12 and abs(pit) < 4 and op_state == "Circulating":
        th_p += 10.0
    hyps.append(Hypothesis("Thermal / compressibility", _clamp(th_p), "Low",
                           ["WEAK_PRIOR"], ["Small imbalances can be thermal"]))

    # Normalize lightly so top set is interpretable (not forced to 100%)
    hyps.sort(key=lambda h: h.probability, reverse=True)
    # Cap extreme double-counting
    for h in hyps:
        h.probability = round(_clamp(h.probability), 1)

    state.hypotheses = [h.to_dict() for h in hyps]
    state.top_hypothesis = hyps[0].name if hyps else ""
    state.top_hypothesis_prob = hyps[0].probability if hyps else 0.0
    return state.hypotheses


# ─────────────────────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────────────────────

def run_phase4_diagnostics(state) -> Any:
    """Full Phase 4 diagnostics pass. Does not alter raw Flow Out/In for model convenience."""
    snap = capture_raw_sensors(state)
    filtered = update_filtered_sensors(state, snap)
    integrate_pit_from_flow(state, snap)
    op_state = classify_operating_state(state, snap)

    # Keep legacy delta fields from RAW (not filtered) for transparency
    state.delta_flow = snap.flow_in_gpm - snap.flow_out_gpm
    state.delta_spp = snap.spp_measured - float(getattr(state, "model_spp", 0) or 0)

    hyps = rank_hypotheses(state, snap, filtered)

    # Map top hypotheses back to legacy kick/loss flags (screening only)
    o = state.operating
    top = hyps[0] if hyps else {}
    kick_h = next((h for h in hyps if h["name"].startswith("Kick")), None)
    loss_h = next((h for h in hyps if h["name"].startswith("Loss")), None)

    o.kick_flag = bool(kick_h and kick_h["probability"] >= 35)
    o.loss_flag = bool(loss_h and loss_h["probability"] >= 35)
    if o.kick_flag and kick_h:
        p = kick_h["probability"]
        o.kick_severity = "Severe" if p >= 70 else ("Moderate" if p >= 50 else "Minor")
        if any("UTUBE" in r for r in kick_h.get("reason_codes", [])):
            o.kick_severity = f"{o.kick_severity} (check U-Tube)"
    else:
        o.kick_severity = "None"
    if o.loss_flag and loss_h:
        p = loss_h["probability"]
        o.loss_severity = "Severe" if p >= 70 else ("Moderate" if p >= 50 else "Minor")
    else:
        o.loss_severity = "None"

    # Status / message
    msgs = []
    status = "OK"
    if o.kick_flag:
        status = "ALERT"
        msgs.append(f"KICK screening {o.kick_severity} P={kick_h['probability']:.0f}%")
    if o.loss_flag:
        status = "ALERT"
        msgs.append(f"LOSS screening {o.loss_severity} P={loss_h['probability']:.0f}%")
    if abs(state.delta_flow) > 15 and status == "OK":
        status = "WARNING"
        msgs.append(f"Flow imbalance ΔQ={state.delta_flow:.1f} gpm")
    if abs(state.delta_spp) > 150:
        status = "WARNING" if status == "OK" else status
        msgs.append(f"SPP residual {state.delta_spp:+.0f} psi")
    if float(getattr(state, "overbalance", 0) or 0) < 100:
        status = "ALERT"
        msgs.append(f"Low overbalance {state.overbalance:.0f} psi")

    # Equipment limits (surface-side)
    try:
        from engines.hydraulics_engine import equipment_pressure_limits
        lim = equipment_pressure_limits(state)
        spp_ref = max(float(getattr(state, "model_spp", 0) or 0), snap.spp_measured)
        if spp_ref > lim["pop_off_psi"]:
            msgs.append(f"SPP {spp_ref:.0f} > Pop-off {lim['pop_off_psi']:.0f} psi")
            status = "ALERT"
        elif spp_ref > lim["working_pump_psi"]:
            msgs.append(f"SPP near pump working limit {lim['working_pump_psi']:.0f} psi")
            status = "WARNING" if status == "OK" else status
        if snap.sbp_setpoint > lim["rcd_rating_psi"] * 0.9:
            msgs.append(f"SBP approaches RCD rating {lim['rcd_rating_psi']:.0f} psi")
            status = "WARNING" if status == "OK" else status
        # Do NOT compare BHP to BOP rating
    except Exception:
        pass

    msgs.append(f"State={op_state}")
    if hyps:
        msgs.append(f"Top: {hyps[0]['name']} {hyps[0]['probability']:.0f}% ({hyps[0]['confidence']})")

    state.diag_status = status
    state.diag_message = " | ".join(msgs) if msgs else "All primary parameters within normal range"
    state.diag_reason_codes = []
    for h in hyps[:3]:
        state.diag_reason_codes.extend(h.get("reason_codes", []))

    return state
