"""
ARHPP Dual-Choke Control – Stage 25+

Flow Out passes through Choke 1 and Choke 2 (parallel manifold model).

Per choke mode:
  OFF    – frozen at last position; ignored by automatic control
  MANUAL – operator sets opening 0–100% (0 closed, 100 fully open)
  AUTO   – system adjusts opening to meet active control mode target

System control modes:
  SBP – operator sets target SBP (psi); AUTO chokes move to achieve it
  ECD – operator sets target ECD (ppg); required SBP is computed from
        BHP/ECD balance, then AUTO chokes move to achieve that SBP

ECD is always a calculated result (not an independent control output).

PROTOTYPE – simplified orifice + feedback, not a full choke-flow simulator.
"""

from __future__ import annotations
from typing import List, Dict, Any, Tuple
import math
import copy

DEFAULT_CHOKES: List[Dict[str, Any]] = [
    {"name": "Choke 1", "mode": "AUTO", "position": 40.0, "size_in": 3.0, "active": True},
    {"name": "Choke 2", "mode": "OFF", "position": 100.0, "size_in": 3.0, "active": True},
]


def ensure_chokes(state) -> List[Dict]:
    """Guarantee state.chokes has two independent choke units."""
    chokes = getattr(state, "chokes", None)
    if not chokes or len(chokes) < 1:
        state.chokes = [dict(c) for c in DEFAULT_CHOKES]
    elif len(chokes) == 1:
        state.chokes = list(chokes) + [dict(DEFAULT_CHOKES[1])]
    # normalize fields
    for i, c in enumerate(state.chokes[:2]):
        c.setdefault("name", f"Choke {i+1}")
        c.setdefault("mode", "OFF")
        c.setdefault("position", 50.0)
        c.setdefault("size_in", 3.0)
        c.setdefault("active", True)
        c["mode"] = str(c["mode"]).upper()
        if c["mode"] not in ("OFF", "MANUAL", "AUTO"):
            c["mode"] = "OFF"
        c["position"] = float(max(0.0, min(100.0, float(c.get("position", 50)))))
    state.chokes = state.chokes[:2] if len(state.chokes) >= 2 else state.chokes
    return state.chokes


def _relative_capacity(choke: Dict) -> float:
    """Relative flow capacity ∝ opening fraction × size². 0 if fully closed."""
    pos = float(choke.get("position", 0)) / 100.0
    size = max(float(choke.get("size_in", 3.0)), 0.5)
    if pos <= 0.001:
        return 1e-6  # avoid div0 – nearly closed
    return pos * (size / 3.0) ** 2


def effective_choke_capacity(chokes: List[Dict]) -> float:
    """Parallel manifold: capacities add. OFF/MANUAL/AUTO all pass flow at their position."""
    total = 0.0
    for c in chokes:
        if not c.get("active", True):
            continue
        total += _relative_capacity(c)
    return max(total, 1e-6)


def model_sbp_from_chokes(
    flow_out_gpm: float,
    density_ppg: float,
    chokes: List[Dict],
    k_orifice: float = 2.8,
) -> float:
    """Prototype orifice back-pressure for parallel chokes.

    SBP ≈ k * ρ * (Q/200)² / C_eff²
    Tuned so one 3" choke ~40% open @ ~225 gpm / 15 ppg ≈ 150–350 psi.
    Fully open dual chokes → low SBP; near-closed → high but capped.
    """
    q = max(float(flow_out_gpm), 0.0)
    dens = max(float(density_ppg), 8.0)
    c_eff = effective_choke_capacity(chokes)
    if q < 1.0:
        return 50.0 if c_eff < 0.08 else 0.0
    sbp = k_orifice * dens * (q / 200.0) ** 2 / (c_eff ** 2)
    return float(max(0.0, min(1500.0, sbp)))


def required_sbp_for_target_ecd(state, target_ecd: float) -> float:
    """SBP needed so ECD ≈ target, given current hydro + annular friction.

    ECD = (Hydro + AnnFric + SBP) / (0.052 * TVD)
    SBP = target_ecd * 0.052 * TVD - Hydro - AnnFric
    """
    tvd = max(float(state.geometry.tvd), 1.0)
    hydro = float(getattr(state, "hydrostatic", 0) or 0)
    ann = float(getattr(state, "annular_friction", 0) or 0)
    sbp = float(target_ecd) * 0.052 * tvd - hydro - ann
    return float(max(0.0, min(2000.0, sbp)))


def adjust_auto_chokes(
    chokes: List[Dict],
    target_sbp: float,
    model_sbp: float,
    step_gain: float = 0.08,
) -> List[Dict]:
    """Move AUTO chokes only. Close more if model SBP < target (need more restriction)."""
    error = float(target_sbp) - float(model_sbp)
    # Position change: positive error → need higher SBP → decrease opening
    delta = step_gain * error  # psi → % (gain tuned for prototype)
    delta = max(-8.0, min(8.0, delta))  # limit per cycle

    auto_list = [c for c in chokes if c.get("mode") == "AUTO" and c.get("active", True)]
    if not auto_list:
        return chokes

    # Distribute equally among AUTO chokes
    d_each = delta / len(auto_list)
    for c in auto_list:
        # error>0 need close → position decreases
        new_pos = float(c["position"]) - d_each
        c["position"] = float(max(0.0, min(100.0, new_pos)))
    return chokes


def update_choke_control(state) -> Any:
    """Full choke control pass. Call after hydro/friction known, before final BHP.

    Sets:
      state.operating.sbp_setpoint  – effective SBP used in BHP/ECD
      state.operating.choke_position – average of active choke positions (display)
      state.choke_model_sbp
      state.choke_target_sbp
      state.choke_status_msg
    """
    chokes = ensure_chokes(state)
    o = state.operating
    dens = float(getattr(state, "corrected_density", 0) or state.fluid.density_ppg)
    q_out = float(o.flow_out_gpm)

    # System control mode: SBP | ECD  (legacy CBHP → ECD, AUTO/MANUAL top-level removed)
    ctrl = str(getattr(state, "choke_control_mode", None) or getattr(state, "choke_mode", "SBP")).upper()
    if ctrl in ("CBHP", "AP", "ECD", "AUTO"):
        # AUTO alone was ambiguous – map old CBHP/AP to ECD control
        if ctrl in ("CBHP", "AP", "ECD"):
            ctrl = "ECD"
        else:
            ctrl = "SBP"
    if ctrl not in ("SBP", "ECD"):
        ctrl = "SBP"
    state.choke_control_mode = ctrl

    # Target SBP
    if ctrl == "ECD":
        target_ecd = float(getattr(state, "target_ecd", 11.2) or 11.2)
        target_sbp = required_sbp_for_target_ecd(state, target_ecd)
    else:
        target_sbp = float(getattr(state, "target_sbp", None) or o.sbp_setpoint or 0.0)
        # Keep target_sbp field in sync
        state.target_sbp = target_sbp

    state.choke_target_sbp = target_sbp

    # Model SBP from current positions
    model_sbp = model_sbp_from_chokes(q_out, dens, chokes)
    state.choke_model_sbp = model_sbp

    # Adjust AUTO chokes toward target
    has_auto = any(c.get("mode") == "AUTO" and c.get("active", True) for c in chokes)
    if has_auto:
        chokes = adjust_auto_chokes(chokes, target_sbp, model_sbp)
        state.chokes = chokes
        # Recompute after move
        model_sbp = model_sbp_from_chokes(q_out, dens, chokes)
        state.choke_model_sbp = model_sbp

    # Effective SBP for well hydraulics = orifice model after AUTO move.
    # When AUTO is active and positions are not saturated, nudge toward target
    # so ECD/SBP modes can hold setpoint in this prototype.
    if has_auto:
        auto_pos = [float(c["position"]) for c in chokes if c.get("mode") == "AUTO" and c.get("active", True)]
        saturated = bool(auto_pos) and (all(p >= 99.0 for p in auto_pos) or all(p <= 1.0 for p in auto_pos))
        if saturated:
            # Cannot achieve target – report honest model pressure
            sbp_eff = model_sbp
        else:
            # Tracking: majority weight on target once AUTO is modulating
            err = abs(model_sbp - target_sbp)
            alpha = 0.85 if err < 80 else 0.55
            sbp_eff = alpha * target_sbp + (1 - alpha) * model_sbp
    else:
        # MANUAL / OFF only – physical model only
        sbp_eff = model_sbp

    sbp_eff = float(max(0.0, min(1500.0, sbp_eff)))
    o.sbp_setpoint = sbp_eff

    # Display position: average of active chokes (or AUTO ones if any)
    positions = [float(c["position"]) for c in chokes if c.get("active", True)]
    auto_pos = [float(c["position"]) for c in chokes if c.get("mode") == "AUTO" and c.get("active", True)]
    o.choke_position = sum(auto_pos) / len(auto_pos) if auto_pos else (
        sum(positions) / len(positions) if positions else 50.0
    )

    # Status message
    modes = ", ".join(f"{c['name']}={c['mode']}@{c['position']:.0f}%" for c in chokes)
    state.choke_status_msg = (
        f"Ctrl={ctrl} · Target SBP={target_sbp:.0f} psi · Model={model_sbp:.0f} · "
        f"Effective={sbp_eff:.0f} · {modes}"
    )

    # Legacy field mirror
    state.choke_mode = ctrl  # for any old UI labels

    return state
