"""
ARHPP Main Application – Stage 7
Save/Load well state + UI polish
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config.settings import APP_NAME, APP_VERSION, APP_SUBTITLE
from engines.hydraulics_engine import (
    SimulationState, run_hydraulics, get_profile_depth_data,
    add_timeline_event, log_activity, get_activity_summary,
    save_state_json, load_state_json, state_to_dict,
    validate_well_intervals, validate_work_string, get_shoe_depth,
    work_string_total_length, work_string_max_od, DEFAULT_CASINGS, DEFAULT_OPEN_HOLE,
    DEFAULT_WORK_STRING, DEFAULT_WELLPATH, compute_wellpath, wellpath_tvd_at_md,
    DEFAULT_FLUID_LIBRARY, fit_hb_from_fann, apply_pump_fluid,
    init_fluid_columns, pump_fluid_step,
    DEFAULT_TEMP_PROFILE, temp_at_tvd, build_temp_profile_from_gradient,
    DEFAULT_LITHOLOGY, enrich_formations_tvd
)

st.set_page_config(page_title=APP_NAME, page_icon="🛢️", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
    .stApp { background-color: #1a1d23; color: #d0d0d0; }
    section[data-testid="stSidebar"] { background-color: #12151a; }
    div[data-testid="stMetricValue"] { color: #00d4aa; font-size: 1.28rem; }
    .block-container { padding-top: 0.4rem; padding-bottom: 0.2rem; }
    h1, h2, h3, h4 { color: #e8e8e8 !important; }
</style>
""", unsafe_allow_html=True)

if "state" not in st.session_state:
    st.session_state.state = run_hydraulics(SimulationState())
if "app_name" not in st.session_state:
    st.session_state.app_name = APP_NAME

state = st.session_state.state

# Top bar
c1, c2, c3, c4 = st.columns([0.5, 3.5, 1.6, 1.2])
with c1:
    st.markdown("### 🛢️")
with c2:
    st.markdown(f"## {st.session_state.app_name} <span style='font-size:12px;color:#888'>{APP_VERSION}</span>", unsafe_allow_html=True)
with c3:
    st.caption(f"Bit: {state.geometry.bit_depth:.0f} ft | {state.current_formation}")
with c4:
    mode_color = {"Offline": "#ffaa00", "Simulation": "#00d4aa", "Live": "#00ff88"}.get(state.mode, "#ffaa00")
    st.markdown(f"<div style='text-align:right;padding-top:10px'><span style='background:{mode_color};color:#111;padding:4px 12px;border-radius:4px;font-weight:700;font-size:12px'>{state.mode.upper()}</span></div>", unsafe_allow_html=True)

status_color = {"OK": "#00d4aa", "WARNING": "#ffaa00", "ALERT": "#ff5555"}.get(state.diag_status, "#888")
st.markdown(f"""
<div style="background:#252a33;padding:6px 12px;border-radius:4px;border-left:4px solid {status_color};margin-bottom:8px;font-size:13px">
<b style="color:{status_color}">{state.diag_status}</b> &nbsp;|&nbsp; {state.diag_message}
</div>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.markdown(f"**{st.session_state.app_name}**")
    nav = st.radio("Modules", [
        "Profile Depth Data", "Wellpath", "Formations", "Temperatures", "Fluid Properties",
        "MPD Gauges", "Main Time Data", "Surge & Swab", "Choke Control", "Actual vs Model",
        "Timeline", "Performance", "Engineering", "Settings"
    ], index=0)
    st.markdown("---")
    st.markdown("**Quick Setpoints**")
    state.mode = st.selectbox("Mode", ["Offline", "Simulation", "Live"],
                              index=["Offline", "Simulation", "Live"].index(state.mode))
    state.choke_mode = st.selectbox("Choke Mode", ["MANUAL", "AUTO", "CBHP"],
                                    index=["MANUAL", "AUTO", "CBHP"].index(state.choke_mode))
    state.operating.sbp_setpoint = st.slider("SBP (psi)", 0, 1000, int(state.operating.sbp_setpoint), 5)
    state.operating.flow_in_gpm = st.number_input("Flow In (gpm)", 0.0, 2000.0, float(state.operating.flow_in_gpm), 10.0)
    state.operating.flow_out_gpm = st.number_input("Flow Out (gpm)", 0.0, 2000.0, float(state.operating.flow_out_gpm), 5.0)
    state.operating.spp_measured = st.number_input("SPP Measured (psi)", 0.0, 6000.0, float(state.operating.spp_measured), 10.0)
    state.operating.choke_position = st.slider("Choke %", 0, 100, int(state.operating.choke_position), 1)

    if state.mode == "Simulation":
        if st.button("▶ Step Simulation", use_container_width=True):
            import random
            state.operating.flow_out_gpm = max(0, state.operating.flow_in_gpm - random.uniform(2, 12))
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = log_activity(st.session_state.state, "Drilling", 0.5)
            st.rerun()

    if st.button("⟳ Recalculate", use_container_width=True, type="primary"):
        st.session_state.state = run_hydraulics(state)
        st.session_state.state = add_timeline_event(st.session_state.state, "Recalculate", f"SBP={state.operating.sbp_setpoint:.0f}")
        st.session_state.state = log_activity(st.session_state.state, "Circulating", 2.0)
        st.rerun()

    st.markdown("---")
    st.markdown("**Save / Load**")
    if st.button("💾 Save State", use_container_width=True):
        path = save_state_json(st.session_state.state, "data/well_state.json")
        st.session_state.state = add_timeline_event(st.session_state.state, "State Saved", path)
        st.success(f"Saved → {path}")
    if st.button("📂 Load State", use_container_width=True):
        st.session_state.state = load_state_json("data/well_state.json")
        st.session_state.state = add_timeline_event(st.session_state.state, "State Loaded")
        st.rerun()

# ── Pages (same structure as Stage 6 + Save/Load already in sidebar) ──
if nav == "Profile Depth Data":
    gcols = st.columns(7)
    for col, (label, val, unit, delta) in zip(gcols, [
        ("BHP", f"{state.bhp:.0f}", "psi", f"Tgt {state.target_bhp:.0f}"),
        ("ECD", f"{state.ecd:.2f}", "ppg", f"Tgt {state.target_ecd:.2f}"),
        ("Model SPP", f"{state.model_spp:.0f}", "psi", None),
        ("SBP", f"{state.operating.sbp_setpoint:.0f}", "psi", None),
        ("Flow In", f"{state.operating.flow_in_gpm:.0f}", "gpm", None),
        ("Live PP", f"{state.live_pp:.0f}", "psi", f"OB {state.overbalance:.0f}"),
        ("Eff. Flow", f"{state.effective_flow:.0f}", "gpm", None),
    ]):
        col.metric(label, f"{val} {unit}", delta)

    left, right = st.columns([3.1, 1.2])
    with left:
        df = pd.DataFrame(get_profile_depth_data(state, 18))
        display_df = df.rename(columns={
            "MD_ft": "MD", "TVD_ft": "TVD", "Formation": "Form",
            "Formation_Temp_F": "Form.T", "Annulus_Temp_F": "Ann.T",
            "Pipe_Temp_F": "Pipe.T", "Annulus_Density_ppg": "Ann.Dens",
            "Pipe_Density_ppg": "Pipe.Dens", "Annulus_Friction_psi": "Ann.Fric",
            "Pipe_App_Visc_cP": "Pipe.Visc", "Annulus_App_Visc_cP": "Ann.Visc",
            "Annulus_ECD_ppg": "Ann.ECD", "Annulus_Pressure_psi": "Ann.P",
            "Pore_Pressure_psi": "PP", "Fracture_Pressure_psi": "FG",
            "PPG": "PPG", "WBSG_ppg": "WBSG", "WBS_psi": "WBS"
        })
        st.dataframe(display_df, use_container_width=True, height=380)

    with right:
        st.markdown("**Well Schematic + Fluids**")
        fig = go.Figure()
        total_md = max(state.geometry.bit_depth, state.geometry.md, 1)
        # Lithology background (full width light)
        for layer in state.lithology:
            y0 = (layer["md_top"] / total_md) * 100
            y1 = min((layer["md_bot"] / total_md) * 100, 100)
            if y0 > 100: continue
            fig.add_shape(type="rect", x0=0.0, x1=1.0, y0=y0, y1=y1,
                          fillcolor=layer["color"], opacity=0.25, line=dict(width=0))
        # Annulus fluid column (outer)
        for seg in (state.ann_column or []):
            y0 = (seg["md_top"] / total_md) * 100
            y1 = (seg["md_bot"] / total_md) * 100
            fig.add_shape(type="rect", x0=0.12, x1=0.88, y0=y0, y1=y1,
                          fillcolor=seg.get("color", "#666"), opacity=0.85, line=dict(color="#222", width=0.4))
            if y1 - y0 > 4:
                fig.add_annotation(x=0.5, y=(y0+y1)/2, text=f"{seg.get('name','')[:12]}", showarrow=False,
                                   font=dict(size=8, color="#fff"))
        # Pipe fluid column (inner)
        for seg in (state.pipe_column or []):
            y0 = (seg["md_top"] / total_md) * 100
            y1 = (seg["md_bot"] / total_md) * 100
            fig.add_shape(type="rect", x0=0.35, x1=0.65, y0=y0, y1=y1,
                          fillcolor=seg.get("color", "#444"), opacity=0.95, line=dict(color="#111", width=0.5))
        shoe_y = (state.geometry.shoe_depth / total_md) * 100
        fig.add_shape(type="line", x0=0.05, x1=0.95, y0=shoe_y, y1=shoe_y, line=dict(color="#ffaa00", width=2, dash="dot"))
        bit_y = (state.geometry.bit_depth / total_md) * 100
        fig.add_shape(type="rect", x0=0.08, x1=0.92, y0=bit_y-1.2, y1=bit_y+1.2, fillcolor="#00d4aa", line=dict(width=0))
        fig.update_layout(height=360, margin=dict(l=5,r=5,t=5,b=5), paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23",
                          xaxis=dict(visible=False, range=[0,1]),
                          yaxis=dict(range=[100,0], color="#718096", gridcolor="#2d3748", tickfont=dict(size=9)))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(
            f"<small>**{state.current_formation}** | Bit {state.geometry.bit_depth:.0f} ft | "
            f"Shoe {state.geometry.shoe_depth:.0f} ft<br>Pump: {state.pump_fluid_name} | "
            f"Choke {state.operating.choke_position:.0f}% ({state.choke_mode})</small>",
            unsafe_allow_html=True
        )

elif nav == "Wellpath":
    st.subheader("Wellpath / Survey")
    st.caption("Enter **MD, Inclination, Azimuth** only. TVD, North, East, DLS, Build/Turn rates, VS, H.Disp are calculated (Minimum Curvature).")

    raw = state.wellpath if state.wellpath else [dict(x) for x in DEFAULT_WELLPATH]
    # show only input columns for editing
    input_df = pd.DataFrame([{"md": r.get("md", 0), "inc": r.get("inc", 0), "azi": r.get("azi", 0)} for r in raw])
    edited = st.data_editor(
        input_df,
        num_rows="dynamic",
        use_container_width=True,
        key="wellpath_editor",
        height=280,
        column_config={
            "md": st.column_config.NumberColumn("MD ft", format="%.2f"),
            "inc": st.column_config.NumberColumn("Inc °", format="%.2f"),
            "azi": st.column_config.NumberColumn("Azi °", format="%.2f"),
        }
    )
    vs_az = st.number_input("Vertical Section Azimuth (°)", value=0.0, step=1.0,
                            help="Azimuth used for VS calculation")

    stations = edited.to_dict("records")
    computed = compute_wellpath(stations, vs_azimuth_deg=vs_az)

    if computed:
        st.markdown("##### Computed Survey (read-only)")
        disp = pd.DataFrame(computed)[[
            "md", "inc", "azi", "tvd", "tvdss", "north", "east",
            "cl", "dls", "build_rate", "turn_rate", "toolface", "vs", "hdisp"
        ]].rename(columns={
            "md": "MD", "inc": "Inc", "azi": "Azi", "tvd": "TVD", "tvdss": "TVDSS",
            "north": "North", "east": "East", "cl": "CL", "dls": "DLS °/100ft",
            "build_rate": "Build °/100ft", "turn_rate": "Turn °/100ft",
            "toolface": "T.Face", "vs": "VS", "hdisp": "H.Disp"
        })
        st.dataframe(disp, use_container_width=True, height=320)

        # Simple plots
        c1, c2 = st.columns(2)
        with c1:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=disp["H.Disp"], y=disp["TVD"], mode="lines+markers",
                                     line=dict(color="#00d4aa", width=2), name="Vertical section"))
            fig.update_layout(title="TVD vs H.Disp", paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23",
                              font=dict(color="#ccc"), height=280, yaxis=dict(autorange="reversed"),
                              margin=dict(t=40, b=30))
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            fig2 = go.Figure()
            fig2.add_trace(go.Scatter(x=disp["East"], y=disp["North"], mode="lines+markers",
                                      line=dict(color="#4a9eff", width=2), name="Plan view"))
            fig2.update_layout(title="North vs East (Plan)", paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23",
                               font=dict(color="#ccc"), height=280, margin=dict(t=40, b=30))
            st.plotly_chart(fig2, use_container_width=True)

        last = computed[-1]
        st.markdown(
            f"**Last station:** MD {last['md']:.1f} · TVD {last['tvd']:.1f} · "
            f"Inc {last['inc']:.1f}° · DLS {last['dls']:.2f}°/100ft · H.Disp {last['hdisp']:.1f} ft"
        )

    b1, b2 = st.columns(2)
    with b1:
        if st.button("Apply Wellpath & Update TVD", type="primary", use_container_width=True):
            state.wellpath = stations
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(
                st.session_state.state, "Wellpath Applied",
                f"Stations={len(stations)}, TVD@bit={st.session_state.state.geometry.tvd:.1f}"
            )
            st.rerun()
    with b2:
        if st.button("Reset Wellpath defaults", use_container_width=True):
            state.wellpath = [dict(x) for x in DEFAULT_WELLPATH]
            st.session_state.state = run_hydraulics(state)
            st.rerun()

elif nav == "Formations":
    st.subheader("Formations")
    st.caption("Enter lithology, name, MD top, PPG, FPG, porosity… **TVD is calculated from Wellpath** (not editable).")

    # Ensure enriched for display
    layers = enrich_formations_tvd(state.lithology or DEFAULT_LITHOLOGY, state.wellpath)
    rows = []
    for f in layers:
        rows.append({
            "lithology": f.get("lithology", ""),
            "name": f.get("name", ""),
            "porosity": float(f.get("porosity", 0)),
            "permeability": float(f.get("permeability", 0)),
            "md": float(f.get("md", f.get("md_top", 0))),
            "tvd": float(f.get("tvd", 0)),
            "ppg": float(f.get("ppg", 9.0)),
            "wbsg": float(f.get("wbsg", 0)),
            "fit": float(f.get("fit", 0)),
            "fpg": float(f.get("fpg", 14.0)),
            "lot": float(f.get("lot", 0)),
            "min_hs": float(f.get("min_hs", 0)),
            "max_hs": float(f.get("max_hs", 0)),
            "d_max_hs": float(f.get("d_max_hs", 0)),
            "ucs": float(f.get("ucs", 0)),
            "mse": float(f.get("mse", 0)),
            "color": f.get("color", "#888888"),
            "description": f.get("description", ""),
        })
    df = pd.DataFrame(rows)
    edited = st.data_editor(
        df,
        num_rows="dynamic",
        use_container_width=True,
        key="formations_editor",
        height=360,
        disabled=["tvd"],  # TVD from wellpath only
        column_config={
            "lithology": st.column_config.SelectboxColumn("Lithology", options=[
                "Anhydrite", "Shale", "Sand/Sandstone", "Limestone", "Dolomite", "Salt", "Coal", "Other"
            ]),
            "name": st.column_config.TextColumn("Name"),
            "porosity": st.column_config.NumberColumn("Porosity", format="%.3f"),
            "permeability": st.column_config.NumberColumn("Perm mD", format="%.1f"),
            "md": st.column_config.NumberColumn("MD ft", format="%.2f"),
            "tvd": st.column_config.NumberColumn("TVD ft (auto)", format="%.2f"),
            "ppg": st.column_config.NumberColumn("PPG ppg", format="%.2f"),
            "wbsg": st.column_config.NumberColumn("WBSG ppg", format="%.2f"),
            "fit": st.column_config.NumberColumn("FIT ppg", format="%.2f"),
            "fpg": st.column_config.NumberColumn("FPG ppg", format="%.2f"),
            "lot": st.column_config.NumberColumn("LOT ppg", format="%.2f"),
            "min_hs": st.column_config.NumberColumn("Min HS Grad", format="%.2f"),
            "max_hs": st.column_config.NumberColumn("Max HS Grad", format="%.2f"),
            "d_max_hs": st.column_config.NumberColumn("D Max HS °", format="%.1f"),
            "ucs": st.column_config.NumberColumn("UCS psi", format="%.0f"),
            "mse": st.column_config.NumberColumn("MSE psi", format="%.0f"),
            "color": st.column_config.TextColumn("Color"),
            "description": st.column_config.TextColumn("Description"),
        }
    )

    # Lithology color strip
    st.markdown("##### Column preview")
    fig = go.Figure()
    total = max(state.geometry.bit_depth, state.geometry.md, 1)
    tmp = enrich_formations_tvd(edited.to_dict("records"), state.wellpath)
    for layer in tmp:
        y0 = (float(layer["md_top"]) / total) * 100
        y1 = min((float(layer["md_bot"]) / total) * 100, 100)
        fig.add_shape(type="rect", x0=0.2, x1=0.8, y0=y0, y1=y1,
                      fillcolor=layer.get("color", "#888"), opacity=0.9, line=dict(width=0.5, color="#222"))
        if y1 - y0 > 3:
            fig.add_annotation(x=0.5, y=(y0+y1)/2, text=layer.get("name", ""), showarrow=False,
                               font=dict(size=10, color="#111"))
    fig.update_layout(height=320, margin=dict(l=10,r=10,t=10,b=10), paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23",
                      xaxis=dict(visible=False, range=[0,1]),
                      yaxis=dict(range=[100, 0], title="MD %", color="#aaa", gridcolor="#333"))
    st.plotly_chart(fig, use_container_width=True)

    b1, b2 = st.columns(2)
    with b1:
        if st.button("Apply Formations", type="primary", use_container_width=True):
            recs = edited.to_dict("records")
            state.lithology = enrich_formations_tvd(recs, state.wellpath)
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(
                st.session_state.state, "Formations Applied", f"n={len(state.lithology)}"
            )
            st.rerun()
    with b2:
        if st.button("Reset Formations defaults", use_container_width=True):
            state.lithology = [dict(x) for x in DEFAULT_LITHOLOGY]
            st.session_state.state = run_hydraulics(state)
            st.rerun()

    form = None
    if state.lithology:
        from engines.hydraulics_engine import get_formation_at_depth
        form = get_formation_at_depth(state.lithology, state.geometry.bit_depth)
    if form:
        st.info(
            f"At bit: **{form.get('name')}** ({form.get('lithology')}) · "
            f"PPG {form.get('ppg', 0):.2f} · FPG {form.get('fpg', 0):.2f} · "
            f"Live PP {state.live_pp:.0f} psi · Overbalance {state.overbalance:.0f} psi"
        )

elif nav == "Temperatures":
    st.subheader("Temperature Profile")
    st.caption("Enter **TVD & Temperature** from MWD/LWD or geothermal gradient. Profile drives density & viscosity corrections → BHP/ECD.")

    left, right = st.columns([1.3, 1.0])
    with left:
        st.markdown("##### Stations (TVD, Temp °F)")
        raw = state.temp_profile if state.temp_profile else [dict(x) for x in DEFAULT_TEMP_PROFILE]
        df = pd.DataFrame([{"tvd": r.get("tvd", 0), "temp_f": r.get("temp_f", 90)} for r in raw])
        edited = st.data_editor(
            df, num_rows="dynamic", use_container_width=True, key="temp_editor", height=260,
            column_config={
                "tvd": st.column_config.NumberColumn("TVD ft", format="%.2f"),
                "temp_f": st.column_config.NumberColumn("Temperature °F", format="%.2f"),
            }
        )
        stations = edited.to_dict("records")

        st.markdown("##### Build from Gradient")
        g1, g2, g3 = st.columns(3)
        surf = g1.number_input("Surface / Ambient °F", value=float(state.fluid.ambient_temp))
        grad = g2.number_input("Gradient °F/100ft", value=float(state.fluid.temp_gradient), format="%.2f")
        max_t = g3.number_input("Max TVD ft", value=float(max(state.geometry.tvd, 10000)))
        if st.button("Generate from Gradient"):
            stations = build_temp_profile_from_gradient(surf, grad, max_t, step=1000.0)
            state.fluid.ambient_temp = surf
            state.fluid.temp_gradient = grad
            state.temp_profile = stations
            st.session_state.state = run_hydraulics(state)
            st.rerun()

        c1, c2 = st.columns(2)
        with c1:
            if st.button("Apply Temperature Profile", type="primary", use_container_width=True):
                state.temp_profile = stations
                st.session_state.state = run_hydraulics(state)
                t_bit = temp_at_tvd(stations, state.geometry.tvd, state.fluid.ambient_temp, state.fluid.temp_gradient)
                st.session_state.state = add_timeline_event(
                    st.session_state.state, "Temp Profile", f"T@bit={t_bit:.1f}°F, pts={len(stations)}"
                )
                st.rerun()
        with c2:
            if st.button("Reset defaults", use_container_width=True):
                state.temp_profile = [dict(x) for x in DEFAULT_TEMP_PROFILE]
                st.session_state.state = run_hydraulics(state)
                st.rerun()

    with right:
        st.markdown("##### Circulating Temps (Mud)")
        state.fluid.temp_in = st.number_input("Mud Temp In °F", value=float(state.fluid.temp_in))
        state.fluid.temp_out = st.number_input("Mud Temp Out °F", value=float(state.fluid.temp_out))
        state.fluid.ref_temp = st.number_input("Ref Temp °F (density)", value=float(getattr(state.fluid, 'ref_temp', 90.0)))
        t_bit = temp_at_tvd(stations if stations else state.temp_profile, state.geometry.tvd,
                            state.fluid.ambient_temp, state.fluid.temp_gradient)
        t_mid = temp_at_tvd(stations if stations else state.temp_profile, state.geometry.tvd * 0.5,
                            state.fluid.ambient_temp, state.fluid.temp_gradient)
        st.metric("T @ Bit (from profile)", f"{t_bit:.1f} °F")
        st.metric("T @ Mid TVD", f"{t_mid:.1f} °F")
        st.metric("Corrected Density", f"{state.corrected_density:.3f} ppg")
        st.caption("Density ↓ with T · Viscosity (K) ↓ with T → friction & ECD change")

    # Chart
    if stations or state.temp_profile:
        pts = stations if stations else state.temp_profile
        pts = sorted(pts, key=lambda x: float(x.get("tvd", 0)))
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=[float(p["temp_f"]) for p in pts],
            y=[float(p["tvd"]) for p in pts],
            mode="lines+markers",
            line=dict(color="#4a9eff", width=2),
            marker=dict(size=7),
            name="Formation / Survey Temp"
        ))
        # circulating mud line (in at surface → out blended)
        fig.add_trace(go.Scatter(
            x=[state.fluid.temp_in, state.fluid.temp_out],
            y=[0, state.geometry.tvd],
            mode="lines",
            line=dict(color="#00d4aa", width=2, dash="dash"),
            name="Mud In → Out (circ)"
        ))
        fig.update_layout(
            title="Temperature vs TVD",
            paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"),
            height=360, margin=dict(t=40, b=30),
            xaxis_title="Temperature °F", yaxis_title="TVD ft",
            yaxis=dict(autorange="reversed"),
            legend=dict(orientation="h")
        )
        st.plotly_chart(fig, use_container_width=True)

elif nav == "Fluid Properties":
    st.subheader("Fluid Properties – Mud Library")
    st.caption("Define multiple muds (name, weight, rheology). Assign **Pump Fluid** to use in hydraulics (Victus-style).")

    left, right = st.columns([2.2, 1.0])

    with right:
        st.markdown("##### Fluid Roles")
        names = [f.get("name", f"Mud-{i}") for i, f in enumerate(state.fluid_library)] or ["(empty)"]
        def _idx(name, names):
            return names.index(name) if name in names else 0
        state.pump_fluid_name = st.selectbox("Pump Fluid (active)", names, index=_idx(state.pump_fluid_name, names), key="pump_sel")
        state.offset_fluid_name = st.selectbox("Offset Fluid", names, index=_idx(state.offset_fluid_name, names), key="off_sel")
        state.initial_fluid_name = st.selectbox("Initial Fluid", names, index=_idx(state.initial_fluid_name, names), key="ini_sel")
        st.markdown("---")
        st.markdown("##### Library")
        for f in state.fluid_library:
            col = f.get("color", "#666")
            active = "◀ PUMP" if f.get("name") == state.pump_fluid_name else ""
            st.markdown(
                f"<div style='background:{col};color:#fff;padding:6px 8px;margin:3px 0;border-radius:4px;font-size:12px'>"
                f"<b>{f.get('name','')}</b><br>MW {f.get('density_ppg',0):.2f} · {f.get('mud_type','')} {active}</div>",
                unsafe_allow_html=True
            )
        st.markdown("---")
        st.markdown("##### Pump into Well")
        mins = st.number_input("Pump duration (min)", min_value=0.5, max_value=500.0, value=5.0, step=0.5)
        if st.button("▶ Pump Selected Fluid", type="primary", use_container_width=True):
            st.session_state.state = pump_fluid_step(state, minutes=float(mins))
            st.session_state.state = run_hydraulics(st.session_state.state)
            st.session_state.state = add_timeline_event(
                st.session_state.state, "Pumped Fluid",
                f"{state.pump_fluid_name} × {mins} min @ {state.operating.flow_in_gpm:.0f} gpm"
            )
            st.rerun()
        if st.button("Init Columns (Initial Fluid)", use_container_width=True):
            init_fluid_columns(state)
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Columns Init", state.initial_fluid_name)
            st.rerun()
        if st.button("Apply Pump Fluid props only", use_container_width=True):
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Pump Fluid", state.pump_fluid_name)
            st.rerun()

        # Column status
        st.markdown("##### Column Status")
        if state.ann_column:
            for seg in state.ann_column:
                st.caption(f"ANN {seg['name']}: {seg['md_top']:.0f}–{seg['md_bot']:.0f} ft · {seg['density_ppg']:.2f} ppg")
        else:
            st.caption("Annulus empty – press Init Columns")
        if state.pipe_column:
            for seg in state.pipe_column:
                st.caption(f"PIPE {seg['name']}: {seg['md_top']:.0f}–{seg['md_bot']:.0f} ft · {seg['density_ppg']:.2f} ppg")

    with left:
        st.markdown("##### Edit / Add Mud")
        # Select which library entry to edit
        edit_name = st.selectbox("Select mud to edit", names, key="edit_mud_sel")
        entry = next((dict(f) for f in state.fluid_library if f.get("name") == edit_name), dict(DEFAULT_FLUID_LIBRARY[0]))

        c1, c2, c3 = st.columns(3)
        with c1:
            entry["name"] = st.text_input("Name", value=str(entry.get("name", "New Mud")))
            entry["mud_type"] = st.selectbox("Mud Type", ["Oil Base", "Water Base", "Synthetic"],
                index=["Oil Base", "Water Base", "Synthetic"].index(entry.get("mud_type", "Oil Base"))
                if entry.get("mud_type") in ["Oil Base", "Water Base", "Synthetic"] else 0)
            entry["density_ppg"] = st.number_input("Mud Weight (ppg)", value=float(entry.get("density_ppg", 10.5)), format="%.2f")
            entry["color"] = st.color_picker("Fill Color", value=str(entry.get("color", "#8B0000")))
        with c2:
            entry["temp_in"] = st.number_input("Mud Inlet Temp °F", value=float(entry.get("temp_in", 120)))
            entry["ref_temp"] = st.number_input("Ref Temp °F", value=float(entry.get("ref_temp", 90)))
            entry["salt_type"] = st.text_input("Salt Type", value=str(entry.get("salt_type", "CaCl2")))
            entry["salinity_wt"] = st.number_input("Salinity Wt%", value=float(entry.get("salinity_wt", 0)))
            entry["ph"] = st.number_input("pH", value=float(entry.get("ph", 9.5)))
        with c3:
            entry["retort_oil"] = st.number_input("Retort Oil %", value=float(entry.get("retort_oil", 0)))
            entry["retort_water"] = st.number_input("Retort Water %", value=float(entry.get("retort_water", 0)))
            entry["solids"] = st.number_input("Solids %", value=float(entry.get("solids", 0)))

        st.markdown("##### Dial Readings (Fann)")
        d1, d2, d3, d4 = st.columns(4)
        entry["r600"] = d1.number_input("θ600", value=float(entry.get("r600", 60)))
        entry["r300"] = d2.number_input("θ300", value=float(entry.get("r300", 40)))
        entry["r200"] = d3.number_input("θ200", value=float(entry.get("r200", 32)))
        entry["r100"] = d4.number_input("θ100", value=float(entry.get("r100", 22)))
        d5, d6, d7, d8 = st.columns(4)
        entry["r6"] = d5.number_input("θ6", value=float(entry.get("r6", 8)))
        entry["r3"] = d6.number_input("θ3", value=float(entry.get("r3", 6)))
        entry["gel_10s"] = d7.number_input("Gel 10s", value=float(entry.get("gel_10s", 6)))
        entry["gel_10m"] = d8.number_input("Gel 10m", value=float(entry.get("gel_10m", 10)))

        if st.button("Fit Herschel-Bulkley from Dials"):
            fit = fit_hb_from_fann(entry["r600"], entry["r300"], entry.get("r200"), entry.get("r100"), entry.get("r6"), entry.get("r3"))
            entry.update(fit)
            st.success(f"Fitted: n={fit['n']}, K={fit['K']}, τy={fit['tau_y']}, PV={fit['pv']}, YP={fit['yp']}")

        st.markdown("##### Rheology (Herschel-Bulkley)")
        r1, r2, r3 = st.columns(3)
        entry["n"] = r1.number_input("n", value=float(entry.get("n", 0.7)), format="%.3f")
        entry["K"] = r2.number_input("K", value=float(entry.get("K", 0.45)), format="%.3f")
        entry["tau_y"] = r3.number_input("τy", value=float(entry.get("tau_y", 4.0)), format="%.2f")
        r4, r5, r6 = st.columns(3)
        entry["pv"] = r4.number_input("PV cP", value=float(entry.get("pv", 20)))
        entry["yp"] = r5.number_input("YP", value=float(entry.get("yp", 12)))
        entry["lsyp"] = r6.number_input("LSYP", value=float(entry.get("lsyp", 4)))

        # Rheology curve preview
        import numpy as np
        gamma = np.linspace(1, 600, 50)
        n_v, K_v, ty = float(entry["n"]), float(entry["K"]), float(entry["tau_y"])
        tau = ty + K_v * (gamma ** n_v)
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=gamma, y=tau, name="HB Fit", line=dict(color="#00d4aa", width=2)))
        # dial points approx (rpm as shear proxy)
        for lab, rpm in [("600", entry["r600"]), ("300", entry["r300"]), ("200", entry.get("r200", 0)),
                         ("100", entry.get("r100", 0)), ("6", entry.get("r6", 0)), ("3", entry.get("r3", 0))]:
            fig.add_trace(go.Scatter(x=[float(lab)], y=[float(rpm)], mode="markers",
                                     marker=dict(size=8), name=f"θ{lab}", showlegend=False))
        fig.update_layout(title="Rheogram (τ vs rpm proxy)", paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23",
                          font=dict(color="#ccc"), height=260, margin=dict(t=40, b=30),
                          xaxis_title="rpm", yaxis_title="Dial / stress")
        st.plotly_chart(fig, use_container_width=True)

        b1, b2, b3 = st.columns(3)
        with b1:
            if st.button("Save Mud to Library", type="primary", use_container_width=True):
                # replace or append by original edit_name
                updated = False
                for i, f in enumerate(state.fluid_library):
                    if f.get("name") == edit_name:
                        state.fluid_library[i] = entry
                        updated = True
                        break
                if not updated:
                    state.fluid_library.append(entry)
                # if renamed pump, keep selection
                if state.pump_fluid_name == edit_name:
                    state.pump_fluid_name = entry["name"]
                st.session_state.state = run_hydraulics(state)
                st.session_state.state = add_timeline_event(st.session_state.state, "Mud Saved", entry["name"])
                st.rerun()
        with b2:
            if st.button("Add as New Mud", use_container_width=True):
                new_e = dict(entry)
                base = new_e.get("name", "Mud")
                new_e["name"] = base if base not in names else f"{base} (copy)"
                state.fluid_library.append(new_e)
                st.session_state.state = state
                st.rerun()
        with b3:
            if st.button("Delete Selected Mud", use_container_width=True) and len(state.fluid_library) > 1:
                state.fluid_library = [f for f in state.fluid_library if f.get("name") != edit_name]
                if state.pump_fluid_name == edit_name:
                    state.pump_fluid_name = state.fluid_library[0]["name"]
                st.session_state.state = run_hydraulics(state)
                st.rerun()

    st.info(f"Active pump fluid in calculations: **{state.pump_fluid_name}** · MW {state.fluid.density_ppg:.2f} ppg · n={state.fluid.n} · K={state.fluid.K}")

elif nav == "Main Time Data":
    st.subheader("Main Time Data – Live Trends")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Effective Flow", f"{state.effective_flow:.1f} gpm")
    m2.metric("Q Loss", f"{state.q_loss:.1f} gpm")
    m3.metric("Q U-Tube", f"{state.q_utube:.1f} gpm")
    m4.metric("Annular Friction", f"{state.annular_friction:.0f} psi")
    if len(state.history_bhp) > 2:
        fig = go.Figure()
        x = list(range(len(state.history_bhp)))
        fig.add_trace(go.Scatter(x=x, y=state.history_bhp, name="BHP", line=dict(color="#00d4aa", width=2)))
        fig.add_trace(go.Scatter(x=x, y=state.history_spp, name="Model SPP", line=dict(color="#4a9eff", width=2)))
        fig.add_trace(go.Scatter(x=x, y=[e*100 for e in state.history_ecd], name="ECD×100", line=dict(color="#ffaa00", width=2)))
        fig.update_layout(paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"),
                          height=300, margin=dict(t=20, b=30), legend=dict(orientation="h"))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Press **Step Simulation** or **Recalculate** a few times to build live trend history.")
    st.metric("Pipe Friction", f"{state.pipe_friction:.0f} psi")
    st.metric("Bit ΔP", f"{state.bit_pressure_drop:.0f} psi")
    st.metric("Corrected Density", f"{state.corrected_density:.2f} ppg")
    st.metric("Current Formation", state.current_formation)

elif nav == "Actual vs Model":
    st.subheader("Actual vs Model Diagnostics")
    st.caption("Primary drivers: Flow In/Out + Density + Temperature. SPP is secondary diagnostic only.")
    d1, d2, d3, d4 = st.columns(4)
    d1.metric("Flow In (Actual)", f"{state.operating.flow_in_gpm:.1f} gpm")
    d2.metric("Flow Out (Actual)", f"{state.operating.flow_out_gpm:.1f} gpm")
    d3.metric("ΔQ (In−Out)", f"{state.delta_flow:.1f} gpm")
    d4.metric("Q Loss (model)", f"{state.q_loss:.1f} gpm")
    st.markdown("---")
    s1, s2, s3 = st.columns(3)
    s1.metric("SPP Measured", f"{state.operating.spp_measured:.0f} psi")
    s2.metric("SPP Model", f"{state.model_spp:.0f} psi")
    s3.metric("Δ SPP (Meas−Model)", f"{state.delta_spp:+.0f} psi")
    st.markdown(f"**Status: {state.diag_status}**")
    st.info(state.diag_message)
    fig = go.Figure()
    fig.add_trace(go.Bar(name="Measured / Actual", x=["Flow In", "SPP"], y=[state.operating.flow_in_gpm, state.operating.spp_measured], marker_color="#4a9eff"))
    fig.add_trace(go.Bar(name="Model", x=["Flow In", "SPP"], y=[state.operating.flow_in_gpm, state.model_spp], marker_color="#00d4aa"))
    fig.update_layout(barmode="group", paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"), height=260, margin=dict(t=20, b=40))
    st.plotly_chart(fig, use_container_width=True)
    st.warning("SPP difference is diagnostic only and does NOT drive pressure calculations.")

elif nav == "Performance":
    st.subheader("Performance – Well Activities")
    summary = get_activity_summary(state)
    fig_pie = px.pie(names=list(summary.keys()), values=list(summary.values()),
                     color_discrete_sequence=px.colors.qualitative.Set2, hole=0.35)
    fig_pie.update_layout(paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"), height=320, margin=dict(t=30,b=20,l=20,r=20))
    col_p1, col_p2 = st.columns([1.4, 1])
    with col_p1:
        st.plotly_chart(fig_pie, use_container_width=True)
    with col_p2:
        for k, v in sorted(summary.items(), key=lambda x: -x[1]):
            st.write(f"• **{k}**: {v:.0f} min")
        act = st.selectbox("Activity type", ["Drilling", "Connection", "Circulating", "Trip", "Offline", "Other"])
        dur = st.number_input("Duration (min)", 0.5, 120.0, 5.0, 0.5)
        if st.button("Add Activity"):
            st.session_state.state = log_activity(state, act, dur)
            st.session_state.state = add_timeline_event(st.session_state.state, f"Activity: {act}", f"{dur} min")
            st.rerun()

elif nav == "Engineering":
    st.subheader("Engineering – Hydraulics Summary")
    e1, e2, e3 = st.columns(3)
    e1.metric("Hydrostatic", f"{state.hydrostatic:.0f} psi")
    e1.metric("Annular Friction", f"{state.annular_friction:.0f} psi")
    e1.metric("Pipe Friction", f"{state.pipe_friction:.0f} psi")
    e2.metric("Bit ΔP", f"{state.bit_pressure_drop:.0f} psi")
    e2.metric("U-Tube ΔP", f"{state.u_tube_dp:.0f} psi")
    e2.metric("Effective Flow", f"{state.effective_flow:.1f} gpm")
    e3.metric("Corrected Density", f"{state.corrected_density:.2f} ppg")
    e3.metric("Live PP Gradient", f"{state.litho_gradient:.3f} psi/ft")
    e3.metric("Overbalance", f"{state.overbalance:.0f} psi")
    budget = {"Hydrostatic": state.hydrostatic, "Annular Friction": state.annular_friction, "SBP": state.operating.sbp_setpoint}
    fig_bar = go.Figure(go.Bar(x=list(budget.keys()), y=list(budget.values()), marker_color=["#4a9eff", "#00d4aa", "#ffaa00"]))
    fig_bar.update_layout(paper_bgcolor="#1a1d23", plot_bgcolor="#1a1d23", font=dict(color="#ccc"), height=240, yaxis_title="psi", margin=dict(t=20,b=40))
    st.plotly_chart(fig_bar, use_container_width=True)

elif nav == "Timeline":
    st.subheader("Timeline / Feedback")
    ec1, ec2 = st.columns([3, 1])
    with ec1:
        new_event = st.text_input("Add event comment", placeholder="Connection, Pump up, Gas show...")
    with ec2:
        st.write(""); st.write("")
        if st.button("Add to Timeline", use_container_width=True) and new_event.strip():
            st.session_state.state = add_timeline_event(state, new_event.strip())
            st.rerun()
    if state.timeline:
        st.dataframe(pd.DataFrame(state.timeline), use_container_width=True, height=320)
    else:
        st.info("No events yet.")

elif nav == "Surge & Swab":
    st.subheader("Surge & Swab Calculator")
    sc1, sc2 = st.columns(2)
    with sc1:
        state.surge.pipe_velocity_ftmin = st.slider("Pipe Velocity (ft/min)", 5, 150, int(state.surge.pipe_velocity_ftmin))
        state.surge.acceleration = st.number_input("Acceleration (ft/s²)", 0.0, 3.0, float(state.surge.acceleration), 0.1)
        state.surge.open_end = st.checkbox("Open Ended", value=state.surge.open_end)
        state.surge.clinging_factor = st.slider("Clinging Factor", 0.1, 1.0, float(state.surge.clinging_factor), 0.05)
        if st.button("Calculate Surge/Swab", type="primary"):
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Surge/Swab", f"Vel={state.surge.pipe_velocity_ftmin}")
            st.session_state.state = log_activity(st.session_state.state, "Trip", 3.0)
            st.rerun()
    with sc2:
        st.metric("Max Surge", f"{state.max_surge_psi:.0f} psi")
        st.metric("Max Swab", f"{state.max_swab_psi:.0f} psi")
        st.metric("ESD Surge", f"{state.esd_surge:.2f} ppg")
        st.metric("ESD Swab", f"{state.esd_swab:.2f} ppg")
        st.metric("BHP @ Surge", f"{state.bhp + state.max_surge_psi:.0f} psi")
        st.metric("BHP @ Swab", f"{state.bhp + state.max_swab_psi:.0f} psi")

elif nav == "Choke Control":
    st.subheader("Choke Control Panel")
    cc1, cc2, cc3 = st.columns(3)
    with cc1:
        state.choke_mode = st.radio("Choke Mode", ["MANUAL", "AUTO", "CBHP"],
                                    index=["MANUAL", "AUTO", "CBHP"].index(state.choke_mode), horizontal=True)
    with cc2:
        if state.choke_mode == "CBHP":
            state.target_bhp = st.number_input("Target BHP (psi)", 0.0, 15000.0, float(state.target_bhp), 10.0)
        elif state.choke_mode == "AUTO":
            state.target_ecd = st.number_input("Target ECD (ppg)", 8.0, 18.0, float(state.target_ecd), 0.05)
        state.operating.sbp_setpoint = st.slider("SBP Setpoint (psi)", 0, 1000, int(state.operating.sbp_setpoint), 5)
    with cc3:
        st.metric("Choke Position", f"{state.operating.choke_position:.0f} %")
        st.metric("Current SBP", f"{state.operating.sbp_setpoint:.0f} psi")
        st.metric("Current BHP", f"{state.bhp:.0f} psi")
        st.metric("Current ECD", f"{state.ecd:.2f} ppg")
    if st.button("Apply Setpoint & Recalculate", type="primary", use_container_width=True):
        st.session_state.state = run_hydraulics(state)
        st.session_state.state = add_timeline_event(st.session_state.state, "Choke Apply", f"{state.choke_mode} SBP={state.operating.sbp_setpoint:.0f}")
        st.rerun()
    if state.choke_mode == "CBHP":
        st.success("CBHP Auto active in Simulation mode → SBP adjusts to hold Target BHP.")

elif nav == "MPD Gauges":
    st.subheader("MPD Gauges")
    g1, g2, g3, g4 = st.columns(4)
    g1.metric("BHP", f"{state.bhp:.0f} psi", f"{state.bhp - state.target_bhp:+.0f}")
    g2.metric("ECD", f"{state.ecd:.2f} ppg", f"{state.ecd - state.target_ecd:+.2f}")
    g3.metric("SBP", f"{state.operating.sbp_setpoint:.0f} psi")
    g4.metric("Overbalance", f"{state.overbalance:.0f} psi")
    if len(state.history_bhp) > 2:
        st.line_chart({"BHP": state.history_bhp, "ECD×100": [e*100 for e in state.history_ecd]})
    else:
        st.line_chart({"BHP": [state.bhp-40, state.bhp-15, state.bhp, state.bhp+8, state.bhp-5],
                       "ECD x100": [(state.ecd-0.08)*100, (state.ecd-0.03)*100, state.ecd*100, (state.ecd+0.02)*100, state.ecd*100]})

elif nav == "Settings":
    st.subheader("Settings (Setup)")
    tab_wp, tab_ws, tab_fluid, tab_bit, tab_app = st.tabs([
        "Well Profile (Intervals)", "Work String (BHA)", "Fluid & Rheology", "Bit", "App / Geometry"
    ])

    # ── Well Profile (Casing + Open Hole) – Victus Well Data style ──
    with tab_wp:
        st.markdown("##### Casing / Liner")
        st.caption("Type · OD · ID · Weight · MD Top/Bottom · Material · Friction Factor")
        cas_df = pd.DataFrame(state.casings) if state.casings else pd.DataFrame([{
            "type": "Surface Casing", "od_in": 9.63, "id_in": 8.675, "nw_lbft": 47.0,
            "md_top": 0.0, "md_bot": 9410.6, "tvd_top": 0.0, "tvd_bot": 9288.77,
            "material": "CS-K55", "friction_factor": 0.20
        }])
        # ensure columns
        for col, default in [
            ("type", "Casing"), ("od_in", 9.63), ("id_in", 8.675), ("nw_lbft", 47.0),
            ("md_top", 0.0), ("md_bot", 1000.0), ("tvd_top", 0.0), ("tvd_bot", 1000.0),
            ("material", "CS"), ("friction_factor", 0.20)
        ]:
            if col not in cas_df.columns:
                cas_df[col] = default
        edited_cas = st.data_editor(
            cas_df[["type", "od_in", "id_in", "nw_lbft", "md_top", "md_bot", "tvd_top", "tvd_bot", "material", "friction_factor"]],
            num_rows="dynamic",
            use_container_width=True,
            key="casings_editor",
            column_config={
                "type": st.column_config.TextColumn("Type", width="medium"),
                "od_in": st.column_config.NumberColumn("OD in", format="%.3f"),
                "id_in": st.column_config.NumberColumn("ID in", format="%.3f"),
                "nw_lbft": st.column_config.NumberColumn("NW lb/ft", format="%.2f"),
                "md_top": st.column_config.NumberColumn("MD Top ft", format="%.2f"),
                "md_bot": st.column_config.NumberColumn("MD Bot ft", format="%.2f"),
                "tvd_top": st.column_config.NumberColumn("TVD Top ft", format="%.2f"),
                "tvd_bot": st.column_config.NumberColumn("TVD Bot ft", format="%.2f"),
                "material": st.column_config.TextColumn("Material"),
                "friction_factor": st.column_config.NumberColumn("Fric.Factor", format="%.2f"),
            }
        )

        st.markdown("##### Open Hole")
        oh_df = pd.DataFrame(state.open_hole) if state.open_hole else pd.DataFrame([
            {"md_top": 9410.6, "md_bot": 12000.0, "hole_id_in": 8.5, "friction_factor": 0.25}
        ])
        for col, default in [("md_top", 0.0), ("md_bot", 1000.0), ("hole_id_in", 8.5), ("friction_factor", 0.25)]:
            if col not in oh_df.columns:
                oh_df[col] = default
        edited_oh = st.data_editor(
            oh_df[["md_top", "md_bot", "hole_id_in", "friction_factor"]],
            num_rows="dynamic",
            use_container_width=True,
            key="openhole_editor",
            column_config={
                "md_top": st.column_config.NumberColumn("MD Top ft", format="%.2f"),
                "md_bot": st.column_config.NumberColumn("MD Bot ft", format="%.2f"),
                "hole_id_in": st.column_config.NumberColumn("Hole ID in", format="%.3f"),
                "friction_factor": st.column_config.NumberColumn("Fric.Factor", format="%.2f"),
            }
        )

        # Validation
        cas_list = edited_cas.to_dict("records")
        oh_list = edited_oh.to_dict("records")
        conflicts = validate_well_intervals(cas_list, oh_list)
        if conflicts:
            for msg in conflicts:
                st.error(msg)
        else:
            st.success("No OD/ID or depth conflicts detected in Well Profile.")

        c1, c2 = st.columns(2)
        with c1:
            if st.button("Apply Well Profile", type="primary", use_container_width=True):
                state.casings = cas_list
                state.open_hole = oh_list
                st.session_state.state = run_hydraulics(state)
                st.session_state.state = add_timeline_event(st.session_state.state, "Well Profile Applied",
                                                           f"Casings={len(cas_list)}, OH={len(oh_list)}")
                st.rerun()
        with c2:
            if st.button("Reset Well Profile to defaults", use_container_width=True):
                state.casings = [dict(x) for x in DEFAULT_CASINGS]
                state.open_hole = [dict(x) for x in DEFAULT_OPEN_HOLE]
                st.session_state.state = run_hydraulics(state)
                st.rerun()


    # ── Work String / BHA (Victus style) ──
    with tab_ws:
        st.markdown("##### Work String / BHA")
        st.caption("Order: Bit at top of table (bottom of well) → DP toward surface. Qty multiplies length & weight.")
        ws = state.work_string if state.work_string else [dict(x) for x in DEFAULT_WORK_STRING]
        ws_df = pd.DataFrame(ws)
        for col, default in [
            ("desc", ""), ("qty", 1), ("conn_bot", ""), ("conn_top", ""),
            ("od_in", 5.0), ("id_in", 4.0), ("max_od_in", 5.0),
            ("len_ft", 30.0), ("nw_lbft", 20.0), ("body", "DP")
        ]:
            if col not in ws_df.columns:
                ws_df[col] = default
        edited_ws = st.data_editor(
            ws_df[["desc", "qty", "conn_bot", "conn_top", "od_in", "id_in", "max_od_in", "len_ft", "nw_lbft", "body"]],
            num_rows="dynamic",
            use_container_width=True,
            key="workstring_editor",
            height=360,
            column_config={
                "desc": st.column_config.TextColumn("Tool / Description", width="medium"),
                "qty": st.column_config.NumberColumn("Qty", min_value=1, step=1),
                "conn_bot": st.column_config.TextColumn("Conn Bot"),
                "conn_top": st.column_config.TextColumn("Conn Top"),
                "od_in": st.column_config.NumberColumn("OD in", format="%.3f"),
                "id_in": st.column_config.NumberColumn("ID in", format="%.3f"),
                "max_od_in": st.column_config.NumberColumn("Max OD in", format="%.3f"),
                "len_ft": st.column_config.NumberColumn("Len ft", format="%.2f"),
                "nw_lbft": st.column_config.NumberColumn("NW lb/ft", format="%.2f"),
                "body": st.column_config.SelectboxColumn("Body", options=["Bit", "BHA", "HWDP", "DP", "Other"]),
            }
        )
        ws_list = edited_ws.to_dict("records")
        total_len = work_string_total_length(ws_list)
        max_od = work_string_max_od(ws_list)
        st.markdown(f"**Total length:** {total_len:.1f} ft &nbsp;|&nbsp; **Max OD:** {max_od:.3f} in &nbsp;|&nbsp; **Bit depth:** {state.geometry.bit_depth:.1f} ft")

        conflicts = validate_work_string(ws_list, state.casings, state.open_hole, state.geometry.bit_depth)
        if conflicts:
            for msg in conflicts:
                st.warning(msg) if "tight clearance" in msg else st.error(msg)
        else:
            st.success("No critical OD/ID conflicts between Work String and Well Profile.")

        c1, c2 = st.columns(2)
        with c1:
            if st.button("Apply Work String", type="primary", use_container_width=True):
                state.work_string = ws_list
                st.session_state.state = run_hydraulics(state)
                st.session_state.state = add_timeline_event(
                    st.session_state.state, "Work String Applied",
                    f"Joints={len(ws_list)}, Len={total_len:.0f}ft, MaxOD={max_od:.2f}"
                )
                st.rerun()
        with c2:
            if st.button("Reset Work String defaults", use_container_width=True):
                state.work_string = [dict(x) for x in DEFAULT_WORK_STRING]
                st.session_state.state = run_hydraulics(state)
                st.rerun()

    # ── Fluid & Rheology ──
    with tab_fluid:
        st.markdown("##### Mud Properties")
        state.fluid.density_ppg = st.number_input("Mud Density (ppg)", value=float(state.fluid.density_ppg))
        state.fluid.temp_in = st.number_input("Mud Temp In (°F)", value=float(state.fluid.temp_in))
        state.fluid.temp_out = st.number_input("Mud Temp Out (°F)", value=float(state.fluid.temp_out))
        state.fluid.ambient_temp = st.number_input("Ambient Temp (°F)", value=float(state.fluid.ambient_temp))
        state.fluid.temp_gradient = st.number_input("Temp Gradient (°F/100ft)", value=float(state.fluid.temp_gradient))
        st.markdown("##### Herschel-Bulkley Rheology")
        st.caption("n = Flow Behavior Index (usually 0.4–0.9) · K = Consistency Index · τy = Yield Stress")
        state.fluid.n = st.number_input("n (HB) – Flow Behavior Index", value=float(state.fluid.n), format="%.3f",
                                        help="n<1 shear-thinning. Typical OBM/WBM: 0.5–0.8")
        state.fluid.K = st.number_input("K (HB) – Consistency Index", value=float(state.fluid.K), format="%.3f",
                                        help="Higher K = thicker mud. Units lb·sⁿ/100ft²")
        state.fluid.tau_y = st.number_input("τy Yield Stress (lb/100ft²)", value=float(state.fluid.tau_y), format="%.2f")
        state.fluid.pv = st.number_input("PV (cP) – Bingham ref", value=float(state.fluid.pv))
        state.fluid.yp = st.number_input("YP (lb/100ft²) – Bingham ref", value=float(state.fluid.yp))
        if st.button("Apply Fluid", type="primary"):
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Fluid Applied")
            st.rerun()

    # ── Bit ──
    with tab_bit:
        state.bit.bit_type = st.selectbox("Bit Type", ["PDC", "Diamond Impregnated", "Tricone"],
                                          index=["PDC", "Diamond Impregnated", "Tricone"].index(state.bit.bit_type)
                                          if state.bit.bit_type in ["PDC", "Diamond Impregnated", "Tricone"] else 0)
        state.bit.bit_size = st.number_input("Bit Size (in)", value=float(state.bit.bit_size), format="%.3f")
        state.bit.tfa = st.number_input("TFA (in²)", value=float(state.bit.tfa), format="%.3f")
        state.bit.nozzles = st.text_input("Nozzles (1/32 in)", value=str(state.bit.nozzles))
        if st.button("Apply Bit", type="primary"):
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Bit Applied")
            st.rerun()

    # ── App / Geometry summary ──
    with tab_app:
        new_name = st.text_input("Application Display Name", value=st.session_state.app_name)
        if st.button("Update Name"):
            st.session_state.app_name = new_name
            st.success(f"Name set to: {new_name}")
            st.rerun()
        st.markdown("---")
        st.markdown("**Well Geometry (summary – auto-synced from Well Profile when possible)**")
        state.geometry.md = st.number_input("Total MD (ft)", value=float(state.geometry.md))
        state.geometry.tvd = st.number_input("TVD (ft)", value=float(state.geometry.tvd))
        state.geometry.bit_depth = st.number_input("Bit Depth (ft)", value=float(state.geometry.bit_depth))
        state.geometry.pipe_od = st.number_input("Pipe OD (in) – main string", value=float(state.geometry.pipe_od))
        state.geometry.pipe_id = st.number_input("Pipe ID (in)", value=float(state.geometry.pipe_id))
        st.caption(f"Hole ID at bit (from intervals): **{state.geometry.hole_id:.3f} in** · Shoe: **{state.geometry.shoe_depth:.1f} ft**")
        if st.button("Apply Geometry & Recalculate", type="primary"):
            st.session_state.state = run_hydraulics(state)
            st.session_state.state = add_timeline_event(st.session_state.state, "Geometry Applied")
            st.rerun()

else:
    st.subheader(nav)
    st.info(f"Module **{nav}** ready.")

st.markdown("<hr style='border-color:#333'>", unsafe_allow_html=True)
st.caption(f"{st.session_state.app_name} | Stage 14 | Formations | Excel v4 physics")
