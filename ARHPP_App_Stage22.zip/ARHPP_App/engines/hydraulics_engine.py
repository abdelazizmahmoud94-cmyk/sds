"""
ARHPP Hydraulics Engine – Stage 21 (Physics Fixes)
PROTOTYPE / EDUCATIONAL – NOT FOR OPERATIONAL OR WELL-CONTROL DECISIONS
Fixes: pump volumetric formula, volume-queue multi-fluid, U-tube indicator,
survey-aware hydrostatic, no Flow-Out mutation, no pit auto-integrate,
full annular friction in SPP, no friction caps, generic formations.
+ Save / Load state (JSON)
+ All previous features
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any
from datetime import datetime
import math
import json

DEFAULT_LITHOLOGY = [
    # Generic formation table – user-editable. MD tops entered by user; TVD from wellpath.
    # ppg = pore pressure gradient (ppg equivalent), fpg = fracture gradient (ppg).
    # These are EXAMPLE defaults only – replace with well-specific data.
    {"lithology": "Anhydrite", "name": "Formation A (Surface)", "md": 0.0, "md_top": 0.0, "md_bot": 800.0,
     "porosity": 0.0, "permeability": 0.0, "ppg": 8.6, "wbsg": 0.0, "fit": 14.0, "fpg": 14.0,
     "lot": 0.0, "min_hs": 0.0, "max_hs": 0.0, "d_max_hs": 0.0, "ucs": 12000.0, "mse": 0.0,
     "color": "#e07070", "pp_grad": 0.447, "fg_grad": 0.728, "description": "User-defined surface formation"},
    {"lithology": "Shale", "name": "Formation B (Shale)", "md": 800.0, "md_top": 800.0, "md_bot": 3500.0,
     "porosity": 0.05, "permeability": 5.0, "ppg": 9.0, "wbsg": 0.0, "fit": 14.5, "fpg": 14.5,
     "lot": 0.0, "min_hs": 0.0, "max_hs": 0.0, "d_max_hs": 0.0, "ucs": 8000.0, "mse": 0.0,
     "color": "#8b7355", "pp_grad": 0.468, "fg_grad": 0.754, "description": "User-defined intermediate shale"},
    {"lithology": "Limestone", "name": "Formation C (Carbonate)", "md": 3500.0, "md_top": 3500.0, "md_bot": 7000.0,
     "porosity": 0.10, "permeability": 20.0, "ppg": 9.5, "wbsg": 0.0, "fit": 15.0, "fpg": 15.0,
     "lot": 0.0, "min_hs": 0.0, "max_hs": 0.0, "d_max_hs": 0.0, "ucs": 11000.0, "mse": 0.0,
     "color": "#a0896c", "pp_grad": 0.494, "fg_grad": 0.780, "description": "User-defined carbonate interval"},
    {"lithology": "Sandstone", "name": "Formation D (Sand)", "md": 7000.0, "md_top": 7000.0, "md_bot": 9500.0,
     "porosity": 0.18, "permeability": 80.0, "ppg": 10.0, "wbsg": 0.0, "fit": 15.5, "fpg": 15.5,
     "lot": 0.0, "min_hs": 0.0, "max_hs": 0.0, "d_max_hs": 0.0, "ucs": 7000.0, "mse": 0.0,
     "color": "#c4a35a", "pp_grad": 0.520, "fg_grad": 0.806, "description": "User-defined sandstone reservoir"},
    {"lithology": "Shale", "name": "Formation E (Deep Shale)", "md": 9500.0, "md_top": 9500.0, "md_bot": 12000.0,
     "porosity": 0.04, "permeability": 2.0, "ppg": 10.5, "wbsg": 0.0, "fit": 16.0, "fpg": 16.0,
     "lot": 0.0, "min_hs": 0.0, "max_hs": 0.0, "d_max_hs": 0.0, "ucs": 9000.0, "mse": 0.0,
     "color": "#6b5b4f", "pp_grad": 0.546, "fg_grad": 0.832, "description": "User-defined deep shale"},
    {"lithology": "Limestone", "name": "Formation F (Deep Carbonate)", "md": 12000.0, "md_top": 12000.0, "md_bot": 15000.0,
     "porosity": 0.08, "permeability": 15.0, "ppg": 11.0, "wbsg": 0.0, "fit": 16.5, "fpg": 16.5,
     "lot": 0.0, "min_hs": 0.0, "max_hs": 0.0, "d_max_hs": 0.0, "ucs": 13000.0, "mse": 0.0,
     "color": "#7a6a5a", "pp_grad": 0.572, "fg_grad": 0.858, "description": "User-defined deep carbonate"},
]

# Well Intervals (Casing / Liner / Open Hole) – Victus Well Data style
DEFAULT_CASINGS = [
    {
        "type": "Surface Casing",
        "od_in": 9.630,
        "id_in": 8.675,
        "nw_lbft": 47.00,
        "md_top": 0.0,
        "md_bot": 9410.60,
        "tvd_top": 0.0,
        "tvd_bot": 9288.77,
        "material": "CS-K55",
        "friction_factor": 0.20,
    },
]

DEFAULT_OPEN_HOLE = [
    {
        "md_top": 9410.60,
        "md_bot": 9411.60,
        "hole_id_in": 12.250,
        "friction_factor": 0.20,
    },
    {
        "md_top": 9411.60,
        "md_bot": 12000.0,
        "hole_id_in": 8.500,
        "friction_factor": 0.25,
    },
]

# Work String / BHA – Victus style (bit at bottom index 0 conceptually when ordered bottom-up)
# order: index 0 = bit (bottom), last = top of string near surface
DEFAULT_WORK_STRING = [
    {"desc": "Diamond Impregnated Bit", "qty": 1, "conn_bot": "-", "conn_top": "4-1/2 REG",
     "od_in": 8.500, "id_in": 2.250, "max_od_in": 8.500, "len_ft": 0.59, "nw_lbft": 222.19, "body": "Bit"},
    {"desc": "STAB", "qty": 1, "conn_bot": "6-5/8 REG", "conn_top": "6-5/8 REG",
     "od_in": 6.750, "id_in": 4.200, "max_od_in": 8.155, "len_ft": 12.89, "nw_lbft": 5.71, "body": "BHA"},
    {"desc": "MONEL DC", "qty": 1, "conn_bot": "7-5/8 REG", "conn_top": "7-5/8 REG",
     "od_in": 6.813, "id_in": 3.250, "max_od_in": 6.813, "len_ft": 9.22, "nw_lbft": 7.99, "body": "BHA"},
    {"desc": "CROSS OVER", "qty": 1, "conn_bot": "6-5/8 REG", "conn_top": "NC50",
     "od_in": 7.000, "id_in": 5.500, "max_od_in": 8.000, "len_ft": 32.71, "nw_lbft": 2.25, "body": "BHA"},
    {"desc": "LSS", "qty": 1, "conn_bot": "NC50", "conn_top": "6-5/8 REG",
     "od_in": 6.875, "id_in": 3.875, "max_od_in": 6.875, "len_ft": 1.48, "nw_lbft": 49.87, "body": "BHA"},
    {"desc": "MONEL DC", "qty": 1, "conn_bot": "7-5/8 REG", "conn_top": "7-5/8 REG",
     "od_in": 6.813, "id_in": 5.901, "max_od_in": 6.813, "len_ft": 24.38, "nw_lbft": 3.02, "body": "BHA"},
    {"desc": "USS", "qty": 1, "conn_bot": "NC50", "conn_top": "6-5/8 REG",
     "od_in": 6.938, "id_in": 3.250, "max_od_in": 6.900, "len_ft": 1.64, "nw_lbft": 44.88, "body": "BHA"},
    {"desc": "FLOAT SUB", "qty": 1, "conn_bot": "NC50", "conn_top": "NC50",
     "od_in": 6.563, "id_in": 3.125, "max_od_in": 6.580, "len_ft": 8.83, "nw_lbft": 8.34, "body": "BHA"},
    {"desc": "HWDP short", "qty": 1, "conn_bot": "6-5/8 REG", "conn_top": "6-5/8 REG",
     "od_in": 6.813, "id_in": 2.375, "max_od_in": 6.800, "len_ft": 3.22, "nw_lbft": 22.90, "body": "HWDP"},
    {"desc": "HWDP short", "qty": 1, "conn_bot": "6-5/8 REG", "conn_top": "6-5/8 REG",
     "od_in": 6.813, "id_in": 2.375, "max_od_in": 6.810, "len_ft": 2.53, "nw_lbft": 29.15, "body": "HWDP"},
    {"desc": "MONEL DC", "qty": 1, "conn_bot": "7-5/8 REG", "conn_top": "7-5/8 REG",
     "od_in": 6.813, "id_in": 2.250, "max_od_in": 6.830, "len_ft": 3.22, "nw_lbft": 22.90, "body": "BHA"},
    {"desc": "MONEL DC", "qty": 1, "conn_bot": "7-5/8 REG", "conn_top": "7-5/8 REG",
     "od_in": 6.813, "id_in": 2.500, "max_od_in": 6.830, "len_ft": 2.89, "nw_lbft": 25.50, "body": "BHA"},
    {"desc": "CUSTOM", "qty": 1, "conn_bot": "6-5/8 REG", "conn_top": "6-5/8 REG",
     "od_in": 6.750, "id_in": 3.750, "max_od_in": 6.750, "len_ft": 5.81, "nw_lbft": 12.68, "body": "BHA"},
    {"desc": "Non-Mag Spiral HWDP", "qty": 6, "conn_bot": "NC50", "conn_top": "NC50",
     "od_in": 5.000, "id_in": 3.000, "max_od_in": 6.625, "len_ft": 30.59, "nw_lbft": 48.06, "body": "HWDP"},
    {"desc": "5\" DP", "qty": 1, "conn_bot": "NC44", "conn_top": "NC44",
     "od_in": 5.000, "id_in": 4.276, "max_od_in": 6.625, "len_ft": 32.81, "nw_lbft": 19.50, "body": "DP"},
]

# Default survey stations (MD, Inc, Azi required; rest calculated)
DEFAULT_WELLPATH = [
    {"md": 0.0, "inc": 0.0, "azi": 0.0},
    {"md": 1000.0, "inc": 0.5, "azi": 0.0},
    {"md": 3000.0, "inc": 5.0, "azi": 45.0},
    {"md": 6000.0, "inc": 25.0, "azi": 90.0},
    {"md": 9000.0, "inc": 45.0, "azi": 120.0},
    {"md": 11200.0, "inc": 60.0, "azi": 150.0},
    {"md": 12000.0, "inc": 65.0, "azi": 155.0},
]

DEFAULT_FLUID_LIBRARY = [
    {
        "name": "15.3 Oil Base", "mud_type": "Oil Base", "color": "#8B0000",
        "density_ppg": 15.30, "n": 0.61, "K": 0.61, "tau_y": 4.03, "pv": 13.4, "yp": 15.9, "lsyp": 4.51,
        "temp_in": 120.0, "ref_temp": 90.0, "salt_type": "CaCl2", "salinity_wt": 4.90,
        "retort_oil": 60.0, "retort_water": 13.8, "solids": 26.2, "ph": 10.0,
        "r600": 42.0, "r300": 31.0, "r200": 24.0, "r100": 15.0, "r6": 7.0, "r3": 5.0,
        "gel_10s": 6.0, "gel_10m": 10.0,
    },
    {
        "name": "13.8 PPG OBM", "mud_type": "Oil Base", "color": "#A52A2A",
        "density_ppg": 13.80, "n": 0.65, "K": 0.50, "tau_y": 5.0, "pv": 22.0, "yp": 14.0, "lsyp": 4.0,
        "temp_in": 120.0, "ref_temp": 90.0, "salt_type": "CaCl2", "salinity_wt": 4.0,
        "retort_oil": 55.0, "retort_water": 15.0, "solids": 20.0, "ph": 9.5,
        "r600": 55.0, "r300": 38.0, "r200": 30.0, "r100": 20.0, "r6": 8.0, "r3": 6.0,
        "gel_10s": 6.0, "gel_10m": 11.0,
    },
    {
        "name": "14.0 PPG OBM", "mud_type": "Oil Base", "color": "#B22222",
        "density_ppg": 14.00, "n": 0.63, "K": 0.55, "tau_y": 4.5, "pv": 20.0, "yp": 15.0, "lsyp": 4.2,
        "temp_in": 120.0, "ref_temp": 90.0, "salt_type": "CaCl2", "salinity_wt": 4.5,
        "retort_oil": 58.0, "retort_water": 14.0, "solids": 22.0, "ph": 10.0,
        "r600": 50.0, "r300": 35.0, "r200": 28.0, "r100": 18.0, "r6": 7.5, "r3": 5.5,
        "gel_10s": 6.0, "gel_10m": 10.0,
    },
    {
        "name": "9.2 WBM", "mud_type": "Water Base", "color": "#1E90FF",
        "density_ppg": 9.20, "n": 0.70, "K": 0.35, "tau_y": 3.0, "pv": 18.0, "yp": 12.0, "lsyp": 3.5,
        "temp_in": 110.0, "ref_temp": 80.0, "salt_type": "NaCl", "salinity_wt": 2.0,
        "retort_oil": 0.0, "retort_water": 85.0, "solids": 12.0, "ph": 9.0,
        "r600": 45.0, "r300": 30.0, "r200": 24.0, "r100": 16.0, "r6": 6.0, "r3": 4.0,
        "gel_10s": 4.0, "gel_10m": 8.0,
    },
    {
        "name": "Fresh Water", "mud_type": "Water Base", "color": "#4169E1",
        "density_ppg": 8.33, "n": 1.0, "K": 0.01, "tau_y": 0.0, "pv": 1.0, "yp": 0.0, "lsyp": 0.0,
        "temp_in": 80.0, "ref_temp": 70.0, "salt_type": "None", "salinity_wt": 0.0,
        "retort_oil": 0.0, "retort_water": 100.0, "solids": 0.0, "ph": 7.0,
        "r600": 2.0, "r300": 1.0, "r200": 1.0, "r100": 0.5, "r6": 0.0, "r3": 0.0,
        "gel_10s": 0.0, "gel_10m": 0.0,
    },
]

# Temperature profile stations: TVD (ft), Temperature (°F)
# Source: MWD/LWD points or geothermal gradient
DEFAULT_TEMP_PROFILE = [
    {"tvd": 0.0, "temp_f": 90.0},
    {"tvd": 2000.0, "temp_f": 115.0},
    {"tvd": 5000.0, "temp_f": 140.0},
    {"tvd": 8000.0, "temp_f": 160.0},
    {"tvd": 10672.0, "temp_f": 175.0},
]

DEFAULT_SURFACE_EQUIPMENT = [
    {"name": "Active Mud Tank", "type": "Tank", "volume_bbl": 400.0, "level_pct": 65.0, "active": True},
    {"name": "BOP", "type": "BOP", "rating_psi": 10000.0, "size_in": 13.625, "active": True},
    {"name": "Choke Manifold", "type": "ChokeManifold", "rating_psi": 10000.0, "active": True,
     "choke1_size_in": 3.0, "choke2_size_in": 3.0, "auto_choke": True},
    {"name": "Derrick", "type": "Derrick", "height_ft": 160.0, "hookload_kip": 1000.0, "active": True},
    {"name": "Instrumentation", "type": "Instrumentation", "active": True},
    {"name": "MGS", "type": "MGS", "capacity_gpm": 1200.0, "active": True},
    {"name": "MPD Manifold", "type": "MPDManifold", "rating_psi": 5000.0, "active": True},
    {"name": "Pump1", "type": "Pump", "pump_state": "Main", "efficiency": 96.0,
     "liner_in": 4.75, "stroke_in": 12.0, "pump_source": "StrokeCounter", "pump_type": "Triplex",
     "output_gal_stk": 2.65, "max_hhp": 2000.0, "max_flow_gpm": 1500.0,
     "max_pressure_psi": 5000.0, "pop_off_psi": 4500.0, "safety_factor": 90.0, "spm": 85.0, "active": True},
    {"name": "Pump2", "type": "Pump", "pump_state": "Standby", "efficiency": 96.0,
     "liner_in": 4.75, "stroke_in": 12.0, "pump_source": "StrokeCounter", "pump_type": "Triplex",
     "output_gal_stk": 2.65, "max_hhp": 2000.0, "max_flow_gpm": 1500.0,
     "max_pressure_psi": 5000.0, "pop_off_psi": 4500.0, "safety_factor": 90.0, "spm": 0.0, "active": True},
    {"name": "Pump3", "type": "Pump", "pump_state": "Off", "efficiency": 95.0,
     "liner_in": 5.5, "stroke_in": 12.0, "pump_source": "StrokeCounter", "pump_type": "Triplex",
     "output_gal_stk": 3.55, "max_hhp": 1600.0, "max_flow_gpm": 1200.0,
     "max_pressure_psi": 5000.0, "pop_off_psi": 4500.0, "safety_factor": 90.0, "spm": 0.0, "active": False},
    {"name": "Pump4", "type": "Pump", "pump_state": "Off", "efficiency": 95.0,
     "liner_in": 6.0, "stroke_in": 11.0, "pump_source": "StrokeCounter", "pump_type": "Triplex",
     "output_gal_stk": 3.80, "max_hhp": 1600.0, "max_flow_gpm": 1200.0,
     "max_pressure_psi": 5000.0, "pop_off_psi": 4500.0, "safety_factor": 90.0, "spm": 0.0, "active": False},
    {"name": "Pump5", "type": "Pump", "pump_state": "Off", "efficiency": 95.0,
     "liner_in": 6.0, "stroke_in": 11.0, "pump_source": "StrokeCounter", "pump_type": "Triplex",
     "output_gal_stk": 3.80, "max_hhp": 1600.0, "max_flow_gpm": 1200.0,
     "max_pressure_psi": 5000.0, "pop_off_psi": 4500.0, "safety_factor": 90.0, "spm": 0.0, "active": False},
    {"name": "Pump6", "type": "Pump", "pump_state": "Off", "efficiency": 95.0,
     "liner_in": 6.0, "stroke_in": 11.0, "pump_source": "StrokeCounter", "pump_type": "Duplex",
     "output_gal_stk": 2.50, "max_hhp": 1200.0, "max_flow_gpm": 900.0,
     "max_pressure_psi": 4000.0, "pop_off_psi": 3600.0, "safety_factor": 90.0, "spm": 0.0, "active": False},
    {"name": "RCD", "type": "RCD", "rating_psi": 3000.0, "size_in": 7.0625, "active": True},
    {"name": "Reserve Mud Tank", "type": "Tank", "volume_bbl": 300.0, "level_pct": 40.0, "active": True},
    {"name": "Shaker", "type": "Shaker", "screens": 3, "active": True},
    {"name": "Trip Tank", "type": "Tank", "volume_bbl": 40.0, "level_pct": 50.0, "active": True},
]

DEFAULT_PIPING = [
    {"name": "Standpipe", "from": "Pumps", "to": "Derrick", "id_in": 4.0, "length_ft": 80.0, "rating_psi": 5000.0},
    {"name": "Kelly Hose", "from": "Standpipe", "to": "Swivel", "id_in": 3.0, "length_ft": 60.0, "rating_psi": 5000.0},
    {"name": "Choke Line", "from": "BOP", "to": "Choke Manifold", "id_in": 3.0, "length_ft": 120.0, "rating_psi": 10000.0},
    {"name": "Kill Line", "from": "Pumps", "to": "BOP", "id_in": 3.0, "length_ft": 100.0, "rating_psi": 10000.0},
    {"name": "MPD Flow Line", "from": "RCD", "to": "MPD Manifold", "id_in": 4.0, "length_ft": 90.0, "rating_psi": 5000.0},
    {"name": "Return Line", "from": "MPD Manifold", "to": "Shaker", "id_in": 8.0, "length_ft": 150.0, "rating_psi": 500.0},
    {"name": "MGS Line", "from": "Choke Manifold", "to": "MGS", "id_in": 6.0, "length_ft": 80.0, "rating_psi": 500.0},
]






@dataclass
class WellGeometry:
    md: float = 12000.0
    tvd: float = 11200.0
    hole_id: float = 8.5
    pipe_od: float = 5.0
    pipe_id: float = 4.276
    casing_od: float = 9.625
    bit_depth: float = 12000.0
    shoe_depth: float = 9410.0

@dataclass
class FluidProperties:
    name: str = "Active Mud"
    mud_type: str = "Oil Base"  # Oil Base / Water Base / Synthetic
    color: str = "#8B0000"
    density_ppg: float = 10.5
    pv: float = 28.0
    yp: float = 18.0
    n: float = 0.72
    K: float = 0.45
    tau_y: float = 6.5
    lsyp: float = 4.5
    temp_in: float = 120.0
    temp_out: float = 155.0
    ambient_temp: float = 95.0
    ref_temp: float = 90.0
    temp_gradient: float = 1.5
    salt_type: str = "CaCl2"
    salinity_wt: float = 0.0
    retort_oil: float = 0.0
    retort_water: float = 0.0
    solids: float = 0.0
    ph: float = 9.5
    # Fann dial readings (lb/100ft²)
    r600: float = 60.0
    r300: float = 40.0
    r200: float = 32.0
    r100: float = 22.0
    r6: float = 8.0
    r3: float = 6.0
    gel_10s: float = 6.0
    gel_10m: float = 10.0

@dataclass
class OperatingParams:
    flow_in_gpm: float = 225.0
    flow_out_gpm: float = 225.0  # align with single-pump default; user/sensor owned
    sbp_setpoint: float = 200.0
    choke_position: float = 42.0
    rpm: float = 120.0
    wob: float = 25.0
    rop: float = 45.0
    spp_measured: float = 900.0
    pump_efficiency: float = 0.97
    gas_units: float = 0.0
    connection_gas: float = 0.0
    background_gas: float = 5.0
    trip_gas: float = 0.0
    # Pumps (Victus-style)
    pump1_spm: float = 85.0
    pump2_spm: float = 0.0
    pump3_spm: float = 0.0
    pump_liner_in: float = 6.0      # liner diameter inches
    pump_stroke_in: float = 12.0    # stroke length inches
    pump_count: int = 2             # duplex/triplex factor handled via efficiency
    total_strokes: float = 0.0      # cumulative strokes
    # Kick / Loss
    pit_gain_bbl: float = 0.0
    kick_flag: bool = False
    loss_flag: bool = False
    kick_severity: str = "None"      # None / Minor / Moderate / Severe
    loss_severity: str = "None"
    use_pump_flow: bool = True  # if True, SPM drives flow_in; else manual flow_in

@dataclass
class BitParams:
    bit_type: str = "PDC"
    tfa: float = 0.85
    bit_size: float = 8.5
    nozzles: str = "16/16/16/16/14/14"

@dataclass
class SurgeSwabParams:
    pipe_velocity_ftmin: float = 60.0
    acceleration: float = 0.5
    open_end: bool = True
    stand_length: float = 93.0
    clinging_factor: float = 0.45

@dataclass
class SimulationState:
    geometry: WellGeometry = field(default_factory=WellGeometry)
    fluid: FluidProperties = field(default_factory=FluidProperties)
    fluid_library: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_FLUID_LIBRARY])
    surface_equipment: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_SURFACE_EQUIPMENT])
    piping: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_PIPING])
    pump_fluid_name: str = "15.3 Oil Base"
    offset_fluid_name: str = "Fresh Water"
    initial_fluid_name: str = "15.3 Oil Base"
    # Multi-fluid columns: list of {name, md_top, md_bot, density_ppg, color}
    # pipe_column: fluid inside drillstring (0 = surface, md_bot toward bit)
    # ann_column: fluid in annulus (0 = surface)
    pipe_column: List[Dict] = field(default_factory=list)
    ann_column: List[Dict] = field(default_factory=list)
    column_initialized: bool = False
    operating: OperatingParams = field(default_factory=OperatingParams)
    bit: BitParams = field(default_factory=BitParams)
    surge: SurgeSwabParams = field(default_factory=SurgeSwabParams)
    mode: str = "Offline"
    choke_mode: str = "AUTO"
    target_bhp: float = 7500.0
    target_ecd: float = 11.20
    litho_gradient: float = 0.56
    lithology: List[Dict] = field(default_factory=lambda: DEFAULT_LITHOLOGY.copy())
    casings: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_CASINGS])
    open_hole: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_OPEN_HOLE])
    work_string: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_WORK_STRING])
    wellpath: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_WELLPATH])
    temp_profile: List[Dict] = field(default_factory=lambda: [dict(x) for x in DEFAULT_TEMP_PROFILE])
    timeline: List[Dict] = field(default_factory=list)
    activity_log: List[Dict] = field(default_factory=list)
    history_bhp: List[float] = field(default_factory=list)
    history_ecd: List[float] = field(default_factory=list)
    history_spp: List[float] = field(default_factory=list)
    history_flow: List[float] = field(default_factory=list)
    bhp: float = 0.0
    ecd: float = 0.0
    model_spp: float = 0.0
    surface_friction: float = 0.0
    annular_friction: float = 0.0
    pipe_friction: float = 0.0
    bit_pressure_drop: float = 0.0
    hydrostatic: float = 0.0
    live_pp: float = 0.0
    overbalance: float = 0.0
    # Pore pressure multi-method results (psi)
    pp_formation: float = 0.0      # from formation PPG × TVD
    pp_dexponent: float = 0.0     # from drilling params (d-exponent style)
    pp_gas: float = 0.0           # gas-show adjusted
    pp_temp: float = 0.0          # temperature influence branch
    pp_hybrid: float = 0.0        # weighted hybrid (primary live_pp)
    pp_gradient_ppg: float = 0.0  # hybrid in ppg
    fg_psi: float = 0.0           # fracture pressure at bit
    gas_units: float = 0.0        # total gas units (user/sensor)
    connection_gas: float = 0.0
    background_gas: float = 0.0
    trip_gas: float = 0.0
    d_exponent: float = 0.0
    dc_exponent: float = 0.0
    pp_mse: float = 0.0           # MSE-based estimate (horizontal/deviated friendly)
    pp_path: float = 0.0          # trajectory-corrected (inc/azi aware)
    mse_ksi: float = 0.0          # mechanical specific energy
    inclination_at_bit: float = 0.0
    azimuth_at_bit: float = 0.0
    wob_effective: float = 0.0    # path-corrected WOB component
    pp_history: List[float] = field(default_factory=list)
    bhp_history_pp: List[float] = field(default_factory=list)
    ecd_history_pp: List[float] = field(default_factory=list)
    fg_history: List[float] = field(default_factory=list)
    time_history: List[str] = field(default_factory=list)
    u_tube_dp: float = 0.0
    effective_flow: float = 0.0
    q_loss: float = 0.0
    q_utube: float = 0.0
    max_surge_psi: float = 0.0
    max_swab_psi: float = 0.0
    esd_surge: float = 0.0
    esd_swab: float = 0.0
    corrected_density: float = 0.0
    current_formation: str = "Formation D (Sand)"  # generic default – user editable
    delta_flow: float = 0.0
    delta_spp: float = 0.0
    diag_status: str = "OK"
    diag_message: str = ""

def _hydrostatic(density, tvd):
    return 0.052 * density * tvd

def _bit_dp(q, dens, tfa):
    if tfa <= 0: return 0.0
    return (q ** 2 * dens) / (12031.0 * tfa ** 2)

def _annular_velocity(q_gpm, hole_id, pipe_od):
    # v (ft/s) = 0.4085 * Q(gpm) / (Dh² - Dp²) with diameters in inches
    denom = (hole_id**2 - pipe_od**2)
    if denom <= 0:
        return 0.0
    return 0.4085 * q_gpm / denom

def _friction_factor(re):
    return 16.0 / max(re, 1.0) if re < 2100 else 0.046 * (re ** -0.2)

def _annular_friction(q, dens, hole_id, pipe_od, length, n, K, rpm=0):
    """Annular friction (psi) – calibrated practical model for Stage 8+.
    Uses effective viscosity from HB and a stable oilfield ΔP form.
    Typical result: 0.03–0.12 psi/ft in 8.5" x 5" at 800–1000 gpm.
    """
    dh = hole_id - pipe_od
    if dh <= 0 or length <= 0 or q <= 0:
        return 0.0
    v = _annular_velocity(q, hole_id, pipe_od)
    if v <= 0:
        return 0.0
    # Shear rate approximation (sec^-1)
    gamma = max((12.0 * v) / max(dh, 0.15), 1.0)
    # Apparent viscosity from HB (cP); K is lb·s^n/100ft² → scale ~100
    mu_app = K * 478.8 * (gamma ** (n - 1.0)) + 1.0  # more standard conversion-ish
    mu_app = max(min(mu_app, 200.0), 5.0)  # keep in realistic band
    re = 928.0 * dens * v * dh / mu_app
    if re < 2100:
        f = 16.0 / max(re, 10.0)
    else:
        f = 0.079 / (re ** 0.25)
    # ΔP = f * ρ * v² * L / (21.1 * dh)  — slightly softer constant for stability
    dp_per_ft = f * dens * (v ** 2) / (21.1 * dh)
    # Extra dependence on K/n (thicker mud → more loss)
    mud_factor = 0.7 + 0.3 * (K / 0.5) * (0.75 / max(n, 0.3))
    rpm_factor = 1.0 + 0.04 * (rpm / 120.0)
    total = dp_per_ft * length * mud_factor * rpm_factor
    return max(total, 0.0)  # no artificial cap

def _pipe_friction(q, dens, pipe_id, length, n, K):
    if pipe_id <= 0 or length <= 0 or q <= 0:
        return 0.0
    # v (ft/s) = 0.4085 * Q / d²  (pipe)
    if pipe_id <= 0:
        return 0.0
    v = 0.4085 * q / (pipe_id ** 2)
    if v <= 0:
        return 0.0
    gamma = max((8.0 * v) / max(pipe_id, 0.15), 1.0)
    mu_app = K * 478.8 * (gamma ** (n - 1.0)) + 1.0
    mu_app = max(min(mu_app, 200.0), 5.0)
    re = 928.0 * dens * v * pipe_id / mu_app
    if re < 2100:
        f = 16.0 / max(re, 10.0)
    else:
        f = 0.079 / (re ** 0.25)
    dp_per_ft = f * dens * (v ** 2) / (21.1 * pipe_id)
    mud_factor = 0.7 + 0.3 * (K / 0.5) * (0.75 / max(n, 0.3))
    total = dp_per_ft * length * mud_factor * 0.55
    return max(total, 0.0)  # no artificial cap

def _temp_corrected_density(base, temp_f, ref_temp=80.0, expansivity=0.0004):
    """Density decreases with temperature (thermal expansion).
    expansivity ~ 3e-4 to 5e-4 /°F for typical muds.
    """
    return base * (1.0 - expansivity * (float(temp_f) - float(ref_temp)))


def _temp_corrected_viscosity_factor(temp_f, ref_temp=120.0):
    """Viscosity decreases as temperature rises (approx exponential).
    factor multiplies K / PV. At higher temp → lower viscosity → lower friction.
    """
    # rough: every 20°F above ref → ~10% thinner
    dT = float(temp_f) - float(ref_temp)
    return max(0.4, min(1.6, 1.0 - 0.005 * dT))


def temp_at_tvd(temp_profile: List[Dict], tvd: float, fallback_surface=90.0, fallback_grad=1.5) -> float:
    """Interpolate formation/mud temperature at TVD from profile stations."""
    if not temp_profile:
        return fallback_surface + (tvd / 100.0) * fallback_grad
    pts = sorted(
        [{"tvd": float(p.get("tvd", 0)), "temp_f": float(p.get("temp_f", fallback_surface))} for p in temp_profile],
        key=lambda x: x["tvd"]
    )
    if tvd <= pts[0]["tvd"]:
        return pts[0]["temp_f"]
    if tvd >= pts[-1]["tvd"]:
        # extrapolate last gradient if possible
        if len(pts) >= 2:
            g = (pts[-1]["temp_f"] - pts[-2]["temp_f"]) / max(pts[-1]["tvd"] - pts[-2]["tvd"], 1.0)
            return pts[-1]["temp_f"] + g * (tvd - pts[-1]["tvd"])
        return pts[-1]["temp_f"]
    for i in range(1, len(pts)):
        if pts[i]["tvd"] >= tvd:
            t0, t1 = pts[i-1]["tvd"], pts[i]["tvd"]
            T0, T1 = pts[i-1]["temp_f"], pts[i]["temp_f"]
            f = (tvd - t0) / max(t1 - t0, 1e-9)
            return T0 + f * (T1 - T0)
    return pts[-1]["temp_f"]


def build_temp_profile_from_gradient(surface_temp: float, gradient_per_100ft: float, max_tvd: float, step: float = 1000.0) -> List[Dict]:
    rows = []
    tvd = 0.0
    while tvd <= max_tvd + 1:
        rows.append({"tvd": round(tvd, 1), "temp_f": round(surface_temp + (tvd / 100.0) * gradient_per_100ft, 2)})
        tvd += step
    if rows[-1]["tvd"] < max_tvd:
        rows.append({"tvd": round(max_tvd, 1), "temp_f": round(surface_temp + (max_tvd / 100.0) * gradient_per_100ft, 2)})
    return rows


def get_hole_id_at_depth(open_hole: List[Dict], casings: List[Dict], md: float, fallback: float = 8.5) -> float:
    """Return hole / casing ID at given MD from well intervals."""
    for oh in open_hole:
        if oh.get("md_top", 0) <= md <= oh.get("md_bot", 1e9):
            return float(oh.get("hole_id_in", fallback))
    # inside casing section – use last casing ID that covers this depth
    for c in reversed(casings):
        if c.get("md_top", 0) <= md <= c.get("md_bot", 1e9):
            return float(c.get("id_in", fallback))
    return fallback

def get_shoe_depth(casings: List[Dict]) -> float:
    if not casings:
        return 0.0
    return max(float(c.get("md_bot", 0)) for c in casings)

def validate_well_intervals(casings: List[Dict], open_hole: List[Dict]) -> List[str]:
    """Return list of conflict / warning messages for well profile."""
    msgs = []
    # OD > ID for each casing
    for i, c in enumerate(casings):
        od, id_ = float(c.get("od_in", 0)), float(c.get("id_in", 0))
        if od > 0 and id_ > 0 and id_ >= od:
            msgs.append(f"Casing[{i}] {c.get('type','')}: ID ({id_}) >= OD ({od})")
        if float(c.get("md_bot", 0)) <= float(c.get("md_top", 0)):
            msgs.append(f"Casing[{i}] {c.get('type','')}: md_bot <= md_top")
    for i, oh in enumerate(open_hole):
        if float(oh.get("md_bot", 0)) <= float(oh.get("md_top", 0)):
            msgs.append(f"OpenHole[{i}]: md_bot <= md_top")
        if float(oh.get("hole_id_in", 0)) <= 0:
            msgs.append(f"OpenHole[{i}]: invalid hole diameter")
    # continuity: open hole should start near last shoe
    if casings and open_hole:
        shoe = get_shoe_depth(casings)
        first_oh = min(float(oh.get("md_top", 0)) for oh in open_hole)
        if abs(first_oh - shoe) > 50:
            msgs.append(f"Open Hole starts at {first_oh:.1f} but last shoe is {shoe:.1f} (gap/overlap > 50 ft)")
    return msgs

    return msgs


def work_string_total_length(work_string: List[Dict]) -> float:
    total = 0.0
    for row in work_string:
        total += float(row.get("qty", 1)) * float(row.get("len_ft", 0))
    return total


def work_string_max_od(work_string: List[Dict]) -> float:
    m = 0.0
    for row in work_string:
        m = max(m, float(row.get("max_od_in", 0) or 0), float(row.get("od_in", 0) or 0))
    return m


def validate_work_string(work_string: List[Dict], casings: List[Dict], open_hole: List[Dict], bit_depth: float) -> List[str]:
    """Check OD vs hole/casing ID along the string, and basic geometry integrity."""
    msgs = []
    if not work_string:
        msgs.append("Work String is empty")
        return msgs
    cum = 0.0  # from bit upward
    # assume list ordered bit-first (index 0 = bit)
    for i, row in enumerate(work_string):
        od = float(row.get("od_in", 0) or 0)
        max_od = float(row.get("max_od_in", od) or od)
        id_ = float(row.get("id_in", 0) or 0)
        qty = float(row.get("qty", 1) or 1)
        length = float(row.get("len_ft", 0) or 0) * qty
        if od > 0 and id_ > 0 and id_ >= od:
            msgs.append(f"WS[{i}] {row.get('desc','')}: ID ({id_}) >= OD ({od})")
        if length <= 0:
            msgs.append(f"WS[{i}] {row.get('desc','')}: length/qty invalid")
        # depth of this component (midpoint from bit)
        md_mid = bit_depth - (cum + length / 2.0)
        cum += length
        if md_mid < 0:
            continue
        hole_id = get_hole_id_at_depth(open_hole, casings, max(md_mid, 0.0), fallback=12.0)
        clearance = hole_id - max_od
        is_bit = ("bit" in str(row.get("desc", "")).lower()) or (str(row.get("body", "")).lower() == "bit")
        if not is_bit and max_od > 0 and hole_id > 0 and clearance < 0.05:
            msgs.append(
                "WS[%d] %s: Max OD %.3f >= Hole/Casing ID %.3f at ~%.0f ft (no clearance)"
                % (i, row.get("desc", ""), max_od, hole_id, md_mid)
            )
        elif not is_bit and max_od > 0 and hole_id > 0 and clearance < 0.25:
            msgs.append(
                "WS[%d] %s: tight clearance %.3f (Max OD %.3f vs ID %.3f) at ~%.0f ft"
                % (i, row.get("desc", ""), clearance, max_od, hole_id, md_mid)
            )
    total_len = work_string_total_length(work_string)
    if total_len > bit_depth + 50:
        msgs.append(f"Work String total length {total_len:.1f} ft exceeds bit depth {bit_depth:.1f} ft")
    return msgs


def sync_geometry_from_work_string(state: "SimulationState") -> None:
    """Update pipe_od / pipe_id from dominant DP section if present."""
    if not state.work_string:
        return
    # prefer last DP body for main pipe
    dp_rows = [r for r in state.work_string if str(r.get("body", "")).upper() in ("DP", "DRILLPIPE", "PIPE")]
    if dp_rows:
        r = dp_rows[-1]
        state.geometry.pipe_od = float(r.get("od_in", state.geometry.pipe_od))
        state.geometry.pipe_id = float(r.get("id_in", state.geometry.pipe_id))
    # bit size from first component if bit
    bit_rows = [r for r in state.work_string if "bit" in str(r.get("desc", "")).lower() or str(r.get("body", "")).lower() == "bit"]
    if bit_rows:
        state.bit.bit_size = float(bit_rows[0].get("od_in", state.bit.bit_size))
        state.bit.bit_type = bit_rows[0].get("desc", state.bit.bit_type)





def fit_hb_from_fann(r600, r300, r200=None, r100=None, r6=None, r3=None):
    """Simple HB / Bingham estimates from Fann readings (field practical)."""
    r600 = float(r600 or 0)
    r300 = float(r300 or 0)
    pv = max(r600 - r300, 0.0)
    yp = max(r300 - pv, 0.0)
    # n, K from 600/300 (Power-law style) with yield approx from 3-rpm
    if r600 > 0 and r300 > 0 and r600 != r300:
        n = 3.32 * math.log10(max(r600, 1e-6) / max(r300, 1e-6))
        n = max(0.2, min(1.2, n))
        K = (r300 - (float(r3 or 0) * 0.5)) / (511.0 ** n) if n > 0 else 0.5
        K = max(0.01, min(5.0, abs(K)))
    else:
        n, K = 0.7, 0.45
    tau_y = float(r3 or 0) * 0.5 if r3 else max(yp * 0.25, 0.0)
    lsyp = float(r6 or 0) * 0.5 if r6 else tau_y
    return {
        "pv": round(pv, 2),
        "yp": round(yp, 2),
        "n": round(n, 3),
        "K": round(K, 3),
        "tau_y": round(tau_y, 2),
        "lsyp": round(lsyp, 2),
    }


def fluid_dict_to_properties(d: Dict) -> FluidProperties:
    keys = {f.name for f in FluidProperties.__dataclass_fields__.values()}
    # map only known fields
    kwargs = {}
    for k, v in d.items():
        if k in keys:
            kwargs[k] = v
    # ensure required
    if "density_ppg" not in kwargs and "mw" in d:
        kwargs["density_ppg"] = d["mw"]
    return FluidProperties(**kwargs)



def pump_output_gpm(spm: float, liner_in: float, stroke_in: float, efficiency: float = 0.97, triplex: bool = True) -> float:
    """Pump hydraulic output (gpm) from SPM and liner geometry (volumetric).

    Correct oilfield formula:
        Q (gpm) = SPM × n_cyl × (π/4) × liner² × stroke / 231 × efficiency
    where 231 in³ = 1 US gallon.
    Triplex n_cyl=3 → factor ≈ 0.010206; Duplex n_cyl=2 → ≈ 0.006804.
    (Previous constant 0.01298 overstated flow by ~27%.)
    """
    import math
    spm = max(float(spm), 0.0)
    if spm <= 0:
        return 0.0
    liner = max(float(liner_in), 1.0)
    stroke = max(float(stroke_in), 1.0)
    eff = max(min(float(efficiency), 1.0), 0.50)
    n_cyl = 3 if triplex else 2
    # volumetric displacement per stroke (gal) × SPM × efficiency
    return spm * n_cyl * (math.pi / 4.0) * (liner ** 2) * stroke / 231.0 * eff




def surface_piping_friction(piping: List[Dict], q_gpm: float, density_ppg: float, n: float = 0.7, K: float = 0.45,
                            mode: str = "normal") -> float:
    """ΔP (psi) through surface lines on the ACTIVE flow path only.

    Normal circulation path: Pump → Standpipe → Kelly/Hose → (string...)
    Does NOT sum kill line + choke line + return lines into SPP.
    mode: "normal" | "mpd" | "kill" (future expansion).
    """
    if not piping or q_gpm <= 0:
        return 0.0
    # Names that belong on the high-pressure discharge path for normal/MPD circulation
    discharge_keys = ("standpipe", "kelly", "hose", "rotary", "swivel", "top drive", "discharge")
    # Explicitly exclude
    exclude_keys = ("return", "mgs", "shaker", "flow line", "flowline", "kill", "choke line", "mud gas")
    total = 0.0
    for line in piping:
        name = str(line.get("name", "")).lower()
        if any(x in name for x in exclude_keys):
            continue
        # If name is specific and not in discharge list, skip unless generic
        if name and not any(x in name for x in discharge_keys):
            # allow unnamed / generic high-pressure lines with rating
            if "pipe" not in name and "line" not in name:
                continue
        id_in = float(line.get("id_in", 3.0) or 3.0)
        length = float(line.get("length_ft", 0) or 0)
        if id_in <= 0 or length <= 0:
            continue
        total += _pipe_friction(q_gpm, density_ppg, id_in, length, n, K)
    return total


def equipment_pressure_limits(state: "SimulationState") -> dict:
    """Collect working pressure limits from surface equipment (pumps, BOP, RCD, choke)."""
    limits = {
        "max_pump_psi": 5000.0,
        "pop_off_psi": 4500.0,
        "bop_rating_psi": 10000.0,
        "rcd_rating_psi": 3000.0,
        "choke_rating_psi": 10000.0,
        "working_pump_psi": 4500.0,
    }
    for e in (state.surface_equipment or []):
        et = e.get("type")
        if et == "Pump" and e.get("active", True) and e.get("pump_state") not in ("Off", None):
            mx = float(e.get("max_pressure_psi", 0) or 0)
            pop = float(e.get("pop_off_psi", 0) or 0)
            sf = float(e.get("safety_factor", 90) or 90) / 100.0
            if mx > 0:
                limits["max_pump_psi"] = min(limits["max_pump_psi"], mx)
                limits["working_pump_psi"] = min(limits["working_pump_psi"], mx * sf)
            if pop > 0:
                limits["pop_off_psi"] = min(limits["pop_off_psi"], pop)
        elif et == "BOP":
            r = float(e.get("rating_psi", 0) or 0)
            if r > 0:
                limits["bop_rating_psi"] = r
        elif et == "RCD":
            r = float(e.get("rating_psi", 0) or 0)
            if r > 0:
                limits["rcd_rating_psi"] = r
        elif et == "ChokeManifold":
            r = float(e.get("rating_psi", 0) or 0)
            if r > 0:
                limits["choke_rating_psi"] = r
    return limits


def sync_pumps_from_equipment(state: "SimulationState") -> None:
    """Map Pump1..Pump3 equipment rows onto operating SPM / liner / stroke / efficiency."""
    pumps = [e for e in (state.surface_equipment or []) if e.get("type") == "Pump"]
    o = state.operating
    for i, key_spm in enumerate(["pump1_spm", "pump2_spm", "pump3_spm"]):
        if i >= len(pumps):
            break
        p = pumps[i]
        if not p.get("active", True) or p.get("pump_state") == "Off":
            setattr(o, key_spm, 0.0)
        else:
            setattr(o, key_spm, float(p.get("spm", 0) or 0))
        if i == 0:
            o.pump_liner_in = float(p.get("liner_in", o.pump_liner_in))
            o.pump_stroke_in = float(p.get("stroke_in", o.pump_stroke_in))
            o.pump_efficiency = float(p.get("efficiency", 96.0)) / 100.0
    # recompute output_gal_stk for display consistency
    for p in pumps:
        liner = float(p.get("liner_in", 4.75))
        stroke = float(p.get("stroke_in", 12.0))
        ptype = p.get("pump_type", "Triplex")
        # gal/stroke theoretical
        import math
        cyl = 3 if ptype == "Triplex" else 2
        gal = cyl * 7.4805 * (math.pi / 4.0) * (liner / 12.0) ** 2 * (stroke / 12.0)
        p["output_gal_stk"] = round(gal * float(p.get("efficiency", 96)) / 100.0, 2)


def pump_gpm_from_equipment(p: Dict) -> float:
    if not p.get("active", True) or p.get("pump_state") == "Off":
        return 0.0
    spm = float(p.get("spm", 0) or 0)
    if spm <= 0:
        return 0.0
    gal_stk = float(p.get("output_gal_stk") or 0)
    if gal_stk <= 0:
        return pump_output_gpm(spm, float(p.get("liner_in", 4.75)), float(p.get("stroke_in", 12)),
                               float(p.get("efficiency", 96)) / 100.0,
                               triplex=(p.get("pump_type", "Triplex") == "Triplex"))
    return spm * gal_stk


def total_pumps_gpm(o: "OperatingParams") -> float:
    g1 = pump_output_gpm(o.pump1_spm, o.pump_liner_in, o.pump_stroke_in, o.pump_efficiency)
    g2 = pump_output_gpm(o.pump2_spm, o.pump_liner_in, o.pump_stroke_in, o.pump_efficiency)
    g3 = pump_output_gpm(o.pump3_spm, o.pump_liner_in, o.pump_stroke_in, o.pump_efficiency)
    return g1 + g2 + g3


def detect_kick_loss(state: "SimulationState") -> "SimulationState":
    """Kick / loss SCREENING from flow imbalance, pit gain, gas, overbalance.

    PROTOTYPE ONLY – not validated for well-control decisions.
    - Never modifies Flow Out (raw sensor/user value is immutable).
    - Does NOT accumulate pit_gain on every Recalculate (needs real Δt).
    - Does NOT yet separate U-Tube / ballooning / thermal / meter lag from true influx.
    - Flags are screening hypotheses only; confidence ranking not implemented.
    """
    o = state.operating
    dq = float(o.flow_out_gpm) - float(o.flow_in_gpm)  # +gain / -loss at returns
    state.delta_flow = o.flow_in_gpm - o.flow_out_gpm  # convention: in - out

    # pit_gain_bbl is owned by user/sensor – do not auto-integrate here

    kick = False
    loss = False
    ksev = "None"
    lsev = "None"

    # Flow-based screening thresholds (illustrative)
    if dq > 15:
        kick = True
        ksev = "Severe" if dq > 40 else ("Moderate" if dq > 25 else "Minor")
    elif dq < -15:
        loss = True
        lsev = "Severe" if dq < -40 else ("Moderate" if dq < -25 else "Minor")

    # Pit volume (user-entered)
    if o.pit_gain_bbl > 5:
        kick = True
        if o.pit_gain_bbl > 20:
            ksev = "Severe"
        elif o.pit_gain_bbl > 10:
            order = ["None", "Minor", "Moderate", "Severe"]
            ksev = order[max(order.index(ksev) if ksev in order else 0, order.index("Moderate"))]
    elif o.pit_gain_bbl < -8:
        loss = True
        lsev = "Moderate" if o.pit_gain_bbl > -20 else "Severe"

    # Gas + low overbalance (screening only)
    gas = float(getattr(o, "gas_units", 0) or 0)
    bg = float(getattr(o, "background_gas", 5) or 5)
    if gas > bg * 3 and state.overbalance < 150:
        kick = True
        ksev = "Moderate" if ksev == "None" else ksev
    if state.overbalance < 50:
        kick = True
        ksev = "Severe" if state.overbalance < 0 else (ksev if ksev != "None" else "Minor")

    # Note U-tube imbalance as alternative hypothesis in severity label when relevant
    if abs(getattr(state, "u_tube_dp", 0.0) or 0.0) > 50 and kick and abs(dq) < 30:
        ksev = f"{ksev} (check U-Tube)"

    o.kick_flag = kick
    o.loss_flag = loss
    o.kick_severity = ksev if kick else "None"
    o.loss_severity = lsev if loss else "None"
    return state


def apply_pump_fluid(state: "SimulationState") -> None:
    """Set state.fluid from library entry matching pump_fluid_name."""
    name = state.pump_fluid_name
    match = None
    for f in state.fluid_library:
        if f.get("name") == name:
            match = f
            break
    if match is None and state.fluid_library:
        match = state.fluid_library[0]
        state.pump_fluid_name = match.get("name", name)
    if match:
        state.fluid = fluid_dict_to_properties(match)



def _fluid_lookup(library: List[Dict], name: str) -> Dict:
    for f in library:
        if f.get("name") == name:
            return f
    return library[0] if library else {"name": name, "density_ppg": 10.0, "color": "#888"}


def init_fluid_columns(state: "SimulationState") -> None:
    """Fill pipe + annulus with Initial Fluid from surface to bit."""
    g = state.geometry
    init = _fluid_lookup(state.fluid_library, state.initial_fluid_name)
    dens = float(init.get("density_ppg", 10.0))
    color = init.get("color", "#8B0000")
    name = init.get("name", state.initial_fluid_name)
    bit = float(g.bit_depth)
    state.pipe_column = [{"name": name, "md_top": 0.0, "md_bot": bit, "density_ppg": dens, "color": color}]
    state.ann_column = [{"name": name, "md_top": 0.0, "md_bot": bit, "density_ppg": dens, "color": color}]
    state.column_initialized = True


def _annular_capacity_bbl_per_ft(hole_id: float, pipe_od: float) -> float:
    # bbl/ft = (Dh^2 - Dp^2) / 1029.4
    return max((hole_id ** 2 - pipe_od ** 2) / 1029.4, 1e-6)


def _pipe_capacity_bbl_per_ft(pipe_id: float) -> float:
    return max((pipe_id ** 2) / 1029.4, 1e-6)


def _column_volume_bbl(col: List[Dict], bbl_per_ft: float) -> float:
    return sum(max(s["md_bot"] - s["md_top"], 0) * bbl_per_ft for s in col)


def _merge_adjacent(col: List[Dict]) -> List[Dict]:
    if not col:
        return []
    ordered = sorted(col, key=lambda s: s["md_top"])
    out = [dict(ordered[0])]
    for s in ordered[1:]:
        last = out[-1]
        if abs(last["md_bot"] - s["md_top"]) < 0.5 and last["name"] == s["name"] and abs(last["density_ppg"] - s["density_ppg"]) < 0.05:
            last["md_bot"] = s["md_bot"]
        else:
            out.append(dict(s))
    return out


def pump_fluid_step(state: "SimulationState", minutes: float = 1.0) -> "SimulationState":
    """Volume-queue displacement: Pump → Drillstring → Bit → Annulus → Surface.

    CRITICAL FIX vs prior version:
    New fluid enters the TOP of the drillstring only.
    Fluid only enters the annulus after it has physically reached the bit
    (i.e., after displacing the full pipe capacity). Volume exiting the
    bottom of the pipe column in this step is the volume inserted at the
    bit into the annulus.

    Still uses single pipe_id / hole_id / pipe_od (section-by-section
    capacities are a later physics upgrade). PROTOTYPE.
    """
    if not state.column_initialized or not state.pipe_column or not state.ann_column:
        init_fluid_columns(state)

    g, o = state.geometry, state.operating
    bit = float(g.bit_depth)
    if bit <= 1:
        return state

    vol_bbl = max(o.flow_in_gpm, 0.0) * max(minutes, 0.0) / 42.0
    if vol_bbl <= 0:
        return state

    pipe_cap = _pipe_capacity_bbl_per_ft(g.pipe_id)
    ann_cap = _annular_capacity_bbl_per_ft(g.hole_id, g.pipe_od)
    if pipe_cap <= 0 or ann_cap <= 0:
        return state

    dL_pipe = vol_bbl / pipe_cap

    pump = _fluid_lookup(state.fluid_library, state.pump_fluid_name)
    p_name = pump.get("name", state.pump_fluid_name)
    p_dens = float(pump.get("density_ppg", state.fluid.density_ppg))
    p_color = pump.get("color", "#8B0000")

    # --- PIPE: push existing fluids toward bit, insert new at surface ---
    # Capture fluid that would exit past the bit (volume that reaches annulus)
    vol_to_ann = 0.0
    exit_name, exit_dens, exit_color = p_name, p_dens, p_color

    new_pipe = []
    for seg in state.pipe_column:
        top = seg["md_top"] + dL_pipe
        bot = seg["md_bot"] + dL_pipe
        # portion that crossed the bit
        if bot > bit:
            overflow_len = bot - max(top, bit)
            if overflow_len > 0:
                vol_to_ann += overflow_len * pipe_cap
                exit_name = seg["name"]
                exit_dens = float(seg["density_ppg"])
                exit_color = seg.get("color", "#888")
            bot = bit
        top = min(top, bit)
        if bot > top + 0.05 and top < bit:
            new_pipe.append({
                "name": seg["name"], "md_top": top, "md_bot": bot,
                "density_ppg": seg["density_ppg"], "color": seg.get("color", "#888")
            })
    # insert pump fluid at surface
    insert_bot = min(dL_pipe, bit)
    if insert_bot > 0.05:
        new_pipe.insert(0, {
            "name": p_name, "md_top": 0.0, "md_bot": insert_bot,
            "density_ppg": p_dens, "color": p_color
        })
    state.pipe_column = _merge_adjacent(new_pipe)

    # If pipe was not yet full of new fluid, volume reaching bit may be less
    # than pumped (first fill). vol_to_ann already accounts for overflow only.
    if vol_to_ann <= 0:
        # Nothing reached bit yet – annulus unchanged
        return state

    dL_ann = vol_to_ann / ann_cap

    # --- ANNULUS: only fluid that exited the bit enters at bottom ---
    new_ann = []
    for seg in state.ann_column:
        top = max(seg["md_top"] - dL_ann, 0.0)
        bot = seg["md_bot"] - dL_ann
        if bot > 0.05 and bot > top:
            new_ann.append({
                "name": seg["name"], "md_top": top, "md_bot": min(bot, bit),
                "density_ppg": seg["density_ppg"], "color": seg.get("color", "#888")
            })
    ins_top = max(bit - dL_ann, 0.0)
    if bit - ins_top > 0.05:
        new_ann.append({
            "name": exit_name, "md_top": ins_top, "md_bot": bit,
            "density_ppg": exit_dens, "color": exit_color
        })
    state.ann_column = _merge_adjacent(new_ann)
    return state


def hydrostatic_from_column(col: List[Dict], tvd_ratio: float = 1.0, wellpath: List[Dict] = None) -> float:
    """Hydrostatic (psi) from fluid column.

    If wellpath (Minimum Curvature stations with md/tvd) is provided, uses
    true ΔTVD per segment. Otherwise falls back to uniform tvd_ratio = TVD/MD
    (acceptable for near-vertical wells only).
    """
    h = 0.0
    for seg in col:
        md_top = float(seg["md_top"])
        md_bot = float(seg["md_bot"])
        md_len = max(md_bot - md_top, 0.0)
        if md_len <= 0:
            continue
        if wellpath:
            tvd_top = wellpath_tvd_at_md(wellpath, md_top)
            tvd_bot = wellpath_tvd_at_md(wellpath, md_bot)
            tvd_len = abs(tvd_bot - tvd_top)
        else:
            tvd_len = md_len * tvd_ratio
        h += 0.052 * float(seg["density_ppg"]) * tvd_len
    return h


def density_at_md(col: List[Dict], md: float, fallback: float = 10.0) -> float:
    for seg in col:
        if seg["md_top"] <= md <= seg["md_bot"]:
            return float(seg["density_ppg"])
    return fallback


def compute_wellpath(stations: List[Dict], vs_azimuth_deg: float = 0.0) -> List[Dict]:
    """Minimum Curvature survey calculation.
    Input each station needs: md, inc, azi (degrees).
    Returns full rows: md, inc, azi, tvd, north, east, cl, dls, build_rate, turn_rate,
                       toolface, vs, hdisp, tvdss, ld.
    """
    if not stations:
        return []
    # sort by MD
    rows = sorted(
        [{"md": float(s.get("md", 0)), "inc": float(s.get("inc", 0)), "azi": float(s.get("azi", 0))}
         for s in stations],
        key=lambda x: x["md"]
    )
    out = []
    north = east = tvd = 0.0
    for i, st in enumerate(rows):
        md = st["md"]
        inc = st["inc"]
        azi = st["azi"]
        if i == 0:
            cl = 0.0
            dls = 0.0
            br = 0.0
            tr = 0.0
            tf = 0.0
            tvd = 0.0
            north = 0.0
            east = 0.0
        else:
            prev = rows[i - 1]
            cl = md - prev["md"]
            if cl <= 0:
                cl = 0.0
                dls = br = tr = tf = 0.0
            else:
                i1 = math.radians(prev["inc"])
                i2 = math.radians(inc)
                a1 = math.radians(prev["azi"])
                a2 = math.radians(azi)
                # dogleg angle β
                cos_dl = math.cos(i1) * math.cos(i2) + math.sin(i1) * math.sin(i2) * math.cos(a2 - a1)
                cos_dl = max(-1.0, min(1.0, cos_dl))
                beta = math.acos(cos_dl)
                beta_deg = math.degrees(beta)
                dls = (beta_deg / cl) * 100.0 if cl > 0 else 0.0
                # ratio factor
                if beta < 1e-8:
                    rf = 1.0
                else:
                    rf = (2.0 / beta) * math.tan(beta / 2.0)
                dn = (cl / 2.0) * (math.sin(i1) * math.cos(a1) + math.sin(i2) * math.cos(a2)) * rf
                de = (cl / 2.0) * (math.sin(i1) * math.sin(a1) + math.sin(i2) * math.sin(a2)) * rf
                dv = (cl / 2.0) * (math.cos(i1) + math.cos(i2)) * rf
                north += dn
                east += de
                tvd += dv
                br = ((inc - prev["inc"]) / cl) * 100.0
                # turn rate (azimuth change handled with wrap)
                dazi = azi - prev["azi"]
                while dazi > 180:
                    dazi -= 360
                while dazi < -180:
                    dazi += 360
                tr = (dazi / cl) * 100.0
                # toolface approx
                if abs(math.sin(i2)) > 1e-6 and beta > 1e-8:
                    tf = math.degrees(math.atan2(
                        math.sin(i1) * math.sin(a2 - a1),
                        math.sin(i1) * math.cos(i2) * math.cos(a2 - a1) - math.cos(i1) * math.sin(i2)
                    ))
                else:
                    tf = 0.0
        hdisp = math.sqrt(north * north + east * east)
        vs_az = math.radians(vs_azimuth_deg)
        vs = north * math.cos(vs_az) + east * math.sin(vs_az)
        out.append({
            "md": round(md, 2),
            "inc": round(inc, 2),
            "azi": round(azi, 2),
            "tvd": round(tvd, 2),
            "tvdss": round(-tvd, 2),  # relative; user can offset later
            "north": round(north, 2),
            "east": round(east, 2),
            "cl": round(cl if i > 0 else 0.0, 2),
            "dls": round(dls if i > 0 else 0.0, 2),
            "build_rate": round(br if i > 0 else 0.0, 2),
            "turn_rate": round(tr if i > 0 else 0.0, 2),
            "toolface": round(tf if i > 0 else 0.0, 2),
            "vs": round(vs, 2),
            "hdisp": round(hdisp, 2),
            "ld": round(hdisp, 2),
        })
    return out


def wellpath_tvd_at_md(computed: List[Dict], md: float) -> float:
    if not computed:
        return md
    if md <= computed[0]["md"]:
        return computed[0]["tvd"]
    for i in range(1, len(computed)):
        if computed[i]["md"] >= md:
            m0, m1 = computed[i - 1]["md"], computed[i]["md"]
            t0, t1 = computed[i - 1]["tvd"], computed[i]["tvd"]
            if m1 <= m0:
                return t1
            f = (md - m0) / (m1 - m0)
            return t0 + f * (t1 - t0)
    return computed[-1]["tvd"]


def get_formation_at_depth(lithology, md):
    if not lithology:
        return {"name": "Unknown", "lithology": "Unknown", "pp_grad": 0.56, "fg_grad": 0.90,
                "ppg": 10.8, "fpg": 16.5, "color": "#888"}
    # Prefer md_top/md_bot ranges
    for layer in lithology:
        top = float(layer.get("md_top", layer.get("md", 0)))
        bot = float(layer.get("md_bot", top + 1))
        if top <= md <= bot:
            return layer
    # Fallback: last top at or below md
    ordered = sorted(lithology, key=lambda x: float(x.get("md_top", x.get("md", 0))))
    best = ordered[0]
    for layer in ordered:
        if float(layer.get("md_top", layer.get("md", 0))) <= md:
            best = layer
        else:
            break
    return best


def enrich_formations_tvd(formations: List[Dict], wellpath: List[Dict]) -> List[Dict]:
    """Fill TVD for each formation MD top from survey (Minimum Curvature wellpath)."""
    computed = compute_wellpath(wellpath) if wellpath and len(wellpath) >= 1 else []
    out = []
    ordered = sorted([dict(f) for f in formations], key=lambda x: float(x.get("md", x.get("md_top", 0))))
    for i, f in enumerate(ordered):
        md = float(f.get("md", f.get("md_top", 0)))
        f["md"] = md
        f["md_top"] = md
        if i + 1 < len(ordered):
            f["md_bot"] = float(ordered[i + 1].get("md", ordered[i + 1].get("md_top", md + 100)))
        else:
            f["md_bot"] = float(f.get("md_bot", md + 500))
        if computed:
            f["tvd"] = round(wellpath_tvd_at_md(computed, md), 2)
        else:
            f["tvd"] = round(float(f.get("tvd", md)), 2)
        # Keep pp_grad / fg_grad in psi/ft synced from ppg if provided
        if f.get("ppg"):
            f["pp_grad"] = float(f["ppg"]) * 0.052
        if f.get("fpg"):
            f["fg_grad"] = float(f["fpg"]) * 0.052
        out.append(f)
    return out

def calculate_surge_swab(state):
    """PRELIMINARY Surge/Swab estimate only – NOT validated for operations."""
    s, g, f = state.surge, state.geometry, state.fluid
    v = s.pipe_velocity_ftmin / 60.0
    dh = g.hole_id - g.pipe_od
    if dh <= 0:
        state.max_surge_psi = state.max_swab_psi = 0.0
        return state
    cling = s.clinging_factor if s.open_end else 1.0
    mu = f.pv * 1.2 + f.yp * 0.5
    base = (mu * v * g.md) / (1000.0 * dh**2) * cling * 3.5
    accel = s.acceleration * f.density_ppg * g.md * 0.0015
    state.max_surge_psi = base + accel
    state.max_swab_psi = -(base * 0.9)
    state.esd_surge = state.ecd + (state.max_surge_psi / (0.052 * g.tvd)) if g.tvd > 0 else state.ecd
    state.esd_swab = state.ecd + (state.max_swab_psi / (0.052 * g.tvd)) if g.tvd > 0 else state.ecd
    return state

def auto_adjust_sbp_for_cbhp(state):
    if state.choke_mode != "CBHP":
        return state
    error = state.target_bhp - state.bhp
    step = max(-30.0, min(30.0, error * 0.18))
    state.operating.sbp_setpoint = max(0.0, min(1000.0, state.operating.sbp_setpoint + step))
    state.operating.choke_position = max(5.0, min(95.0, 28.0 + state.operating.sbp_setpoint / 9.5))
    return state

def run_diagnostics(state):
    state.delta_flow = state.operating.flow_in_gpm - state.operating.flow_out_gpm
    state.delta_spp = state.operating.spp_measured - state.model_spp
    msgs = []
    status = "OK"
    if abs(state.delta_flow) > 15:
        status = "WARNING"
        msgs.append(f"Flow imbalance ΔQ={state.delta_flow:.1f} gpm (possible loss/gain)")
    if getattr(state.operating, "kick_flag", False):
        msgs.append(f"KICK DETECTED ({state.operating.kick_severity}) pit={state.operating.pit_gain_bbl:.1f} bbl")
        status = "ALERT"
    if getattr(state.operating, "loss_flag", False):
        msgs.append(f"LOSS DETECTED ({state.operating.loss_severity})")
        status = "ALERT" if status != "ALERT" else status
    elif abs(state.delta_flow) > 5:
        msgs.append(f"Minor flow difference ΔQ={state.delta_flow:.1f} gpm")
    if abs(state.delta_spp) > 150:
        status = "WARNING" if status == "OK" else status
        msgs.append(f"SPP residual {state.delta_spp:+.0f} psi (diagnostic only)")
    elif abs(state.delta_spp) > 50:
        msgs.append(f"SPP residual {state.delta_spp:+.0f} psi")
    if state.overbalance < 100:
        status = "ALERT"
        msgs.append(f"Low overbalance {state.overbalance:.0f} psi")

    # Equipment pressure limits
    try:
        lim = equipment_pressure_limits(state)
        spp_ref = max(state.model_spp, state.operating.spp_measured)
        if spp_ref > lim["pop_off_psi"]:
            msgs.append(f"SPP {spp_ref:.0f} > Pop-off {lim['pop_off_psi']:.0f} psi")
            status = "ALERT"
        elif spp_ref > lim["working_pump_psi"]:
            msgs.append(f"SPP near pump working limit {lim['working_pump_psi']:.0f} psi")
            status = "WARNING" if status == "OK" else status
        if state.operating.sbp_setpoint > lim["rcd_rating_psi"] * 0.9:
            msgs.append(f"SBP approaches RCD rating {lim['rcd_rating_psi']:.0f} psi")
            status = "WARNING" if status == "OK" else status
        if state.bhp > lim["bop_rating_psi"]:
            # BOP rating is a surface equipment limit – compare to surface pressures, not BHP
            msgs.append(f"NOTE: BOP rating {lim['bop_rating_psi']:.0f} psi is a wellhead limit; check SIWHP/choke pressure, not BHP")
            status = "ALERT"
    except Exception:
        pass

    state.diag_status = status
    state.diag_message = " | ".join(msgs) if msgs else "All primary parameters within normal range"
    return state

def push_history(state, maxlen=40):
    state.history_bhp.append(state.bhp)
    state.history_ecd.append(state.ecd)
    state.history_spp.append(state.model_spp)
    state.history_flow.append(state.effective_flow)
    state.history_bhp = state.history_bhp[-maxlen:]
    state.history_ecd = state.history_ecd[-maxlen:]
    state.history_spp = state.history_spp[-maxlen:]
    state.history_flow = state.history_flow[-maxlen:]
    return state


def compute_d_exponent(rop_fph: float, rpm: float, wob_klbf: float, bit_in: float) -> float:
    """Standard d-exponent (dimensionless drilling strength indicator).
    d = log10(ROP/(60*RPM)) / log10(12*WOB/(1000*BitDia))
    ROP in ft/hr, WOB in klbf, bit in inches.
    """
    import math
    rop = max(float(rop_fph), 0.1)
    rpm = max(float(rpm), 1.0)
    wob = max(float(wob_klbf), 0.5)
    bit = max(float(bit_in), 1.0)
    num = math.log10(rop / (60.0 * rpm))
    den = math.log10(12.0 * wob / (1000.0 * bit))
    if abs(den) < 1e-9:
        return 1.5
    d = num / den
    return max(0.5, min(3.5, d))


def compute_dc_exponent(d_exp: float, mud_ppg: float, normal_ppg: float = 8.75) -> float:
    """Corrected d-exponent for mud weight (Rehm & McClendon style).
    dc = d * (normal_ppg / mud_ppg)
    """
    mud = max(float(mud_ppg), 6.0)
    return d_exp * (float(normal_ppg) / mud)


def pp_from_formation(tvd: float, ppg: float) -> float:
    """Pore pressure (psi) from formation pore gradient in ppg."""
    return 0.052 * float(ppg) * float(tvd)


def pp_from_dexponent(tvd: float, dc: float, normal_dc: float = 1.4, normal_ppg: float = 8.75,
                      eaton_exp: float = 1.2, overburden_ppg: float = 19.0) -> float:
    """Eaton-style pore pressure from corrected d-exponent.
    PPG_pore = PPG_ob - (PPG_ob - PPG_normal) * (dc / dc_normal)^n
    """
    ratio = max(dc, 0.3) / max(normal_dc, 0.3)
    ratio = max(0.3, min(2.5, ratio))
    ppg = overburden_ppg - (overburden_ppg - normal_ppg) * (ratio ** eaton_exp)
    ppg = max(7.5, min(overburden_ppg - 0.5, ppg))
    return 0.052 * ppg * float(tvd), ppg


def pp_gas_adjustment(pp_base_psi: float, gas_units: float, bg_gas: float, conn_gas: float,
                      trip_gas: float, tvd: float) -> float:
    """Increase estimated pore pressure when gas shows rise above background.
    Strong shows → formation pressure closer to / above ECD (underbalanced tendency).
    Empirical: +0.5 to +3.0 ppg equivalent depending on severity.
    """
    excess = max(float(gas_units) - max(float(bg_gas), 1.0), 0.0)
    conn_x = max(float(conn_gas) - max(float(bg_gas), 1.0), 0.0)
    trip_x = max(float(trip_gas) - max(float(bg_gas), 1.0), 0.0)
    # severity score
    score = (excess / 50.0) + 0.5 * (conn_x / 80.0) + 0.3 * (trip_x / 100.0)
    score = max(0.0, min(3.0, score))
    delta_ppg = score * 0.8  # up to ~2.4 ppg
    return pp_base_psi + 0.052 * delta_ppg * float(tvd), delta_ppg


def pp_temperature_factor(pp_psi: float, temp_f: float, ref_temp: float = 150.0) -> float:
    """Mild temperature influence on interpreted PP (compaction / fluid expansion proxy).
    Hotter than expected for depth can indicate undercompacted / higher PP zones.
    """
    dT = float(temp_f) - float(ref_temp)
    # ±5% per 50°F deviation, clamped
    factor = 1.0 + max(-0.08, min(0.08, 0.001 * dT))
    return pp_psi * factor



def inclination_azimuth_at_md(wellpath: List[Dict], md: float) -> tuple:
    """Interpolate Inc/Azi at MD from survey stations."""
    if not wellpath:
        return 0.0, 0.0
    pts = sorted(
        [{"md": float(s.get("md", 0)), "inc": float(s.get("inc", 0)), "azi": float(s.get("azi", 0))}
         for s in wellpath],
        key=lambda x: x["md"]
    )
    if md <= pts[0]["md"]:
        return pts[0]["inc"], pts[0]["azi"]
    if md >= pts[-1]["md"]:
        return pts[-1]["inc"], pts[-1]["azi"]
    for i in range(1, len(pts)):
        if pts[i]["md"] >= md:
            m0, m1 = pts[i-1]["md"], pts[i]["md"]
            f = (md - m0) / max(m1 - m0, 1e-9)
            inc = pts[i-1]["inc"] + f * (pts[i]["inc"] - pts[i-1]["inc"])
            # azimuth unwrap
            a0, a1 = pts[i-1]["azi"], pts[i]["azi"]
            da = a1 - a0
            while da > 180: da -= 360
            while da < -180: da += 360
            azi = a0 + f * da
            return inc, azi
    return pts[-1]["inc"], pts[-1]["azi"]


def compute_mse_ksi(wob_klbf: float, rpm: float, rop_fph: float, bit_in: float,
                    torque_kftlb: float = 0.0) -> float:
    """Mechanical Specific Energy (ksi) – Teale / modern MSE.
    MSE = (WOB/Area) + (120*π*RPM*Torque)/(Area*ROP)
    If torque unknown, approximate Torque ≈ WOB * bit/12 * 0.15 (rule of thumb).
    Strong indicator in horizontal wells where ROP/WOB relationship changes with path.
    """
    import math
    bit = max(float(bit_in), 1.0)
    area = math.pi / 4.0 * bit * bit  # in²
    wob = max(float(wob_klbf), 0.1) * 1000.0  # lbf
    rop = max(float(rop_fph), 0.5)
    rpm = max(float(rpm), 1.0)
    if torque_kftlb and torque_kftlb > 0:
        tq = float(torque_kftlb) * 1000.0  # ft-lbf
    else:
        tq = wob * (bit / 12.0) * 0.15  # approx ft-lbf
    mse_psi = (wob / area) + (120.0 * math.pi * rpm * tq) / (area * rop)
    return mse_psi / 1000.0  # ksi


def pp_from_mse(tvd: float, mse_ksi: float, baseline_mse: float = 15.0,
                normal_ppg: float = 8.75, overburden_ppg: float = 19.0) -> float:
    """Map MSE ratio to pore pressure (empirical Eaton-like on strength).
    Higher MSE than baseline → harder rock / lower differential → often lower PP;
    Lower MSE (drilling easier) → possible higher PP / underbalance tendency.
    """
    ratio = max(float(mse_ksi), 1.0) / max(float(baseline_mse), 1.0)
    ratio = max(0.4, min(2.5, ratio))
    # invert: easy drilling (low MSE) → higher PP
    ppg = overburden_ppg - (overburden_ppg - normal_ppg) * (ratio ** 0.9)
    ppg = max(7.5, min(overburden_ppg - 0.5, ppg))
    return 0.052 * ppg * float(tvd), ppg


def pp_path_corrected(tvd: float, pp_dex_psi: float, inclination_deg: float,
                      azimuth_deg: float, dls: float = 0.0) -> float:
    """Trajectory-aware correction for high-angle / horizontal sections (2023–2025 practice).
    - In near-vertical: trust d-exp fully
    - In build/high-angle: blend toward TVD-based formation stress (path changes ROP/WOB coupling)
    - Horizontal (inc~90): reduce weight of pure vertical compaction model, increase path factor
    Recent literature: wellbore trajectory significantly affects undrained PP response and
    effective drilling parameter interpretation (poroelastic anisotropy + stress rotation).
    """
    import math
    inc = max(0.0, min(90.0, float(inclination_deg)))
    # path factor 0 vertical → 1 horizontal
    path_f = (math.sin(math.radians(inc))) ** 1.2
    # DLS stress: higher dogleg → local stress concentration uncertainty
    dls_f = min(0.15, abs(float(dls)) / 20.0)
    # In horizontal, PP estimate shifts mildly toward hydrostatic+tectonic midpoint
    hydro = 0.052 * 8.75 * tvd
    tectonic_mid = 0.052 * 12.0 * tvd  # mid-range for active basins
    path_anchor = hydro * (1 - path_f) + tectonic_mid * path_f
    blended = (1.0 - 0.35 * path_f - dls_f) * pp_dex_psi + (0.35 * path_f + dls_f) * path_anchor
    return blended



def estimate_pore_pressure(state: "SimulationState") -> "SimulationState":
    """Multi-method live pore pressure estimation → fills state.pp_* and live_pp."""
    g, o, b, f = state.geometry, state.operating, state.bit, state.fluid
    tvd = max(g.tvd, 1.0)
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    form_ppg = float(form.get("ppg", 9.0) or 9.0)
    form_fpg = float(form.get("fpg", 16.0) or 16.0)

    # 1) Formation PPG method
    state.pp_formation = pp_from_formation(tvd, form_ppg)
    state.fg_psi = 0.052 * form_fpg * tvd

    # 2) d-exponent / Eaton method from drilling parameters
    rop = float(o.rop)  # ft/hr assumed
    rpm = float(o.rpm)
    wob = float(o.wob)
    bit = float(b.bit_size or g.hole_id)
    d_exp = compute_d_exponent(rop, rpm, wob, bit)
    dc = compute_dc_exponent(d_exp, f.density_ppg, normal_ppg=8.75)
    state.d_exponent = d_exp
    state.dc_exponent = dc
    # normal dc baseline from bit type
    normal_dc = {"PDC": 1.35, "Diamond Impregnated": 1.45, "Tricone": 1.25}.get(b.bit_type, 1.4)
    pp_dex_psi, dex_ppg = pp_from_dexponent(tvd, dc, normal_dc=normal_dc, normal_ppg=8.75)
    # bit aggressiveness factor
    bit_factor = {"PDC": 1.0, "Diamond Impregnated": 1.03, "Tricone": 0.97}.get(b.bit_type, 1.0)
    state.pp_dexponent = pp_dex_psi * bit_factor

    # 3) Gas-adjusted (apply on formation baseline)
    gas_u = float(getattr(o, "gas_units", state.gas_units) or state.gas_units)
    bg = float(getattr(o, "background_gas", state.background_gas) or state.background_gas)
    cg = float(getattr(o, "connection_gas", state.connection_gas) or state.connection_gas)
    tg = float(getattr(o, "trip_gas", state.trip_gas) or state.trip_gas)
    state.gas_units = gas_u
    state.background_gas = bg
    state.connection_gas = cg
    state.trip_gas = tg
    pp_gas_psi, gas_dppg = pp_gas_adjustment(state.pp_formation, gas_u, bg, cg, tg, tvd)
    state.pp_gas = pp_gas_psi

    # 4) Temperature branch
    t_bit = temp_at_tvd(state.temp_profile, tvd, f.ambient_temp, f.temp_gradient) if state.temp_profile else f.temp_out
    # expected temp from gradient
    t_exp = f.ambient_temp + (tvd / 100.0) * f.temp_gradient
    state.pp_temp = pp_temperature_factor(state.pp_formation, t_bit, ref_temp=t_exp)

    # 5) MSE method (robust in horizontal / high-angle where ROP-WOB coupling changes)
    mse = compute_mse_ksi(wob, rpm, rop, bit)
    state.mse_ksi = mse
    # baseline MSE scales with bit type
    base_mse = {"PDC": 35.0, "Diamond Impregnated": 55.0, "Tricone": 40.0}.get(b.bit_type, 40.0)
    pp_mse_psi, _ = pp_from_mse(tvd, mse, baseline_mse=base_mse)
    state.pp_mse = pp_mse_psi

    # 6) Path / trajectory-corrected (inc, azi, DLS from wellpath)
    inc_bit, azi_bit = inclination_azimuth_at_md(state.wellpath, g.bit_depth)
    state.inclination_at_bit = inc_bit
    state.azimuth_at_bit = azi_bit
    # effective axial WOB component (vertical contribution falls with inclination)
    import math as _m
    state.wob_effective = wob * max(0.15, abs(_m.cos(_m.radians(inc_bit))))
    # local DLS from last wellpath computed segment
    dls_local = 0.0
    if state.wellpath and len(state.wellpath) >= 2:
        try:
            wp_c = compute_wellpath(state.wellpath)
            # nearest station to bit
            dls_local = float(wp_c[-1].get("dls", 0.0))
            for row in wp_c:
                if abs(row["md"] - g.bit_depth) < abs(wp_c[-1]["md"] - g.bit_depth):
                    dls_local = float(row.get("dls", 0.0))
        except Exception:
            pass
    state.pp_path = pp_path_corrected(tvd, state.pp_dexponent, inc_bit, azi_bit, dls_local)

    # 7) Hybrid – weights shift toward MSE + path when inclination is high
    path_f = (_m.sin(_m.radians(inc_bit))) ** 1.2
    w_form = 0.28
    w_dex = 0.18 * (1.0 - 0.5 * path_f)
    w_mse = 0.18 + 0.12 * path_f
    w_path = 0.10 + 0.15 * path_f
    w_gas = 0.18 if gas_u > bg * 1.5 else 0.08
    w_temp = 0.08
    wsum = w_form + w_dex + w_mse + w_path + w_gas + w_temp
    hybrid = (
        w_form * state.pp_formation +
        w_dex * state.pp_dexponent +
        w_mse * state.pp_mse +
        w_path * state.pp_path +
        w_gas * state.pp_gas +
        w_temp * state.pp_temp
    ) / wsum
    state.pp_hybrid = hybrid
    state.live_pp = hybrid  # ESTIMATED PP (not measured live pore pressure)
    state.pp_gradient_ppg = hybrid / (0.052 * tvd) if tvd > 0 else form_ppg
    state.overbalance = state.bhp - state.live_pp
    state.litho_gradient = state.pp_gradient_ppg * 0.052

    # history for live charts
    from datetime import datetime
    state.pp_history.append(state.live_pp)
    state.bhp_history_pp.append(state.bhp)
    state.ecd_history_pp.append(state.ecd)
    state.fg_history.append(state.fg_psi)
    state.time_history.append(datetime.now().strftime("%H:%M:%S"))
    maxlen = 60
    state.pp_history = state.pp_history[-maxlen:]
    state.bhp_history_pp = state.bhp_history_pp[-maxlen:]
    state.ecd_history_pp = state.ecd_history_pp[-maxlen:]
    state.fg_history = state.fg_history[-maxlen:]
    state.time_history = state.time_history[-maxlen:]
    return state


def run_hydraulics(state):
    apply_pump_fluid(state)
    sync_pumps_from_equipment(state)
    g, f, o, b = state.geometry, state.fluid, state.operating, state.bit
    # Optional: derive flow from pump SPM if pumps running
    pumps_q = total_pumps_gpm(o)
    # Flow priority: pumps drive flow_in when use_pump_flow and SPM active
    if getattr(o, "use_pump_flow", True) and pumps_q > 10:
        o.flow_in_gpm = pumps_q
        o.total_strokes = o.total_strokes + (o.pump1_spm + o.pump2_spm + o.pump3_spm) * 0.05
        # NEVER auto-alter raw Flow Out – sensor/user value is immutable.
        # Imbalance is handled only in diagnostics / kick-loss detection.

    # Sync geometry from well intervals when available
    if state.open_hole or state.casings:
        g.hole_id = get_hole_id_at_depth(state.open_hole, state.casings, g.bit_depth, g.hole_id)
        if state.casings:
            g.shoe_depth = get_shoe_depth(state.casings)
            g.casing_od = float(state.casings[-1].get("od_in", g.casing_od))
    if state.work_string:
        sync_geometry_from_work_string(state)
    # Update TVD from survey when wellpath exists
    if state.wellpath and len(state.wellpath) >= 2:
        computed = compute_wellpath(state.wellpath)
        g.tvd = wellpath_tvd_at_md(computed, g.bit_depth)
        if g.md < g.bit_depth:
            g.md = g.bit_depth
    # Enrich formation TVDs from wellpath; normalize ranges
    if state.lithology:
        state.lithology = enrich_formations_tvd(state.lithology, state.wellpath)
    form = get_formation_at_depth(state.lithology, g.bit_depth)
    state.current_formation = form.get("name", form.get("lithology", "Unknown"))
    # Prefer PPG (ppg) → psi/ft
    if form.get("ppg"):
        state.litho_gradient = float(form["ppg"]) * 0.052
    else:
        state.litho_gradient = form.get("pp_grad", 0.56)

    # Temperature at bit from profile (or gradient fallback)
    t_bit = temp_at_tvd(state.temp_profile, g.tvd, f.ambient_temp, f.temp_gradient)
    t_mid = temp_at_tvd(state.temp_profile, g.tvd * 0.5, f.ambient_temp, f.temp_gradient)
    # Mud in/out influence average circulating temp
    t_circ = 0.5 * (f.temp_in + f.temp_out) if f.temp_out > 0 else f.temp_in
    t_eff = 0.5 * (t_bit + t_circ)  # effective for density/rheology
    state.corrected_density = _temp_corrected_density(f.density_ppg, t_eff, ref_temp=f.ref_temp if hasattr(f, 'ref_temp') else 80.0)
    visc_factor = _temp_corrected_viscosity_factor(t_eff, ref_temp=f.temp_in)
    state.q_loss = max(0.0, o.flow_in_gpm - o.flow_out_gpm)

    if not state.column_initialized:
        init_fluid_columns(state)

    tvd_ratio = (g.tvd / g.md) if g.md > 1 else 1.0
    if state.ann_column:
        wp_computed = compute_wellpath(state.wellpath) if state.wellpath else None
        state.hydrostatic = hydrostatic_from_column(state.ann_column, tvd_ratio, wellpath=wp_computed)
        # average ann density near bottom for ECD reference
        dens_ann = density_at_md(state.ann_column, g.bit_depth * 0.95, state.corrected_density)
    else:
        dens_ann = state.corrected_density + 0.15
        state.hydrostatic = _hydrostatic(state.corrected_density, g.tvd)

    # --- U-Tube indicator (PROTOTYPE) ---
    # Correct approach: full-column hydrostatic pipe vs annulus from survey ΔTVD.
    # q_utube is NOT a physical flow solution – it is an imbalance INDICATOR only.
    # A proper U-tube flow requires root-solving the network pressure equation.
    dens_pipe = density_at_md(state.pipe_column, g.bit_depth * 0.5, state.corrected_density) if state.pipe_column else state.corrected_density
    # Full-column hydrostatic difference (no arbitrary 0.5 factor)
    pipe_hydro = hydrostatic_from_column(state.pipe_column, tvd_ratio) if state.pipe_column else _hydrostatic(dens_pipe, g.tvd)
    ann_hydro = state.hydrostatic  # already from ann_column
    # Positive u_tube_dp means annulus heavier → tendency for flow into pipe (or reduced returns)
    # Negative means pipe heavier → tendency for free-fall / U-tube into annulus
    state.u_tube_dp = ann_hydro - pipe_hydro
    # Indicator only – NOT added to effective flow for friction calculations
    state.q_utube = 0.0  # disabled as flow; see diag for imbalance magnitude
    # Effective flow for friction: do NOT invent U-tube gpm; use measured Qin and losses
    state.effective_flow = max(o.flow_in_gpm - state.q_loss, 0.0)
    state.bit_pressure_drop = _bit_dp(state.effective_flow, state.corrected_density, b.tfa)
    K_eff = f.K * visc_factor
    state.annular_friction = _annular_friction(state.effective_flow, state.corrected_density, g.hole_id, g.pipe_od, g.md, f.n, K_eff, o.rpm)
    state.pipe_friction = _pipe_friction(state.effective_flow, state.corrected_density, g.pipe_id, g.md, f.n, K_eff)

    state.bhp = state.hydrostatic + state.annular_friction + o.sbp_setpoint
    state.ecd = state.bhp / (0.052 * g.tvd) if g.tvd > 0 else 0.0
    state.surface_friction = surface_piping_friction(
        state.piping, state.effective_flow, state.corrected_density, f.n, f.K * visc_factor
    )
    # Steady circulation pressure balance (homogeneous):
    # SPP ≈ ΔP_surface + ΔP_pipe + ΔP_bit + ΔP_annulus + SBP + ΔP_hydro(ann-string)
    # U-tube hydrostatic imbalance is accounted via column hydrostatics, not a 0.15 factor.
    hydro_imbalance = 0.0
    if state.pipe_column and state.ann_column:
        # approximate: difference already reflected in u_tube_dp sign convention
        hydro_imbalance = max(-state.u_tube_dp, 0.0)  # only if pipe heavier contributes to SPP demand
    state.model_spp = (
        state.pipe_friction
        + state.bit_pressure_drop
        + state.annular_friction
        + state.surface_friction
        + o.sbp_setpoint
        + hydro_imbalance
    )

    # Multi-method live pore pressure (formation, d-exp, gas, temp → hybrid)
    state = estimate_pore_pressure(state)
    state = detect_kick_loss(state)

    state = calculate_surge_swab(state)

    if state.choke_mode == "CBHP" and state.mode == "Simulation":
        state = auto_adjust_sbp_for_cbhp(state)
        state.bhp = state.hydrostatic + state.annular_friction + state.operating.sbp_setpoint
        state.ecd = state.bhp / (0.052 * g.tvd) if g.tvd > 0 else 0.0
        state.overbalance = state.bhp - state.live_pp

    state = run_diagnostics(state)
    state = push_history(state)
    return state

def get_profile_depth_data(state, num_points=16):
    """ILLUSTRATIVE profile only – NOT a sectional hydraulic solution.
    Densities/friction are linearly distributed for visualization.
    Do not use for engineering decisions.
    """
    rows = []
    md_step = state.geometry.md / max(num_points - 1, 1)
    for i in range(num_points):
        md = i * md_step
        tvd = md * (state.geometry.tvd / state.geometry.md) if state.geometry.md > 0 else md
        frac = md / state.geometry.md if state.geometry.md > 0 else 0.0
        dens_ann = state.corrected_density + frac * 0.25
        hydro = _hydrostatic(dens_ann, tvd)
        fric = state.annular_friction * frac
        pressure = hydro + fric + state.operating.sbp_setpoint * frac
        ecd = pressure / (0.052 * tvd) if tvd > 1 else 0.0
        form = get_formation_at_depth(state.lithology, md)
        form_temp = temp_at_tvd(state.temp_profile, tvd, state.fluid.ambient_temp, state.fluid.temp_gradient)
        ann_temp = state.fluid.temp_in + frac * (state.fluid.temp_out - state.fluid.temp_in)
        # blend annulus circulating temp with formation temp at depth
        ann_temp = 0.6 * ann_temp + 0.4 * form_temp
        rows.append({
            "MD_ft": round(md, 0), "TVD_ft": round(tvd, 0), "Formation": form["name"],
            "Formation_Temp_F": round(form_temp, 1), "Annulus_Temp_F": round(ann_temp, 1),
            "Pipe_Temp_F": round(state.fluid.temp_in + frac * (form_temp - state.fluid.temp_in) * 0.5, 1),
            "Annulus_Density_ppg": round(dens_ann, 2), "Pipe_Density_ppg": round(state.corrected_density, 2),
            "Annulus_Friction_psi": round(fric, 1),
            "Pipe_App_Visc_cP": round(state.fluid.pv * (1 + frac * 0.3), 1),
            "Annulus_App_Visc_cP": round(state.fluid.pv * (1 + frac * 0.5), 1),
            "Annulus_ECD_ppg": round(ecd, 2), "Annulus_Pressure_psi": round(pressure, 1),
            "Pore_Pressure_psi": round(tvd * form.get("pp_grad", 0.56), 1),
            "Fracture_Pressure_psi": round(tvd * form.get("fg_grad", 0.90), 1),
            "PPG": round(form.get("pp_grad", 0.56) * 19.25, 2), "WBSG_ppg": 0.0, "WBS_psi": 0.0,
        })
    return rows

def add_timeline_event(state, event, details=""):
    state.timeline.insert(0, {"time": datetime.now().strftime("%H:%M:%S"), "event": event, "details": details})
    state.timeline = state.timeline[:50]
    return state

def log_activity(state, activity, duration_min=1.0):
    state.activity_log.append({"time": datetime.now().strftime("%H:%M:%S"), "activity": activity, "duration_min": duration_min})
    state.activity_log = state.activity_log[-200:]
    return state

def get_activity_summary(state):
    summary = {}
    for a in state.activity_log:
        summary[a["activity"]] = summary.get(a["activity"], 0.0) + a.get("duration_min", 1.0)
    if not summary:
        summary = {"Drilling": 42, "Connection": 18, "Circulating": 15, "Trip": 12, "Offline": 8, "Other": 5}
    return summary

def state_to_dict(state: SimulationState) -> Dict[str, Any]:
    """Serialize state for Save"""
    return {
        "geometry": asdict(state.geometry),
        "fluid": asdict(state.fluid),
        "fluid_library": state.fluid_library,
        "surface_equipment": state.surface_equipment,
        "piping": state.piping,
        "pump_fluid_name": state.pump_fluid_name,
        "offset_fluid_name": state.offset_fluid_name,
        "initial_fluid_name": state.initial_fluid_name,
        "pipe_column": state.pipe_column,
        "ann_column": state.ann_column,
        "column_initialized": state.column_initialized,
        "operating": asdict(state.operating),
        "bit": asdict(state.bit),
        "surge": asdict(state.surge),
        "mode": state.mode,
        "choke_mode": state.choke_mode,
        "target_bhp": state.target_bhp,
        "target_ecd": state.target_ecd,
        "litho_gradient": state.litho_gradient,
        "lithology": state.lithology,
        "casings": state.casings,
        "open_hole": state.open_hole,
        "work_string": state.work_string,
        "wellpath": state.wellpath,
        "temp_profile": state.temp_profile,
        "timeline": state.timeline[:20],
        "activity_log": state.activity_log[-50:],
    }

def dict_to_state(data: Dict[str, Any]) -> SimulationState:
    """Deserialize state for Load"""
    state = SimulationState()
    if "geometry" in data:
        state.geometry = WellGeometry(**data["geometry"])
    if "fluid" in data:
        # filter unknown keys for forward compatibility
        fk = {k: v for k, v in data["fluid"].items() if k in FluidProperties.__dataclass_fields__}
        state.fluid = FluidProperties(**fk)
    state.fluid_library = data.get("fluid_library", [dict(x) for x in DEFAULT_FLUID_LIBRARY])
    state.surface_equipment = data.get("surface_equipment", [dict(x) for x in DEFAULT_SURFACE_EQUIPMENT])
    state.piping = data.get("piping", [dict(x) for x in DEFAULT_PIPING])
    state.pump_fluid_name = data.get("pump_fluid_name", state.pump_fluid_name)
    state.offset_fluid_name = data.get("offset_fluid_name", state.offset_fluid_name)
    state.initial_fluid_name = data.get("initial_fluid_name", state.initial_fluid_name)
    state.pipe_column = data.get("pipe_column", [])
    state.ann_column = data.get("ann_column", [])
    state.column_initialized = data.get("column_initialized", False)
    if "operating" in data:
        state.operating = OperatingParams(**data["operating"])
    if "bit" in data:
        state.bit = BitParams(**data["bit"])
    if "surge" in data:
        state.surge = SurgeSwabParams(**data["surge"])
    state.mode = data.get("mode", "Offline")
    state.choke_mode = data.get("choke_mode", "AUTO")
    state.target_bhp = data.get("target_bhp", 7500.0)
    state.target_ecd = data.get("target_ecd", 11.20)
    state.litho_gradient = data.get("litho_gradient", 0.56)
    state.lithology = data.get("lithology", DEFAULT_LITHOLOGY.copy())
    state.casings = data.get("casings", [dict(x) for x in DEFAULT_CASINGS])
    state.open_hole = data.get("open_hole", [dict(x) for x in DEFAULT_OPEN_HOLE])
    state.work_string = data.get("work_string", [dict(x) for x in DEFAULT_WORK_STRING])
    state.wellpath = data.get("wellpath", [dict(x) for x in DEFAULT_WELLPATH])
    state.temp_profile = data.get("temp_profile", [dict(x) for x in DEFAULT_TEMP_PROFILE])
    state.timeline = data.get("timeline", [])
    state.activity_log = data.get("activity_log", [])
    return run_hydraulics(state)

def save_state_json(state: SimulationState, path: str = "data/well_state.json") -> str:
    from pathlib import Path
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state_to_dict(state), indent=2), encoding="utf-8")
    return str(p)

def load_state_json(path: str = "data/well_state.json") -> SimulationState:
    from pathlib import Path
    p = Path(path)
    if not p.exists():
        return run_hydraulics(SimulationState())
    data = json.loads(p.read_text(encoding="utf-8"))
    return dict_to_state(data)
