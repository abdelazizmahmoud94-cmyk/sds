# ARHPP Digital Twin – Stage 22

**PROTOTYPE / EDUCATIONAL SIMULATOR**  
Not validated for operational decisions or Well Control.

## Stage 22 – Phase 2: Single source of truth

### Navigation
- **Monitoring** – Pore Pressure, Profile, MPD Gauges, Timeline, Actual vs Model, …
- **Setup** – Wellpath, Formations, Temperatures, Fluid Properties, Surface Equipment, Settings
- **Operations** – Pumps, Choke Control, Kick/Loss, Surge & Swab

### Parameter ownership
| Parameter | Editable only on |
|-----------|------------------|
| Pump SPM / liner / stroke / eff | Operations › Pumps |
| SBP / choke mode / position | Operations › Choke Control |
| Pit gain | Operations › Kick/Loss |
| Mud density / rheology / Fann | Setup › Fluid Properties |
| Geometry / BHA / survey | Setup › Settings / Wellpath |
| Gas / ROP / WOB / RPM / Flow Out | Live Inputs (sidebar) |
| Bottom strip | **Status only** (read-only) |

### Stage 21 physics fixes retained
- Correct volumetric pump formula
- Volume-queue multi-fluid displacement
- U-Tube as indicator only
- Survey-aware hydrostatic
- No Flow-Out mutation / no pit auto-integrate
- Full annular friction in Model SPP
- Generic formations only

## Run
```bash
cd ARHPP_App
pip install -r requirements.txt
streamlit run app.py
```
